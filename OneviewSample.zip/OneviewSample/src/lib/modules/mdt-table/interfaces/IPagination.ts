export class IPagination {
    rowsPerPage: Array<number>;
    defaultRowsPerPage: number;
}