import {IRow} from "./IRow";

export class IPaginationService {
    itemsPerPage: number;
    page: number;

 
}