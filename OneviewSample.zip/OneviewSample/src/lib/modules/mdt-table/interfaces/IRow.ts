import {ICell} from "./ICell";

export class IRow{
    rowId?: any;
    index: number;
    //selected: boolean;
    //deleted: boolean;
    //visible: boolean;
    value: Array<ICell>;
    //rawValue: any;
}