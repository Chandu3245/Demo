import {IPagination} from "./IPagination";

export class ITableFooter {
    pagination: IPagination;
}