export class ITableHeader {
    title: string;
}