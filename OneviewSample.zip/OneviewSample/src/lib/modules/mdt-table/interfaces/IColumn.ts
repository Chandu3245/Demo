import {AlignRule} from "../enums/AlignRule";
import {ColumnType} from "../enums/ColumnType";

export class IColumn{
    dataKey: string;
    name: string;
    align: AlignRule;
    columnType:ColumnType;
    isInEditMode:boolean;
    isFreeze:boolean;
    isEdit:boolean;
    isGroupingAllowed:boolean;
}