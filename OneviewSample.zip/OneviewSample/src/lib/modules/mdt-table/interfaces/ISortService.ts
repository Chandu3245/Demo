import {IColumn} from "./IColumn";
import {IRow} from "./IRow";

export class ISortService {

    
}