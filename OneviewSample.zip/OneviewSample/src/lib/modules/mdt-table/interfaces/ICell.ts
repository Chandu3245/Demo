

export class ICell{
    dataKey:any;
    value:any;
    isEdit:boolean;
    columnType?:any;
}