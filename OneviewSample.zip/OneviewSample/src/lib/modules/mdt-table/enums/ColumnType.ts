export enum ColumnType{
    TEXT=1,
    REFERENCE_DATA,
    ICON,
    ACTION,
    CLICKABLE,
    CLICKABLE_ICON,
    DATE,
    LOOK_UP,
    DROP_DOWN,
    PRIMARYKEY
}