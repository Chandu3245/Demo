export enum AlignRule{
    Left=1,
    Right,
    Center
}