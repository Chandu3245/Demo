export enum SortDirection {
    Ascending,
    Descending
}