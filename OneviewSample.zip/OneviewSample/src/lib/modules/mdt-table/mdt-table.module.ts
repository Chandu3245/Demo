import { CommonModule } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { HttpModule,BrowserXhr } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import 'hammerjs';

import { MdtTable,MdtRows,MdtColumns,MdtFooter,MdtColumnConfig,MdtChips } from './components';
import {CustomBrowserXhr} from './custom-browser-xhr';
import { MdtCellDoubleClick,MdtCellAlign} from './directives'
import {IColumn} from "./interfaces/IColumn";
import { MyMaterialModule } from './../material/material.module';
import { DataService,ArrayPaginationService, SortService } from './services';

import { DragDropDirectiveModule} from "angular4-drag-drop";
// import {Parser} from 'xml2js';

@NgModule({
  declarations: [
    MdtTable,MdtRows,MdtColumns,MdtFooter,MdtColumnConfig,MdtChips,MdtCellDoubleClick,MdtCellAlign
 
  ],
  imports: [
    CommonModule, FormsModule,ReactiveFormsModule,
    HttpModule,
    MyMaterialModule ,
    DragDropDirectiveModule,
    CommonModule
  ],
  providers: [DataService,ArrayPaginationService, SortService, { provide: BrowserXhr, useClass: CustomBrowserXhr }],
  entryComponents: [MdtColumnConfig],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  exports:[MdtTable],

})
export class MdtTableModule { }
