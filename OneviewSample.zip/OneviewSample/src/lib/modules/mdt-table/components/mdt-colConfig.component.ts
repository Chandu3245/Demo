import { Component,Input,Output,OnInit,Inject ,ChangeDetectorRef} from '@angular/core'
import {MAT_DIALOG_DATA} from '@angular/material';

import {DataService} from "../services/DataService";

@Component({
    selector:'col-config',
    templateUrl: '../views/mdt-colconfig.html',
    styleUrls: ['../main.scss']
})
export class MdtColumnConfig implements OnInit {
    
    private availabelColumns:any =[];
    private selectedColumns:any = [];
    
    private chosenSelectedList: any= [];
    private chosenAvailableColumn: string[] = [];
    private selectSelectedColumns: boolean = false;
    private selectedColumnsLeftArrowCheckbox:boolean=false;
    private selectedColumnsRightArrowCheckbox:boolean=false;
    private interchangeElement: any = -1
     private dragStartSection:string='';
     private  savecolumns:boolean=false;
    private selCols:any=[];
    private availCols:any=[];
    private middleBtnTransition:number=-1;
    constructor(@Inject(MAT_DIALOG_DATA) public cols: any,@Inject(DataService) public dataService:DataService, public ref:ChangeDetectorRef){
        
        
        
    }
    
    ngOnInit(){
        this.availabelColumns = this.dataService.getAvailableColumns();
        this.selectedColumns =  this.dataService.getSelectedColumns();
        if(!this.selectedColumns || (this.selectedColumns && this.selectedColumns.length <1)){
            this.selectedColumns = this.cols;
        }
        if(!this.availabelColumns || (this.availabelColumns && this.availabelColumns.length <1)){
            this.availabelColumns = [];
        }
        if(this.availabelColumns == this.selectedColumns){
            this.availabelColumns = [];
        }
       

        if(this.selectedColumns != this.cols){
            this.selectedColumns = this.cols;
            this.availabelColumns = [];
            this.dataService.saveColPreferences(this.availabelColumns,this.selectedColumns)
        }
    }
    
    public draggingStart(event,dragStartFlag){
        this.dragStartSection = dragStartFlag
    }
    
    public onDrop(evn,col:any=[],dragStopflag){
         let dropColumn = evn;
        
         if(dragStopflag == 0){
             if(dragStopflag != this.dragStartSection){
                 this.removeFromSelectedColumns();
             }else{
                 this.availabelColumns = this.dataService.swapItemList(col,this.chosenAvailableColumn, this.availabelColumns,0);
                 this.ref.detectChanges();
             }
             
         }else{
             if(dragStopflag !=  this.dragStartSection){
                 this.addToSelectedColumns();
             }else{
                this.selectedColumns =  this.dataService.swapItemList(col,this.chosenSelectedList, this.selectedColumns,1);
                this.ref.detectChanges();
             }
             
             
         }
        
    }
    
    public selectedSelctionChanged(element, event, ind?) {
        if (event.checked) {
            this.chosenSelectedList.push(element);
            if (this.chosenSelectedList.length ==1) {
                this.selectSelectedColumns = true;
            }
            else{
                this.selectSelectedColumns = false;
            }
            this.selectedColumnsLeftArrowCheckbox=true;
        } else {
            if (this.chosenSelectedList.indexOf(element) >= 0) {
                this.chosenSelectedList.splice(this.chosenSelectedList.indexOf(element), 1);
                if (this.chosenSelectedList.length == 0 || this.chosenSelectedList.length>1) {
                    this.selectSelectedColumns = false;
                }
                else{
                    this.selectSelectedColumns = true;
                }
            }
        }
        // if (this.chosenSelectedList.length != 1) {
        //     this.selectSelectedColumns = true;
        // } else {
        //     this.interchangeElement = ind;
        //     this.selectSelectedColumns = false;
        // }
    }
    
    public removeEleFromSelected(ind, event) {
        this.availabelColumns.push(this.selectedColumns[ind]);
        this.selectedColumns.splice(ind, 1);
        event.preventDefault();
    }
    
    public removeFromSelectedColumns() {
    //    this.availCols=this.availabelColumns;
         for (let i = 0; i < this.chosenSelectedList.length; i++) {
            let eleIndex = this.selectedColumns.indexOf(this.chosenSelectedList[i]);
            let dummy = this.selectedColumns.splice(eleIndex, 1)
            this.selCols.push(dummy[0]);
        }
      this.availabelColumns = this.availabelColumns.concat(this.chosenSelectedList);
          this.chosenSelectedList = [];

          if (this.chosenSelectedList.length ==1) {
            this.selectSelectedColumns = false;
        }
        else{
            this.selectSelectedColumns = false;
        }
        this.selectedColumnsLeftArrowCheckbox=false;
    }
    
    public availableSelectionChanged(element, event) {
        if (event.checked) {
            this.chosenAvailableColumn.push(element);
            this.selectedColumnsRightArrowCheckbox=true;
        } else if (this.chosenAvailableColumn.indexOf(element) >= 0) {
            this.chosenAvailableColumn.splice(this.chosenAvailableColumn.indexOf(element, 1));
            this.selectedColumnsRightArrowCheckbox=true;
        }
    }
    
    public addEleToSelected(ind, event) {
        this.selectedColumns.push(this.availabelColumns[ind]);
            this.availabelColumns.splice(ind, 1);
        event.preventDefault();
    }
    
    public addToSelectedColumns() {
        for (let i = 0; i < this.chosenAvailableColumn.length; i++) {
            let eleIndex = this.availabelColumns.indexOf(this.chosenAvailableColumn[i]);
            this.availabelColumns.splice(eleIndex, 1);
        }
        this.selectedColumns = this.selectedColumns.concat(this.chosenAvailableColumn);
        this.chosenAvailableColumn = [];
        this.selectedColumnsRightArrowCheckbox=false;
    }
    
    public saveColSetting(){
        this.dataService.saveColPreferences(this.availabelColumns,this.selectedColumns);
    }
   public cancelColsetting(){
    for(let item of this.selCols){
        if(this.selectedColumns.indexOf(item)<0){
            this.selectedColumns.push(item)
        }
    }
    // this.availabelColumns=this.dataService.getAvailableColumns();
    //  this.dataService.saveColPreferences(this.availabelColumns,this.selectedColumns);
   }
    public interchangeSelectedColumns() {

        let indexOfEleToBeSwapped = this.selectedColumns.indexOf(this.chosenSelectedList[0]);
        if (indexOfEleToBeSwapped != 0) {
            let newSelectedColumns = this.selectedColumns;
            let arraySwap = newSelectedColumns.splice(indexOfEleToBeSwapped, 1);
            this.selectedColumns.splice(indexOfEleToBeSwapped - 1, 0, arraySwap[0]);
        }

        // this.selectSelectedColumns = true;
    }
    public interchangeSelectedColumns1() {
        let indexOfEleToBeSwapped = this.selectedColumns.indexOf(this.chosenSelectedList[0]);
        if (indexOfEleToBeSwapped != this.selectedColumns.length - 1) {
            let newSelectedColumns = this.selectedColumns;
            let arraySwap = newSelectedColumns.splice(indexOfEleToBeSwapped, 1);
            this.selectedColumns.splice(indexOfEleToBeSwapped + 1, 0, arraySwap[0]);
        }

        //this.selectSelectedColumns = true;
    }
}