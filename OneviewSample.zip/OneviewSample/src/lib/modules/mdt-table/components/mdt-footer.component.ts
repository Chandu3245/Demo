import {Component, Input,Output, EventEmitter, Inject} from "@angular/core";
import {ITableFooter} from "../interfaces/ITableFooter";
import {ArrayPaginationService} from "../services/ArrayPaginationService";
import {DataService} from "../services/DataService";
@Component({
    selector: 'mdt-footer',
    styleUrls:['../main.scss'],
    templateUrl: '../views/mdt-footer.html',
})
export class MdtFooter{
    @Input('table-footer')
    tableFooter: ITableFooter;
    @Input() tabMode;
    @Input() enableServerSidePagination;
    @Input() recordCount:any;

    @Output() serverSidePagintionEmit: EventEmitter<any> = new EventEmitter();
    @Output() serverRowsPerPage: EventEmitter<any> = new EventEmitter();
    @Output() tabModeEmit: EventEmitter<any> = new EventEmitter();
    @Output() ChangeRowPage: EventEmitter<any> = new EventEmitter();

    private paginationOpts:number[] = [1,2,3,4,5];
    
    constructor(@Inject(ArrayPaginationService) private arrayPaginationService: ArrayPaginationService,
    @Inject(DataService) public dataService: DataService){

    }

    ngOnInit(){
        this.tableFooter.pagination.rowsPerPage =  this.tableFooter.pagination.rowsPerPage || [];

        if(this.isEnabled()){
            this.tableFooter.pagination.defaultRowsPerPage = this.tableFooter.pagination.defaultRowsPerPage
                                                                || this.tableFooter.pagination.rowsPerPage[0];

            this.arrayPaginationService.setItemsPerPage(this.tableFooter.pagination.defaultRowsPerPage);
        }
    }
    ngOnChanges(){
        if(this.recordCount){
            this.arrayPaginationService.setserverRowsCount(this.recordCount);
        }
    }

    isEnabled(){
        return this.tableFooter.pagination.rowsPerPage.length > 0;
    }

    setPageSize(pageSize:number){
        if(!this.enableServerSidePagination == false){
            let dummy ={ 
           startIndex: Number(1),
            endIndex:Number(pageSize)
            }
            this.serverRowsPerPage.emit(dummy);
        }
        this.arrayPaginationService.setItemsPerPage(+Number(pageSize));
        this.ChangeRowPage.emit(pageSize);
    }

  nextPage(){
        if(!this.enableServerSidePagination ==  false){
            let startIndex = this.arrayPaginationService.getServerSideStartIndex() + (this.arrayPaginationService.itemsPerPage);
            let endIndex = startIndex + (this.arrayPaginationService.itemsPerPage -1);
            if(endIndex > this.arrayPaginationService.getserverRowsCount()){
                endIndex = this.arrayPaginationService.getserverRowsCount();
            }
            this.paginationServerSide(startIndex,endIndex);
        

       
        } else{
          //  this.emitPagination();
        //   console.log("elsepart")
          this.tabMode = 'defaultMode';
          this.tabModeEmit.emit(this.tabMode);
          this.arrayPaginationService.nextPage();
        }
       
    }

    previousPage(){
        if(!this.enableServerSidePagination ==  false){
            let startIndex = this.arrayPaginationService.getServerSideStartIndex() - this.arrayPaginationService.itemsPerPage;
            let endIndex =  this.arrayPaginationService.getServerSideEndIndex() - this.arrayPaginationService.itemsPerPage
            if(startIndex ==1){
                endIndex = this.arrayPaginationService.itemsPerPage
            }
            this.paginationServerSide(startIndex,endIndex);
       
        } else{
            this.tabMode = 'defaultMode';
            this.tabModeEmit.emit(this.tabMode);
    
            this.arrayPaginationService.previousPage();
        }
    }
  public paginationServerSide(startInd,endInd) {
    this.arrayPaginationService.setServerSideStartIndex(startInd);
    this.arrayPaginationService.setServerSideEndIndex(endInd);


        let dummy = {
            startIndex: Number(startInd),
            endIndex: Number(endInd),
        }
        this.serverSidePagintionEmit.emit(dummy);
    }


    isPreviousButtonDisabled(): string {
        if(!this.enableServerSidePagination){
            if(this.arrayPaginationService.hasPreviousPage() == false){
                return 'md-dark md-inactive';
            }
            return '';
        }else{
            if(this.arrayPaginationService.getServerSideStartIndex() == 1){
                return 'md-dark md-inactive';
            }
            return '';
        }
        
    }

    isNextButtonDisabled(): string {
        if(!this.enableServerSidePagination){
            if(this.arrayPaginationService.hasNextPage() == false){
                return 'md-dark md-inactive';
            }
    
            return '';
        }else{
            if(this.arrayPaginationService.getServerSideEndIndex() == this.arrayPaginationService.getserverRowsCount()){
                return 'md-dark md-inactive';
            }
            return '';
        }
       
    }
    
    public paginationTable(crntPage){
        this.tabMode = 'defaultMode';
        this.tabModeEmit.emit(this.tabMode);
        this.arrayPaginationService.setPageNumber(crntPage);
        
        this.arrayPaginationService.transformRows(this.dataService.getRows());
      
             
    }
    //to populate button based pagination based on no.of pages available
    public checkNoOfPagesAvailable(){
        let totNoOfRows = this.dataService.getRows().length;
        let totNoPages = totNoOfRows/this.tableFooter.pagination.defaultRowsPerPage;
        if(totNoPages >= 5){
            this.paginationOpts = [1,2,3,4,5];
        }else {
            for(let i=1;i<=totNoPages;i++){
                this.paginationOpts.push(i);
            }
        }
    }
}
