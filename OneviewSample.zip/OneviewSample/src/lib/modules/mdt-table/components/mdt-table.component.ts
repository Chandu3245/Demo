import {Component, Input, Output,OnDestroy,EventEmitter, ChangeDetectorRef, Inject,AfterViewChecked,AfterViewInit} from "@angular/core";
import { FormControl,FormGroup, FormBuilder } from '@angular/forms';
import {MatIconRegistry,MatDialog,MatSnackBar} from '@angular/material';

import { ColumnType } from './../enums/ColumnType';
import {IPagination} from "../interfaces/IPagination";
import {ITableHeader} from "../interfaces/ITableHeader";
import {ITableFooter} from "../interfaces/ITableFooter";
import { MdtChips } from './mdt-chips.component';
import {MdtColumns} from "./mdt-columns.component";
import { MdtColumnConfig } from './mdt-colConfig.component'
import {MdtFooter} from "./mdt-footer.component";
import {MdtHeader} from "./mdt-header.component";
import {MdtRows} from "./mdt-rows.component";
import {ArrayPaginationService} from "../services/ArrayPaginationService";
import { DataService } from './../services/DataService';
import {SortService} from "../services/SortService";
import{WindowRef} from"../../../../app/services/WindowRef.service";

export {AlignRule} from '../enums/AlignRule';
import{ environment } from '../../../../environments/environment';
export {ColumnType} from '../enums/ColumnType';

import {Observable} from 'rxjs/Observable';
import {map} from 'rxjs/operators/map';
import {startWith} from 'rxjs/operators/startWith';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'mdt-table',
    templateUrl: '../views/mdt-table.html',
    styleUrls:['../main.scss'],
    providers: [DataService, ArrayPaginationService, MatIconRegistry, SortService]
})
export class MdtTable implements AfterViewChecked ,AfterViewInit{
    @Input() columnsObj: any;
    @Input() rowsObj: any;
    @Input('table-header') tableHeader: ITableHeader;
    @Input('pagination') pagination: IPagination;
    @Input('sortable-columns') sortableColumns: boolean;
    @Input() colHeight;
    @Input() rowHeight;
    @Input() enableColConfig:boolean;
    @Input() enableFilter:boolean;
    @Input() enableRowEdit:boolean;
    @Input() enableCheckbox:boolean; 
    @Input() enableGrouping:boolean;
    @Input() enableColDrag:boolean;
    @Input() enableEdit:boolean;
    @Input() enableAction:boolean
    @Input() actionItems;
    @Input() actionMenu;
    @Input() enableServerSidePagination:boolean;
    @Input() enableServerSideSorting:boolean
    @Input() recordCount:any;
    @Input() imagePath;
    @Input()  enableCellLevelEnabled:boolean;
    @Input() enableServerSideFilterLookup:any;
    @Input() serverSideFilterLookupValues:any;
    @Input() EditServerSideLookup:any;
    @Input() CommunicationLookUp:any;
    @Input() CommunicationFilterFlag:boolean;
    

    @Output() saveEdittedRow:EventEmitter<any>= new EventEmitter();
    @Output() edittedCellVal:EventEmitter<any>= new EventEmitter();
    @Output() colFilterOpt:EventEmitter<any>= new EventEmitter();
    @Output() colFilterOptWithOutServer:EventEmitter<any>= new EventEmitter();
    @Output() actionSelectedEvent: EventEmitter<any> = new EventEmitter();
    @Output() rowsSelOpt:EventEmitter<any>= new EventEmitter();
    @Output() clickableCol: EventEmitter<any> = new EventEmitter();
    @Output() serverSortingOpt: EventEmitter<any> = new EventEmitter();
    @Output() serverSideFilterLookupObj: EventEmitter<any> = new EventEmitter();
    @Output() serverPaginationOpt: EventEmitter<any> = new EventEmitter();
    @Output()serverRowsPerPage: EventEmitter<any> = new EventEmitter(); 
     //lnagpal
     @Output() communicationCategoryLookup:EventEmitter<any> = new EventEmitter();

     @Output() MostRecentRowOpt:EventEmitter<any> = new EventEmitter()
    

     private hoverRowIndex:any ; // to store the index of hovered row
     private mostRecentRowSelected:any ={index:-1}; // to store the recent row
    tableFooter: ITableFooter;
    
    private rows:any;
    private sortHoverIndex: number = -1;
    private columns:any;
    private listOfSelectedRows:any=[];
    private selectAllRowFlag:boolean=false;
    private groupByObservable:any;
   private groupbyappliedFlag:boolean = false;
   private getEdittedRowIndex:any;
    private openEdittedForm:boolean = false;
    private startRowIndex:number=-1;
    private endRowIndex:number=-1;
    private checkappliedFlag:boolean=false;
    private editMode:boolean = false;
    tabRows:any=[];
    private edittingRow:any;
    private edittableFieldsObj:any = [];
    private colsForEditting:any
    private cellValEd:any;
    private rowBeingEditted:any;
    private editDivHeightStyle:number;
    private totRowEditObg:any;
    columnType = ColumnType;
    editLookUpControl: any;
    private filteredOpts:any;
    private lookUpOpts:any= [];
    private groupEmitObj:any;
    private DropDownOpts :any= [];
    private tabMode:string = 'defaultMode';
    private docUrl:string;
    private groupingFlag :boolean;
    private selectedFilterListCol:any=[];
    private filterTrigAt:string;
    private loadForm = false;
    private defaultLookup:boolean = true;
    private editFieldForm:FormGroup;
    private    columnForSort:    any=[];    
    private commCardCategory:any=[];   //lnagpal
    commCategoryCtrl: FormControl; //lnagpal
    commCategories: Observable<any[]>;  //lnagpal
  private controlNameFocused:any;
 private selectedRowClick:any;
 private sortIconChange:boolean = true;
 private rowSelected:boolean=false;
 private winref: any;
//  private toolTipPositionLeft="left";
 private actionMenuIcons:any=["share","file_download","delete_forever","attach_file"];
 private actionTriggerd:any;
 private  selectedRows: any=[];
 private columnsToSort:any=[];
 private subscription:any;
 private hideSortingIcon:any=-1;
 private dummyAppliedFilterArray:any=[];
    constructor(@Inject(DataService) protected dataService: DataService,
    @Inject(ArrayPaginationService)  protected arrayPaginationService: ArrayPaginationService,
    @Inject(SortService) protected sortService: SortService,
    @Inject(MatDialog)  public dialog: MatDialog, 
    @Inject(FormBuilder) private fb: FormBuilder,
    @Inject(ChangeDetectorRef)  private ref:ChangeDetectorRef,
    @Inject(WindowRef) private winRef: WindowRef,
    @Inject(MatSnackBar) public snackBar: MatSnackBar,){
        this.docUrl = environment.DocURL;
        this.winref = winRef.nativeWindow;
                 let self=this;
                 
        //          this.editLookUpControl = new FormControl();
        // this.filteredOpts  = this.editLookUpControl.valueChanges
        //     .startWith(null)
        //     .map(name => this.filterOpt(name,this.lookUpOpts))
            
            this.dataService.getGroupByObserver().subscribe(function(res){  
                self.groupingFlag = res.groupingFlag;
            })
            this.dataService.getRowSelectioinObservable().subscribe(function (res) {
               self.selectedRows=res;
               })
               this.subscription=this.dataService.getSortingCol().subscribe(function (res) {
                self.selectAllRowFlag=false;
                self.selectAllRow(self.selectAllRowFlag);
            });
            //lnagpal
            // this.CommunicationCategory();
         
           this.commCategoryCtrl = new FormControl();
        

             
    }
    
    ngAfterViewInit(){
       
        // this.scrollbarService.initScrollbar('#top', { axis: 'yx',theme: 'minimal-dark', }); 
        // this.scrollbarService.initScrollbar('#bottom', { axis: 'yx',theme: 'minimal-dark', }); 
        this.onScroll();
       
    }
    
    ngOnInit(){
        // this.dataService.addColumns(this.columns);
        // this.dataService.addRows(this.rows);
        this.columnsToSort=this.columns;
        this.sortService.setSortingEnabled(this.sortableColumns);

        this.tableFooter = {
            pagination: this.pagination || <IPagination>{}
        };
        if(this.pagination){
            this.arrayPaginationService.setItemsPerPage(this.pagination.defaultRowsPerPage)
        }
        

        
    }
    ngOnChanges(){
        if( this.columnsObj &&  this.columnsObj.length>0){
            this.columns = this.dataService.configureColumns(this.columnsObj);
            // this.dataService.setSelectedColumns([]);
            this.dataService.saveColPreferences(this.columns,this.columns);
            this.rows = this.dataService.configureRows(this.rowsObj);

            this.dataService.addColumns(this.columns);
            this.dataService.addRows(this.rows);          
            this.columnsToSort=this.columns;  
        }
      
        // if(this.columns && this.columns.length>0){
        //     this.dataService.addColumns(this.columns);
        // }
        this.dataService.setImagePath(this.imagePath);
   
        if(this.CommunicationLookUp!==undefined){
            
             this.commCategories = this.commCategoryCtrl.valueChanges
               .pipe(
                 startWith(''),
                 // map(opts => opts ? this.cardCommCategories(opts) : this.commCardCategory.slice())
                 map(opts => opts ? this.cardCommCategories(opts) : this.CommunicationLookUp.slice())
               );
              }

              if(this.EditServerSideLookup){
                  let arrayToBeFiltered = [];
                  for(let item of this.EditServerSideLookup){
                    if(arrayToBeFiltered.indexOf(item.name)<0){
                            arrayToBeFiltered.push(item.name);
                    }
                  }
                  this.filteredOpts  = this.editFieldForm.controls[this.controlNameFocused].valueChanges
                  .startWith(this.editFieldForm.controls[this.controlNameFocused]["_value"])
                  .map(name => this.filterOptServer(name,arrayToBeFiltered))
              }
           
              
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
      }

    filterOptServer(val,arrayToBeFiltered){
        return val ? arrayToBeFiltered.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
        : arrayToBeFiltered;
    }
 ngAfterViewChecked(){

    //  this.scrollbarService.initScrollbar('#top', { axis: 'yx',theme: 'minimal-dark', }); 
    //  this.scrollbarService.initScrollbar('#bottom', { axis: 'yx',theme: 'minimal-dark', }); 
     this.onScroll();
 }
 onScroll(){
    var isSyncingLeftScroll = false;
    var isSyncingRightScroll = false;
    var leftDiv = document.getElementById('top');
    var rightDiv = document.getElementById('bottom');
    
    leftDiv.onscroll = function() {
        if (!isSyncingLeftScroll) {
          isSyncingRightScroll = true;
          rightDiv.scrollLeft = this.scrollLeft;
      }
      isSyncingLeftScroll = false;
    }
    
    rightDiv.onscroll = function() {
        if (!isSyncingRightScroll) {
          isSyncingLeftScroll = true;
          leftDiv.scrollLeft = this.scrollLeft;
      }
      isSyncingRightScroll = false;
    }
 }

    //lnagpal
    cardCommCategories(name: any) {
        // return this.commCardCategory.filter(opts =>
        return this.CommunicationLookUp.filter(opts =>
            opts.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
      }

    checkNoOfCols(){
        if(this.columns && this.columns.length <=2){
            for(let item of this.columns){
                if(item.columnType ==ColumnType.PRIMARYKEY  ){
                    return true
                }
            }
        }
        return false
    }


    mapControlToLookup (row,controlName){
        this.controlNameFocused=controlName
        let col={
            dataKey:controlName
        }
        let dummy={
            col: this.dataService.getColAsPerInput(col),
            value:this.editFieldForm.controls[controlName]["_value"]
        }
        // this.lookUpOpts = this.dataService.getLookupValues(col);
        // console.log(this.lookUpOpts);
        let control = this.editFieldForm.controls[controlName];
        // this.editLookUpControl = control;
        this.filteredOpts  = this.editFieldForm.controls[controlName].valueChanges
        .startWith(this.editFieldForm.controls[controlName]["_value"])
        .map(name => this.filterOpt(name,col))


        this.serverSideFilterLookupObj.emit(dummy);
          //   this.CommunicationCategory()
            //  this.serverSideFilterLookupObjEmit(event)
    }

    createForm() {
      
        const group = this.fb.group({});
        this.edittableFieldsObj.forEach(control => group.addControl(control.dataKey, this.createControl(control)));
      
        
        return group;
      }
      public rowClick(event){
        
    this.clickableCol.emit(event);
    }

      createControl(config) {
        const { isDisabled, validation , value } = config;
            if(config.colType==ColumnType.LOOK_UP){
                this.createAutoControl(this.fb.control( {'value':config.value, 'disabled':isDisabled}, validation ))
            }
                return this.fb.control( {'value':config.value, 'disabled':isDisabled}, validation );
            }
      public createAutoControl(controls){
          
      }
      public closeAutoPanel(rowItem){
          rowItem.value =  this.editFieldForm.controls[rowItem.dataKey].value;
      }
    public createLookUpOpt(item){
         this.lookUpOpts = [];
        let availRows = this.dataService.getRows();
        for(let i=0;i<availRows.length;i++){
            for(let j=0;j<availRows[i].value.length;j++){
                if(item.dataKey == availRows[i].value[j].dataKey){
                    if(this.lookUpOpts.indexOf(availRows[i].value[j].value) <0){
                        this.lookUpOpts.push(availRows[i].value[j].value)
                    }
                    
                }
            }
            
        }
        return true;
    }
    public filterOpt(val: string,col){
        // console.log(val);
        // console.log(arrayToBeFiltered);
        let arrayToBeFiltered = this.dataService.getLookupValues(col);
        // console.log(arrayToBeFiltered);
        return val ? arrayToBeFiltered.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
               : arrayToBeFiltered;
    }
    public checkForTrig(){
     return;
      }
    
 
    public setControlValue(val){
        this.defaultLookup = false;
        this.editLookUpControl.setValue(val)
    }
    public createDropDownOpt(item){
        this.DropDownOpts = [];
        let availRows = this.dataService.getRows();
         for(let i=0;i<availRows.length;i++){
            for(let j=0;j<availRows[i].value.length;j++){
                if(item.dataKey == availRows[i].value[j].dataKey){
                  if( this.DropDownOpts.indexOf(availRows[i].value[j].value)<0){ 
                    this.DropDownOpts.push(availRows[i].value[j].value)
                  }
                }
            }
            
        }
      return true;
    }
    public getEdittedRowValue(event){
        this.dataService.setGroupingVal([]);
        this.getEdittedRowIndex=event.defaultIndex;
        this.tabMode  ='editModeSwitch'
        this.editMode = true;
        
        this.endRowIndex=this.getEdittedRowIndex;
        this.startRowIndex=this.endRowIndex+1;
       this.openEdittedForm=true;
        this.edittingRow= this.dataService.getEdittedRow(event.currentRowIndex);
      
      this.colsForEditting = this.columns;
      this.rowBeingEditted = this.dataService.getEdittedRow(event.currentRowIndex);
      this.edittableFieldsObj = []
      for(let i=0;i<this.colsForEditting.length;i++){
          if(this.colsForEditting[i].isEdit){
              if(this.colsForEditting[i].columnType ==  ColumnType.DATE){
                this.rowBeingEditted.value[i].value = new Date(this.rowBeingEditted.value[i].value);
              }
              let dummy = {
                  value: this.rowBeingEditted.value[i].value,
                  colType: this.colsForEditting[i].columnType,
                  dataKey: this.rowBeingEditted.value[i].dataKey,
                  isEdit: this.rowBeingEditted.value[i].isEdit
              }
              this.edittableFieldsObj.push(dummy);
              
          }
      }
      let sliceRowHeight;
      sliceRowHeight=this.rowHeight.substring(0,2)
    //  this.editDivHeightStyle=(( sliceRowHeight)*this.edittableFieldsObj.length)+52; 

let quotient = Math.floor((this.edittableFieldsObj.length)/3);
let remainder =1;

let addEditaFieldObj=quotient +remainder;

    this.editDivHeightStyle=((53.63)*addEditaFieldObj)+77; 
     if(this.editDivHeightStyle>456){
        this.editDivHeightStyle=456;
     }
     this.editFieldForm=this.createForm();
     this.listOfSelectedRows=[];
    }
    
    public saveRowEdit (){
        for(let j=0;j<this.rowBeingEditted.value.length; j++){
                for(let i=0;i<this.edittableFieldsObj.length;i++){
                    if(this.edittableFieldsObj[i].dataKey == this.rowBeingEditted.value[j].dataKey){
                        if(this.edittableFieldsObj[i].colType == this.columnType.LOOK_UP && this.enableServerSideFilterLookup){
                            for(let item of this.EditServerSideLookup){
                                if(item.name == this.edittableFieldsObj[i].value){
                                    this.rowBeingEditted.value[i].value = item
                                }
                            }
                        }else{
                            this.rowBeingEditted.value[j].value =  this.edittableFieldsObj[i].value
                        }
                        
                    }
                }
            }
        this.dataService.saveEdittedRowData(this.rowBeingEditted,this.rowBeingEditted.index);
        
       
        this.saveEdittedRow.emit(this.dataService.saveRowCofigure(this.rowBeingEditted));
        for(let ele of this.rowBeingEditted.value){
            for(let item of this.edittableFieldsObj){
                if(item.dataKey == ele.dataKey){
                    if(item.colType == this.columnType.LOOK_UP && this.enableServerSideFilterLookup){
                        for(let opt of this.EditServerSideLookup){
                            if(opt.name == ele.value.name){
                                ele.value = item.value
                            }
                        }
                    }
                }
            }
        }
        this.dataService.saveEdittedRowData(this.rowBeingEditted,this.rowBeingEditted.index);

        this.getEdittedRowIndex = -1;
        this.endRowIndex=-1;
        this.startRowIndex=-1;
        this.editMode = false;
        this.openEdittedForm = false;
        this.tabMode = 'defaultMode'
        this.listOfSelectedRows=[];
        // for(let i in this.edittableFieldsObj[0]){
            
        // }
    }
    public cancleRowEdit(){
        this.getEdittedRowIndex = -1;
        this.endRowIndex=-1;
        this.startRowIndex=-1;
        this.editMode = false;
        this.openEdittedForm = false;
        this.tabMode = 'defaultMode'
    }
    public saveEdittedRowData(event){
        let rowToBeReturned = this.dataService.getEdittedRow(event);
           this.saveEdittedRow.emit(rowToBeReturned);
    }
    public tabModeEmitClick(event){
        this.tabMode = event;
        this.selectAllRowFlag=false;
        this.selectAllRow(this.selectAllRowFlag);
    }
    //table header checkbox click event
    public selectAllRow(event) {
        this.selectAllRowFlag = event;
        let selectingRows = [];
        
        if (this.selectAllRowFlag == true) {
            let pageStartIndex = this.arrayPaginationService.getStartIndex();
            if(this.rowsObj.length <  this.arrayPaginationService.itemsPerPage ){
                 this.arrayPaginationService.itemsPerPage = this.rowsObj.length;
            }
            let pageEndIndex = this.arrayPaginationService.getStartIndex() + this.arrayPaginationService.itemsPerPage - 1;
            for (let i = pageStartIndex; i <= pageEndIndex; i++) {
                let selRow = this.dataService.getEdittedRow(i)
                if(selRow){
                selectingRows.push(this.dataService.saveRowCofigure(selRow));
                }
            }
        }
        if (this.selectAllRowFlag == false) {
            selectingRows = [];
        }
        this.dataService.selectingAllRows(selectingRows);
        this.selRowsOutput(selectingRows);
        this.dataService.setRowSelectionobservable(selectingRows);
    }
    public saveEdittedCell(event){
        this.edittedCellVal.emit(event);
    }
       //Function for header collevel Apply All
    public colLevelFilter(event){
        this.dataService.setFilterlistApplied(event);
        this.colFilterOpt.emit(this.dataService.getFilterlistApplied())
    }
    //Function for header collevel Clear All
    public colLevelFilterWithOutServer(event){
        this.dataService.setFilterlistApplied(event);
        this.colFilterOptWithOutServer.emit(this.dataService.getFilterlistApplied())
    }
    
    public selRowsOutput(event) {
        this.listOfSelectedRows=[];
        this.listOfSelectedRows=event;
        this.rowsSelOpt.emit(event)
        // this.selectedRowClick = event;
        // if (event.checkTrigger.checked) {
        //     if (event.listOfSelRows.length > 1) {
        //         this.rowSelected = true;        
        //     }
          
        // }
        // else {
        //     this.rowSelected = false;
        // }
        
    }
    public groupingDisabled(){
        this.groupbyappliedFlag = false;
        this.tabMode  ='defaultMode';
        
    }
    
    public setFilterTrigerAt(event){
        this.filterTrigAt = event
    }
    
    public groupByEmitted(){
        this.groupByObservable = this.dataService.getObgForGrouping();
        this.tabMode  ='groupingMode'
        this.groupbyappliedFlag = true;
    }
    
    public openColConf(){
        let colList = this.dataService.getColumns();
        let self=this;
       let dialogRef = this.dialog.open(MdtColumnConfig, {
        height: '400px',
        width: '500px',
            data: colList
        });
        
        dialogRef.afterClosed().subscribe(result => {
            if (result ==""){
                self.columns = this.dataService.getColumns();
                }
                else {
                self.dataService.setSelectedColumns(result);
                self.columns =self.dataService.getColumns();
                } 
            });
        

    }
    public addRemoveData(event){
        this.groupEmitObj = event;
    }
    public checkIfGroupCollapse(item){
        if(!this.groupEmitObj){
            return false;
        }else{
            if(!this.groupEmitObj.panelCollapseOpt){
                return false
            }else{
                if(this.groupEmitObj.groupVal == item){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
    }
    public setMultiSelect(event){
        this.selectedFilterListCol = event;
    }

    public selectedAction(event){
        this.actionSelectedEvent.emit(event);
    }
    public ServerSorting(event){
        this.serverSortingOpt.emit(event);
    }
    public changeRowPerpage(event){
        this.selectAllRowFlag=false;
        this.selectAllRow(this.selectAllRowFlag);
    }
    public  paginationServerSide(event){
        this.serverPaginationOpt.emit(event);
    }
    public serverSideFilterLookupObjEmit(event){
        this.serverSideFilterLookupObj.emit(event);
    }
    public rowPerPageServer(event){
        this.serverRowsPerPage.emit(event);
        
    }


  //lnagpal
    // public CommunicationCategory(){ 
    //     this.clientService.setUrl('http://web-dev.swissre.com/webapp/cfc/ws/restApp/corflowClaim/REFDATA/COMMUNICATION_CATEGORY/')
    //   this.clientService.getClientData().subscribe(commCategory => {
    //        this.commCardCategory = commCategory;
    //        this.communicationCategoryLookupEmit(this.commCardCategory);
    //     });
        
    // }
  
    // public communicationCategoryLookupEmit(event){
    //     this.communicationCategoryLookup.emit(event);
    // }
  

    public CommunicationCategory() {
        let event:any={
            Refdata:"REFDATA",
            CommCategory:"COMMUNICATION_CATEGORY"
        }
        this.communicationCategoryLookup.emit(event);
    }
    // to store the index of hovered row
    public rowHoverTriggered(ind){
        this.hoverRowIndex = ind;
    }
    //to set the hover index to -1 so that highlight is addRemoveData
    public onMouseOutOfTable(){
        this.hoverRowIndex = -1;
    }

    //method to store recent row selection so as to send as input to the other table(sticky and no sticky)
    public rowRecentSelectEvent(event){
        this.mostRecentRowSelected = event;
        // let recentRowAsPerIpt = this.dataService.saveRowCofigure(event)
        this.MostRecentRowOpt.emit(this.mostRecentRowSelected);
    }
    //Soting the table rows on  sort header icon beside column preference 
    public sortingRows(colToSort,i){
        if (this.enableServerSideSorting == false) {
            this.sortService.setColumnToSort(colToSort);
            this.sortService.transformRows(this.dataService.getRows());
        }
        else {
            this.sortService.setServerColSorted(colToSort);
            this.sortService.changeSortdir(colToSort);
            let dummy = {
                colBeingSorted: this.dataService.getColAsPerInput(colToSort),
                direction: this.sortService.direction
            }
            // this.sortingServerSideEmit.emit(dummy);
            // console.log(dummy)
        }
    }
    public actioMenuEvent(event) {
        this.actionTriggerd = event;
        let ele = this.selectedRows;
        let  finalURL = "";
        let documentId="";
        documentId = this.selectedRows;
        switch (this.actionTriggerd) {
            case "Share":
                let locationUrl;
                if(this.selectedRows.length <=15){
                    for(let docId of documentId){
                            locationUrl = this.docUrl + "?docId=" + docId + "%26appName=NATIVE" + "%26externalApp=false" +"%0A";
                            finalURL  = finalURL+ locationUrl;
                    } 
                let mywindo = this.winref.open('mailto:?subject=Copy Document Link(s)&Body=Location URL : ' + finalURL ,  "target='_blank'");
                        setTimeout(() => {
                            mywindo.close();
                        }, 50);
                    } else{
                        this.snackBar.open("Maximum selection for share(15) reached", 'Close', {
                            duration: 5000,
                        });
                    }
                break;
            case "Download":
            for(let docId of documentId){
                            this.winref.open(this.docUrl + "?docId=" + docId + "&appName=NATIVE&verNo=" + "&externalApp=false");
            }

                break;
            case "Delete":
         
                break;
            case "Attach":
                break;
        }
    }
}