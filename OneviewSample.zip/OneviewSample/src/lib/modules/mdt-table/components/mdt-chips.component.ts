import {Component, Input,Output, EventEmitter, Inject} from "@angular/core";
// import { ENTER} from '@angular/material';

import { DataService } from './../services/DataService';

@Component({
    selector: 'mdt-chips',
    styleUrls:['../main.scss'],
    templateUrl: '../views/mdt-chips.html',
})
export class MdtChips {
    private hideChipHead:boolean=false;
  @Input() selectedFil;
  
    
    constructor(@Inject(DataService) public dataService:DataService){
    }
     ngOnChanges(){
       
         if(this.selectedFil){
         }
     }
     remove(filterDataRemove,$event) {
         if(this.selectedFil.filterValData.length>0){
             this.hideChipHead=false;
             this.selectedFil.filterValData.splice(this.selectedFil.filterValData.indexOf(filterDataRemove), 1);
             $event.stopPropagation();
         }
         else{
              this.hideChipHead=true;
         }
         
    }

}