import { NgModule, Input, ChangeDetectorRef, OnDestroy,Component,Output, EventEmitter,OnInit, Inject} from '@angular/core';
import { FormControl } from '@angular/forms';
import { NgModel } from '@angular/forms/src/directives';

import {MdtCellAlign} from "../directives/mdt-cell-align.directive";
import {MdtCellDoubleClick} from "../directives/mdt-cell-doubleClick.directive";
import {ColumnType} from "../enums/ColumnType";
import { IColumn } from './../interfaces/IColumn';
import {ArrayPaginationService} from "../services/ArrayPaginationService";
import {DataService} from "../services/DataService";
import{ environment } from '../../../../environments/environment';
import{WindowRef} from"../../../../app/services/WindowRef.service";

import 'rxjs/add/operator/map'; 
import 'rxjs/add/operator/startWith';
import {Observable} from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: '[mdt-rows]',
    styleUrls: ['../main.scss'],
    templateUrl: '../views/mdt-rows.html',
})
export class MdtRows implements OnInit {
    @Input('rowType') rowType = "non-sticky";
    @Input() enableRowEdit: boolean;
    @Input() enableCheckbox: boolean;
    @Input() allRowSelected: boolean;
    @Input() rowHeight;
    @Input() groupingState;
    @Input() groupingObj;
    @Input() groupbyappliedFlag;
    @Input() groupVal;
    @Input() endRowIndex;
    @Input() tabMode;
    @Input() startRowIndex;
    @Input() openEdittedForm;
    @Input() checkappliedFlag;
    @Input() groupCollapse;
    @Input() enableEdit;
    @Input() enableAction:boolean;
    @Input() actionItems;
    @Input() actionMenu;
    @Input()  enableCellLevelEnabled:boolean;

     
     @Input() rowHoverIndex:any;    // input for synch between sticky and non sticky on hover
     @Input() mostRecentRow:any;    //input to hold the most recent row selected
    
    @Output() groupingData: EventEmitter<any> = new EventEmitter();
    @Output() editRowData: EventEmitter<any> = new EventEmitter();
    @Output() saveRowData: EventEmitter<any> = new EventEmitter();
    @Output() edittedCellData: EventEmitter<any> = new EventEmitter();
    @Output() selectedRowsOpt: EventEmitter<any> = new EventEmitter();
    @Output() selectedActionOpt: EventEmitter<any> = new EventEmitter();
    @Output() RowClickData: EventEmitter<any> = new EventEmitter();

    // output events for synch betweent sticky and non sticky on hover
    @Output() rowHoverEvent: EventEmitter<any> = new EventEmitter();
    @Output() recentRowSelectEvent: EventEmitter<any>= new EventEmitter(); // event to emit most resent selected row

    columnType = ColumnType;
    actionMenuRef:any;
    actionMenuTriggerIndex:any=-1;
    tabRows: any = [];
    editMode: boolean = false;
    editRowIndex: number = -1;
    private listOfSelRows: any = [];
    private winref: any;
    private groupByObservable: any;
    private filteredOpts: any;
    private lookUpOpts: any = [];
    private panelCollapseOpt: boolean = false;
    private groupStatusObj: any = {
        panelCollapseOpt: this.panelCollapseOpt,
        groupVal: this.groupVal
    }

    
    private groupCollapseBoolean: boolean = false;
    private rowAllChecked:boolean=false;
    private selectedAll:any=[];
    private  selectedAllBooleanVals:any=[];
    private checkedAll:boolean=false;
    private groupByValues: any = [];
    private selectedRowValue:any=[];
    private checkStatusList:any=[];
    private docUrl:any;
    public subscription:any;
    private actionFavButton:boolean=false;
    private listOfActionItemIcon = ["mode_edit","visibility","share","file_download","delete","info","attach_file"];
    private menuTriggerIndex:any;
     editLookUpControl: FormControl;

    constructor(@Inject(DataService) public dataService: DataService, 
    @Inject(ArrayPaginationService)  protected arrayPaginationService: ArrayPaginationService,
    @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef,
    @Inject(WindowRef) private winRef: WindowRef) {
        this.docUrl = environment.DocURL;
        this.winref = winRef.nativeWindow;
        this.tabRows = this.dataService.getRows();
        // console.log("==="+this.tabMode)


        this.editLookUpControl = new FormControl();
        let self = this;
        this.dataService.getAllRows().subscribe(function (res) {
            self.listOfSelRows = res;
            self.checkStatusList =[];
            for(let item of self.listOfSelRows){
                self.checkStatusList.push(true);
            }
        })
this.subscription=this.dataService.getSortingCol().subscribe(function (res) {
            self.listOfSelRows=[];
            for(let item of self.listOfSelRows){
                self.checkStatusList.push(false);
            }
        });
      
    }
    ngOnInit(){
        this.filteredOpts = this.editLookUpControl.valueChanges
        .startWith(' ')
        .map(name => this.filterOpt(name, this.lookUpOpts))
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
      }
    getColumns() {

        if (this.rowType == 'sticky') {


            return this.dataService.getColumns().slice(0, 1);
        }


        else {
            return this.dataService.getColumns().slice(1, this.dataService.getColumns().length);
        }
    }
    ngAfterViewChecked()
    {
    this.ref.detectChanges();
    } 
    ngOnChanges() {
        if (!this.rowHeight) {
            this.rowHeight = '30px'
        } else {
            this.rowHeight = this.rowHeight ;
        }
        if (!this.openEdittedForm) {
            this.editRowIndex = -1
        }
        if (this.groupCollapse && this.groupCollapse.panelCollapseOpt) {
            this.groupCollapseBoolean = true;
        }
        else {
            this.groupCollapseBoolean = false;
        }

    }

    public filterOpt(val: string, arrayToBeFiltered) {
        return val ? arrayToBeFiltered.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
            : arrayToBeFiltered;
    }

    public openEditMode(crntRow,crntRowIndex) {
        this.editMode = true;
        this.editRowIndex = crntRowIndex;
        this.recentRowSelectEvent.emit(crntRow);
        this.dataService.setRowToEdit(crntRow);
        this.editRowData.emit({defaultIndex:this.editRowIndex,currentRowIndex:crntRow.index})
    }
    public saveEdittedData(val) {
        this.editMode = false;
        this.dataService.setRowToEdit(-1);
        // this.dataService.saveEdittedRowData(this.tabRows[this.editRowIndex],this.editRowIndex);
        // to change the rows from parent page
        this.saveRowData.emit(this.editRowIndex);
        this.editRowIndex = -1;
    }

    public saveCellData(rowIndex, colIndex, cellvalue) {
        this.editRowIndex = rowIndex;
        this.dataService.saveCellData(rowIndex, colIndex, cellvalue);
        this.saveRowData.emit(this.editRowIndex);
        let edittedRow = this.dataService.getEdittedRow(this.editRowIndex);
        this.edittedCellData.emit(edittedRow.value[colIndex]);
        this.editRowIndex = -1;
    }

    public checkFun(rowInd, colInd) {
    }
    //below code must be optimised
    //checkbox event for table
    public rowSelChanged(aRow,ind, event) {
        let documentId="";
    //     for(let ele of aRow.value){
    //     if (aRow.value[ele].dataKey == "DOC_ID") {
    //         let documentId = aRow.value.value;
    //         console.log(documentId)
    //     }
    // }
    for (let docId of aRow.value) {
        if (docId.dataKey == "DOC_ID") {
            documentId = docId.value;
        }
    }
        let selectedRowVal = this.dataService.getEdittedRow(ind);
        this.checkStatusList[ind] = event.checked;
        if (event.checked) {
        let list =    this.listOfSelRows.push(documentId);
                                              
        } else {
            this.listOfSelRows.splice(this.listOfSelRows.indexOf(documentId),1);
        }
        this.dataService.setRowSelectionobservable(this.listOfSelRows); 
        this.selectedRowsOpt.emit(this.listOfSelRows);
        this.ref.detectChanges();
    }
    public createLookUpOpt(aColumn) {
        // let dummy;

        // dummy={
        //     dataKey:aColumn.dataKey,
        // }
        // console.log(dummy);
        this.lookUpOpts = this.dataService.getLookupValues(aColumn);
        return true;

    }
    public addRemoveData(event) {
        this.groupingData.emit(event);
    }
    public checkIfRowMatchesGroupHeader(val) {
        let listOfCollopsed = this.dataService.getGroupCollapsedList();
        if (!this.groupbyappliedFlag) {
            return !!this.groupbyappliedFlag;
        } else {
            let dummy = val.value;
            if (this.panelCollapseOpt) {
                return false;
            }
            else {
                for (let i = 0; i < dummy.length; i++) {
                    if (dummy[i].dataKey == this.groupingObj.dataKey) {
                        if (dummy[i].value == this.groupVal) {
                            if(listOfCollopsed.indexOf(dummy[i].value)<0){
                                return true;
                            }else{
                                return false;
                            }
                            
                        } else {
                            return false;
                        }
                    }
                }
            }
        }

    }
    public checkIfRowClickedOnEdit(val) {
        if (this.checkappliedFlag) {
            if (val >= this.startRowIndex || val <= this.endRowIndex) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }

    }

    public panelCollpase() {
        this.panelCollapseOpt = !this.panelCollapseOpt;
        let listOfCollapsed = this.dataService.getGroupCollapsedList();
        let dummy = {
            panelCollapseOpt: this.panelCollapseOpt,
            groupVal: this.groupVal,

        }
        this.groupStatusObj = {
            panelCollapseOpt: this.panelCollapseOpt,
            groupVal: this.groupVal
        }


        if (this.panelCollapseOpt) {
            if (listOfCollapsed.indexOf(this.groupVal) < 0) {
                listOfCollapsed.push(this.groupVal);
            }

        } else {
            if (listOfCollapsed.indexOf(this.groupVal) >= 0) {
                listOfCollapsed.splice(listOfCollapsed.indexOf(this.groupVal), 1)
            }
        }
        this.dataService.setGroupCollapsedList(listOfCollapsed);
        this.groupingData.emit(dummy);
    }
    public checkForColl(row) {
        // for(let item of this.dataService.getGroupCollapsedList()){
        //     if(row.value[this.groupingObj.dataKey].value == item){
        //         return false
        //     }
        // }
        // return true

        for (let i = 0; i < row.value.length; i++) {
            if (row.value[i].dataKey == this.groupingObj.dataKey) {
                let listOfCollapsed = this.dataService.getGroupCollapsedList();
                for (let j = 0; j < listOfCollapsed.length; j++) {
                    if (row.value[i].value == listOfCollapsed[j]) {
                        // console.log(row.value[i].value)
                        return false
                    }
                }

            }


        }
    }
    public checkIfCollapsed(row){
        let rowNotCollapsed = true;
        let listOfCollapsed = this.dataService.getGroupCollapsedList();
        for(let item of listOfCollapsed){
            for(let ele of row.value){
                if(ele.value ==item){
                    rowNotCollapsed = false;
                }
            }

        }
        return rowNotCollapsed
    }

    public actionSelected(actn, row) {
        let documentId
        let evntObj = {
            actionItem:actn,
            row:row
        }
        for (let i = 0; i < row.value.length; i++) {
            if (row.value[i].dataKey == "DOC_ID") {
                documentId = row.value[i].value;
            }
        }
        switch (actn) {
            case "Edit":
                break;
            case "View":
                this.winref.open(this.docUrl + "?docId=" + documentId + "&verNo=" + "&appName=NATIVE&openInline=Y");
                break;
            case "Share":
           let  locationUrl = this.docUrl + "?docId=" + documentId + "%26appName=NATIVE" + "%26externalApp=false" +"%0A";
                let mywindo = this.winref.open('mailto:?subject=Copy Document Link(s)&Body=Location URL : ' + locationUrl, + '%0A' + "target='_blank'");

                setTimeout(() => {
                    mywindo.close();
                }, 50);
                break;
            case "Download":
                this.winref.open(this.docUrl + "?docId=" + documentId + "&appName=NATIVE&verNo=" + "&externalApp=false");
                break;
            case "Delete":
                break;
            case "Additional Info":
                this.selectedActionOpt.emit(evntObj);
                break;
            case "Attach":
                break;
        }


    }
   public checkCol(){
          let col =  this.dataService.getColumns();
          if(col && col.length <=2){
            for(let item of col){
                if(item.columnType ==ColumnType.PRIMARYKEY  ){
                    return true
                }
            }
          }
          return false
         
       
      }
   

    public rowClick(row,column){
        let clickValue={
            column: this.dataService.getColAsPerInput(column),
            row:this.dataService.saveRowCofigure(row),
            clickValue:this.dataService.getCellData(column, row).value
        }
         this.RowClickData.emit(clickValue);
    }
    public saveCellDataClick(column, row,cellselected){
       let dummy=this.dataService.saveCellData(column, row,cellselected);
     this.edittedCellData.emit(dummy)
   }
   
//    method to emit event on row hover
public onRowHover(rowHovered){
    this.rowHoverEvent.emit(rowHovered.index)
}

//method to emit the recent row
public onRowClick(row){
    let documentId="";
    for (let i = 0; i < row.value.length; i++) {
       if(row.value[i].dataKey=="DOC_ID"){
        documentId=row.value[i].value;
       }
    }
    this.recentRowSelectEvent.emit(documentId);
}
public actionMenuTriggered(menuRef,menTrigInd){
    
    if(menTrigInd != this.actionMenuTriggerIndex && this.actionMenuRef){
        this.actionMenuRef.closeMenu();
    }
    this.actionMenuTriggerIndex = menTrigInd;
    this.actionMenuRef = menuRef;
}
public closeActionMenu(){
    if(this.actionMenuRef){
        this.actionMenuRef.closeMenu();
        this.ref.detectChanges();
    }
    
}

}
