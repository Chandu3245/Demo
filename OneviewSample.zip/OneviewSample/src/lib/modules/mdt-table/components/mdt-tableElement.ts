// import {Component,Input} from '@angular/core';
// import {ColumnType} from "../enums/ColumnType";
// import {FormControl} from '@angular/forms';

// @Component({
//   selector: 'table-element',
//   templateUrl: '../views/mdt-tableElement.html',
  
// })
// export class TableElement {
//     private ColumnType = ColumnType;
//  @Input('ColumnType') ColumnType;
  
// //      stateCtrl: tableControl;

// // states = [
// //     'Alabama',
// //     'Alaska',
// //     'Arizona',
// //     'Arkansas',
// //     'California',
// //     'Colorado',
// //     'Connecticut',
// //     'Delaware',
// //     'Florida',
// // ]
//   constructor() {
      
//     console.log("creating table component");
//     //this.stateCtrl = new tableControl();
//   }
   
// }