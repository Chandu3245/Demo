import { Component, Input, Output, EventEmitter, OnChanges, DoCheck, OnInit, ChangeDetectorRef,Inject} from "@angular/core";
import { FormControl } from '@angular/forms';

import { MdtCellAlign } from "../directives/mdt-cell-align.directive";
import  { ColumnType }  from  "../enums/ColumnType";
import { IColumn } from "../interfaces/IColumn";
import { ArrayPaginationService } from "../services/ArrayPaginationService";
import { DataService } from "../services/DataService";
import { SortService } from "../services/SortService";

import  { Observable }  from  'rxjs/Observable';
import  'rxjs/add/operator/startWith';
import  'rxjs/add/operator/map';

@Component({
    selector: '[mdt-columns]',
    styleUrls: ['../main.scss'],
    templateUrl: '../views/mdt-columns.html',
})
export class MdtColumns implements OnInit {

    @Input() enableFilter;
    @Input() enableRowEdit: boolean;
    @Input() enableCheckbox: boolean;
    @Input('columnType') columnType = "non-sticky";
    @Input() colHeight;
    @Input() groupedFlag;
    @Input() filterTriggeredAt;
    @Input() enableFilterMode: boolean;
    @Input() enableGroupingMode: boolean;
    @Input() enableColDrag: boolean;
    @Input() enableAction: boolean;
    @Input() enableServerSideSorting;
    @Input() enableServerSideFilterLookup: any;
    @Input() serverSideFilterLookupValues: any;

    @Output() sortingServerSideEmit: EventEmitter<any> = new EventEmitter();
    @Output() serverSideFilterLookupObj: EventEmitter<any> = new EventEmitter();

    @Output() filterOutput: EventEmitter<any> = new EventEmitter();
    @Output() selectAllChanged: EventEmitter<any> = new EventEmitter();
    @Output() colLevelFilter: EventEmitter<any> = new EventEmitter();
    @Output() groupByColOpt: EventEmitter<any> = new EventEmitter();
    @Output() groupingDis: EventEmitter<any> = new EventEmitter();
    @Output() colMultiSelectOpt: EventEmitter<any> = new EventEmitter();
    @Output() colMultiSelectOptLabel: EventEmitter<any> = new EventEmitter();
    @Output() selectedFilterOpt: EventEmitter<any> = new EventEmitter();
    @Output() selectedFilterOptWithOutServer: EventEmitter<any> = new EventEmitter();
    

    ColType = ColumnType;
    public checked: boolean = false;
    private filterList: any = [];
    private colList: any = [];
    private groupFlag: boolean;
    private groupByObservable: any = {
        'dataKey': '',
        'header': '',
        'values': ''
    };
    private groupingVals:any=[];
    private colFilterDebList: any = [];
    private colFilterCtrl: FormControl;
    private colFilter: any;
    private filteredOpts: Observable<string[]>;
    private lookUpOpts: any = [];
    private toggleId: boolean = false;
    private filteringDuplicates: any = [];
    private actionIndex: any;
    private selectedFilterArray = [];
    private displayId: boolean = false;
    private enableFilterIcon: boolean = false;
    private togglePopUp: boolean = false;
    private selectAllRows: boolean = false;
    private selectAllCheck: boolean = false;
    private openedfilterat: string = ''
    private groupedBycol: any;
    message: any;
    // subscription: Subscription;
    private filtersApplied: any = [];
    private groupApplied:any=[];
    private selRowsCount: any = [];
    private selrowLength: any;
    private listOfSelRows: any = [];
    // private stopProp:boolean=false;
    private displayIdDiv: boolean = false;
    constructor( @Inject(DataService) public dataService: DataService,
        @Inject(ArrayPaginationService) public arrayPaginationService: ArrayPaginationService,
        @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef,
        @Inject(SortService) public sortService: SortService) {
        let self = this;
        this.colList = this.dataService.getColumns();
        for (let i = 0; i < this.colList.length; i++) {
            this.filterList.push('');
        }
        this.colFilterDebList = this.filterList;
        this.dataService.getGroupByObserver().subscribe(function (res) {
            self.groupByObservable = res;
            self.groupFlag = res.groupingFlag;
        })
        this.dataService.getRowSelectioinObservable().subscribe(function (res) {
            self.selRowsCount = res;
            if (self.selRowsCount.length < self.arrayPaginationService.itemsPerPage) {
                self.checked = false;
                self.selectAllCheck = false;
                self.selectAllRows = false;
            } else {
                self.checked = true;
                self.selectAllCheck = true;
                self.selectAllRows = true;
            }
        })
    }
    ngOnInit() {
        this.colFilterCtrl = new FormControl();
        this.filteredOpts = this.colFilterCtrl.valueChanges
            .startWith(' ')
            .map(name => this.filterOpt(name, this.lookUpOpts))
    }


    // ngDoCheck(){
    //     if(document.getElementById("myDropdown") && !this.stopProp){
    //         let self = this;
    //         document.getElementById("myDropdown").addEventListener('click', function (event) {
    //             event.stopPropagation();
    //             self.stopProp = true
    //         });
    //     }
    // }

    ngOnChanges() {
        if (!this.colHeight) {
            this.colHeight = '56px'
        } else {
            this.colHeight = this.colHeight + 'px'
        }
        if (this.groupedFlag) {
            this.groupFlag = this.groupedFlag;
        }
    }


    public filterOpt(val: string, arrayToBeFiltered) {
        if (val && val.length >= 1) {
            return arrayToBeFiltered.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
        } else {
            return [];
        }
        // return val ? arrayToBeFiltered.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
        //        : arrayToBeFiltered;
    }
    setColumnOrder(aColumn: IColumn) {
        this.sortService.setColumnToSort(aColumn);
    }
    onDrop($event: any, aColumn: IColumn) {
        var dropColumn = $event;
        var temp = aColumn;
        this.dataService.swapItem(aColumn, $event, this.dataService.getColumns())

    }


    // below method moved to service

    // swapItem(source: any, target: IColumn, list: Array<any>) {


    //     let sourceIndex = list.map((e) => {
    //         return e.dataKey
    //     }).indexOf(source.dataKey);

    //     let targetIndex = list.map((e) => {
    //         return e.dataKey
    //     }).indexOf(target.dataKey);

    //     var b = list[sourceIndex];
    //     list[sourceIndex] = list[targetIndex];
    //     list[targetIndex] = b;

    // }
    getColumns() {

        if (this.columnType == 'sticky') { return this.dataService.getColumns().slice(0, 1); }


        else {
            return this.dataService.getColumns().slice(1, this.dataService.getColumns().length);
        }
    }
    public  sortCol(colToSort) {
        if (this.enableServerSideSorting == false) {
            this.sortService.setColumnToSort(colToSort);
            this.sortService.transformRows(this.dataService.getRows());
        }
        else {
            this.sortService.setServerColSorted(colToSort);
            this.sortService.changeSortdir(colToSort);
            let dummy = {
                colBeingSorted: this.dataService.getColAsPerInput(colToSort),
                direction: this.sortService.direction
            }
            this.sortingServerSideEmit.emit(dummy);
        }

        this.dataService.setSortingCol(colToSort);
    }
    public selectAll() {
        this.checked = !this.checked;
        this.selectAllChanged.emit(this.checked);
        this.ref.detectChanges();
    }
    public setColFilter(ind, col) {
        let colFilter = {
            filterVal: this.filterList[ind],
            colObj: this.dataService.getColAsPerInput(col)
        }
        this.colLevelFilter.emit(colFilter);
    }

    public groupByColumn(aCol) {
        this.groupFlag = true;
        this.actionIndex = -1;
        this.dataService.setAvailableGroupByVals(aCol, this.groupFlag);
        this.groupByColOpt.emit();
        this.groupingVals=this.groupByObservable;
       this.dataService.setGroupingVal(this.groupingVals);
    }
    public disableGrouping(aCol) {
        this.groupFlag = false;
        this.actionIndex = -1;
        this.groupingDis.emit();
        this.groupApplied=this.dataService.getGroupingVal();
        
        this.dataService.setGroupingVal([]);
    }

    public createLookUpOpt(col, val) {

        this.filteringDuplicates = [];
        if (!this.enableServerSideFilterLookup) {
            this.lookUpOpts = this.dataService.getColValues(col);
        } else {
            this.lookUpOpts = this.serverSideFilterLookupValues;
        }
        this.filteredOpts = this.colFilterCtrl.valueChanges.startWith(null)
            .map(name => this.filterOpt(name, this.lookUpOpts))

    }

    public myFunction(i,aCol) {
        this.groupApplied=this.dataService.getGroupingVal();
            if (this.groupApplied.dataKey== aCol.dataKey) {
               this.groupFlag=true;
            }else{
               this.groupFlag=false;
            }
        
        this.actionIndex = i;
        this.toggleId = true;
        this.displayId = false;
    }

    public displayFiltrValues(i, col) {
        this.serverSideFilterLookupObj.emit(this.dataService.getColAsPerInput(col));
        this.selectedFilterArray = [];
        this.colFilter = {
            filterValData: this.selectedFilterArray,
            colObj: ''
        }

        this.filtersApplied = this.dataService.getFilterlistApplied();
        for (let fltr of this.filtersApplied) {
            if (fltr.colObj && fltr.colObj.name == col.name) {
                this.colFilter = fltr;
                this.selectedFilterArray = fltr.filterValData;
            }
        }

        if (this.displayId && this.actionIndex == i) {
            this.displayId = false;
            this.actionIndex = -1;
        } else {
            this.displayId = true;
            this.actionIndex = i;
        }

        this.toggleId = false;
        this.openedfilterat = this.columnType;
        this.filterOutput.emit(this.openedfilterat);



        this.colFilterCtrl["_value"] = '';

    }
    public checkIfFilterApplied(col) {
        let appliedListOfFilters = this.dataService.getFilterlistApplied();

        for (let fltr of appliedListOfFilters) {
            // console.log("applied")


            if (fltr.colObj && fltr.colObj.name == col.name && fltr.filterValData.length > 0) {
                return true;
            }

        }
    }
    //css for grouping icon
    public checkGroupApplied(col){
        let groupColApplied =this.dataService.getGroupingVal();
        if (groupColApplied.dataKey== col.dataKey ) {
         return true;
        }
    }
    public select(opts, ind, col) {
        if (this.selectedFilterArray.indexOf(opts) < 0) {
            this.selectedFilterArray.push(opts);
        }
        this.colFilter = {
            filterValData: this.selectedFilterArray,
            colObj: this.dataService.getColAsPerInput(col)
        }
        this.colMultiSelectOpt.emit(this.colFilter);
        this.colFilterCtrl.setValue('');
    }
    public buttonFilterPopUpClose(ind) {
        this.displayId = false;
    }
    public filterPopUpApply(ind, col) {
        // console.log(ind+"===="+col)
        this.displayId = false;
        this.colFilter = {
            filterValData: this.selectedFilterArray,
            colObj: this.dataService.getColAsPerInput(col)
        }
        this.selectedFilterOpt.emit(this.colFilter)

    }
    public filterPopUpClear(ind, col) {
        this.colFilter.filterValData.splice(0, this.colFilter.filterValData.length);
        //this.filterColorChange = false;
        if (!this.enableServerSideFilterLookup) {
            this.selectedFilterOptWithOutServer.emit(this.colFilter)
        }
        else{
            this.selectedFilterOpt.emit(this.colFilter)
        }
        this.displayId = false;

    }
    public getCellIndex(ind, col) {
        this.selectedFilterArray = [];
        let colFilter = {
            filterValData: this.selectedFilterArray,
            colObj: this.dataService.getColAsPerInput(col)
        }
        this.colMultiSelectOpt.emit(colFilter);
    }

}