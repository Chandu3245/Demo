import {Injectable,Inject} from "@angular/core";
import { Http } from '@angular/http';

import {ArrayPaginationService} from "./ArrayPaginationService";
import {AlignRule} from "../enums/AlignRule";
import {ColumnType} from "../enums/ColumnType";
import {IColumn} from "../interfaces/IColumn";
import {IRow} from "../interfaces/IRow";
import {ICell} from "../interfaces/ICell";
import * as _ from "lodash";
import {Column} from "../models/Column";
import {SortService} from "./SortService";

import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class DataService {
    private columns: Array<IColumn>;
    private rows: Array<IRow>;
    private groupByValuesAvailable: Array<any> = [];
    private groupByColHeader: string;
    private objForGrouping: any;
    private selectedColumns: Array<IColumn>;
    private AvailableColumns: Array<IColumn>; 
    private listOfGroupCollapsed:any =[];
    private columnListSet: any;
    private rowListSet: any;
    public rowsConfigure:any= [];
    public columnConfigure:any =[];
    public saveConfig :any=[];
    public saveCellEdit : any;
    private pathOfImage:any;
    private imagePathUrl:any;
    private imageUrl:String;
    private dataUrl:any;
    
      private selectedValues: Subject<any> = new Subject();
    private selValues: Subject<any> = new Subject();
    private groupByRows: Subject<any> = new Subject();
    private groupByObj: Subject<any> = new Subject();
    private groupByCheckBox: Subject<any> = new Subject();
    private sortedValues: Subject<any> = new Subject();
  private listofAppliedFilter:any=[];
  private groupingByCol:any=[];
    constructor(@Inject (ArrayPaginationService )private arrayPaginationService: ArrayPaginationService,
    @Inject (SortService) private sortService: SortService, @Inject(Http) private http:Http) {

        this.columns = [];
        this.rows = [];
    }

    configureRows(rows:any){
        let rowValue: any = [];
        let keyArray: any = [];
        let valueArray: any = [];
        let rowObject = {};
        let dummy=[];
        
        for (let i = 0; i < rows.length; i++) {
            keyArray = [];
            valueArray = [];
            for (var name in rows[i]) {
                keyArray.push(rows[i][name].dbColumnName);
                valueArray.push(rows[i][name].value);
            }
            rowObject = {};
            keyArray.forEach((key, i) => rowObject[key] = valueArray[i]);
            rowValue.push(rowObject);

        }
        this.rowListSet = rowValue;
        this.rowsConfigure = rows;
        return this.rowListSet;
    }

    public findColType(val){
        let colType;

        switch(val){
            case 'TEXT':
            case 'TEXTCOLUMN':{
                colType = ColumnType.TEXT;
                break;
            }

            case 'CLICKABLECOLUMN':{
                colType = ColumnType.CLICKABLE;
                break;
            }
            case 'DATECOLUMN':
            case 'TIMESTAMPCOLUMN':
            case 'DATEBOX':{
                colType = ColumnType.DATE;
                // cols[i].isEdit = true;
                break;
            }
            case 'PREVIEWCOLUMN':{
                colType = ColumnType.ICON;
                break;
            }
            case 'LOCK_COLUMN':{
                colType = ColumnType.ICON;
                break;
            }

            case 'PRIMARYKEY':{
                colType =  ColumnType.PRIMARYKEY;
                break;
            }

            default:{
                colType = ColumnType.LOOK_UP;
                break
            }
        }

        return colType
    }
    configureColumns(cols:any){
        let dummy = {};
        let colType: any;
        let freezeBool: boolean = true;
        this.columnListSet = [];
        for (let i = 0; i < cols.length; i++) {
            colType = this.findColType(cols[i].type);
            dummy = {
                        dataKey: cols[i].dbColumnName,
                        name:cols[i].name,
                        isEdit: cols[i].isEditForTable,
                        align: AlignRule.Left,
                        isInEditMode:false,
                        columnType: colType,
                        isFreeze: freezeBool,
                        isGroupingAllowed:cols[i].isGroupingAllowed
                    }

           
            this.columnListSet.push(dummy);
            this.columnConfigure = cols;
        }
        return this.columnListSet;
    }
    public getColNameForEdit(dataKey){

        for(let col of this.columnListSet){
            if(col.dataKey == dataKey){
                return col.name;
            }
        }
    }

    addColumns(columns: Array<IColumn>) {
        this.columns= [];
        _.each(columns, (aColumn) => {
            let col = new Column();

            col.dataKey = aColumn.dataKey;
            col.name = aColumn.name;
            col.align = aColumn.align || AlignRule.Left;
            col.columnType = aColumn.columnType;
            col.isFreeze = aColumn.isFreeze;
            col.isEdit = aColumn.isEdit;
            col.isGroupingAllowed = aColumn.isGroupingAllowed;
            this.columns.push(col);
        });
        this.AvailableColumns = this.columns;
    }

    addRows(rows: Array<any>) {
        this.rows = [];
        _.each(rows, (aRow: any, rowIndex: number) => {
            var newRow: Array<ICell> = [];

            _.each(this.columns, (aColumn: IColumn) => {
                newRow.push({
                    dataKey: aColumn.dataKey,
                    value: aRow[aColumn.dataKey],
                    isEdit: false,
                    columnType: aRow[aColumn.columnType]
                });
            });

            this.rows.push({
                index: rowIndex,
                value: newRow
            });
        });
    }
    convertToDate(col,row){
        let val = this.getCellData(col,row);
        val.value = new Date(val.value);
        return val;
    }

    getCellData(column: IColumn, row: IRow) {
        
        return _.find(row.value, (aCell: ICell) => {
            return aCell.dataKey === column.dataKey
        });
    }
    //  getColumnType(column:IColumn, row:IRow){
    //     return _.find(row.value, (aCell:ICell) => {
    //         return aCell.ColumnType === column.ColumnType
    //     });
    // }

    getColumns() {
        return this.columns;
    }

    getRows(): Array<IRow> {
        //sorting rows
        let rows = this.sortService.transformRows(this.rows);

        //paginating rows
        rows = this.arrayPaginationService.transformRows(rows);

        return rows;
    }

    closeMdtContainer(column: IColumn, row: IRow) {
        _.find(row.value, (aCell: ICell) => {
            aCell.isEdit = false;
        });


    }

    getColValues(col) {
        let colValues = [];
        for (let i = 0; i <= this.rows.length; i++) {
            if (this.rows[i]) {
                for (let j = 0; j <= this.rows[i].value.length; j++) {
                    if (this.rows[i].value[j]) {
                        if (col.dataKey == this.rows[i].value[j].dataKey) {
                            if(colValues.indexOf(this.rows[i].value[j].value)<0){
                                colValues.push(this.rows[i].value[j].value);
                            }
                            
                        }
                    }
                    // if (col.dataKey == this.rows[i].value[j].dataKey) {
                    //     colValues.push(this.rows[i].value[j].value);
                    // }
                }
            }


        }
        return colValues;
    }
    
    public setImagePath(val) {
        this.imagePathUrl = val;
    }
    // public getImagePath(aColumn) {
    //     let dummyPath 
    //     if(aColumn.dataKey == "DOCUMENT_PREVIEW"  ){
    //         dummyPath= "/icon_adv_search.png";
    //     }else if(aColumn.dataKey == "ACQUIRED_IND"){
    //         dummyPath = "/user1_lock.png";
    //     }
    //     this.pathOfImage = this.imagePathUrl + dummyPath;
    //     return this.pathOfImage ;
    // }


    public getImagePath(aColumn, aRow,index) {
        let docName:any;
        if(aColumn && aRow){
            let imagePath 
            if(aColumn.dataKey == "DOCUMENT_PREVIEW"  ){
                imagePath= "/icon_adv_search.png";
            }else if(aColumn.dataKey == "ACQUIRED_IND"){
                imagePath = "/user1_lock.png";
            }
            let datalength = this.getRows();
          for(let i=0;i<datalength.length;i++){
         
            if(aRow.value[i] && aRow.value[i].dataKey== "DOCUMENT_NAME")
            {
             docName =aRow.value[i].value;
             this.checkimagetype(docName);
             imagePath =   this.imageUrl;
            // if(aColumn.dataKey == "DOCUMENT_IMAGE")
            // {
             
              
            //     }
            }
            }
             // this.imagePathUrl  ="images";
            // this.pathOfImage = this.imagePathUrl + dummyPath;
            // return this.pathOfImage ;
            return imagePath;
        }
    }
    private checkimagetype(docName){

     let lastIndex = docName.lastIndexOf('.');
     let docExtn = docName.substring((lastIndex + 1), docName.length);
     if (docExtn == 'pdf' || docExtn == 'PDF') {
        this.imageUrl = "./images/PDF_Icon.png";
     } else if (docExtn == 'eml' ) {
        this.imageUrl ="./images/EML_Icon.png";
    } 
    else if  (docExtn == 'doc' || docExtn == 'txt') { 
         this.imageUrl ="./images/DOC_Icon.png";
    } 
    else if (docExtn == 'ppt' || docExtn == 'pptx')  {
        this.imageUrl ="./images/PPT_Icon.png";
    } 
    else if (docExtn == 'xls' || docExtn == 'xlsx') {
        this.imageUrl ="./images/XLS_Icon.png";
    }  else {
        this.imageUrl ="./images/DOC_Icon.png";
    }
}


    saveCellData(col,row, cellVal) {
        let rowIndex = row.index
        for(let i=0;i<this.rows[rowIndex].value.length;i++){
            if(this.rows[rowIndex].value[i].dataKey == col.dataKey){
                this.rows[rowIndex].value[i].value = cellVal.value
                this.rows[rowIndex].value[i].isEdit = false;
            }
        }
        let dummy = {
            col: this.getColAsPerInput(col),
            row: this.saveRowCofigure(row)
        }
        this.saveCellEdit=dummy;
        return this.saveCellEdit;
    }



    getLookupValues(col?): Array<any> {
        
        let lookUpVal:any = [];
        if(!col){
            let lookUpList: Array<any> = [
            { value: '0', viewValue: 'Financial' },
            { value: '1', viewValue: 'FNOL' },
            { value: '2', viewValue: 'Status Update' }
        ];
        return lookUpList;
        }else{
            for(let i=0;i<this.rows.length;i++){
                for(let j=0;j<this.rows[i].value.length;j++){
                    if(col.dataKey ==  this.rows[i].value[j].dataKey){
                         if( lookUpVal.indexOf(this.rows[i].value[j].value)<0 && this.rows[i].value[j].value != ''){ 
                        lookUpVal.push(this.rows[i].value[j].value);
                         }
                        
                    }
                }
            }
            return lookUpVal;
        }
        
    }

    setRowToEdit(index) {
        for (let j = 0; j < this.rows.length; j++) {
            for (let k = 0; k < this.rows[j].value.length; k++) {
                //    this.rows[j].value[k].isEdit = false;
            }
        }
        if (index >= 0) {
            for (let i = 0; i < this.rows[index].value.length; i++) {
                // this.rows[index].value[i].isEdit = true;
            }
        }

    }
    saveEdittedRowData(rowData, ind) {
        this.rows[ind] = rowData;
    }
    //return the row in server format with attribute type
    saveRowCofigure(rowData) {
        this.saveConfig = [];
        for(let i=0;i<this.rowsConfigure[rowData.index].length;i++){
           if( this.rowsConfigure[rowData.index][i].value == rowData.value[i].value){
            this.rowsConfigure[rowData.index][i].value = rowData.value[i].value;
           }
            let objToReturn :any ={
                obj:this.rowsConfigure[rowData.index][i],
            }
           this.saveConfig.push(objToReturn)
        }
        
          return this.saveConfig;
    }

    getColAsPerInput(col){
        for(let item of this.columnConfigure){
            if(item.dbColumnName == col.dataKey){
                return item;
            }
        }
    }
    getEdittedRow(index) {
        return this.rows[index];
    }


    public setAvailableGroupByVals(val, groupingFlag) {
        //    this.groupByValuesAvailable = val;
        this.groupByValuesAvailable = [];
        this.groupByColHeader = val.name;
        for (let i = 0; i < this.rows.length; i++) {
            let crntRow = this.rows[i].value;
            for (let j = 0; j < crntRow.length; j++) {
                if (crntRow[j].dataKey == val.dataKey) {
                    if (this.groupByValuesAvailable.indexOf(crntRow[j].value) < 0) {
                        this.groupByValuesAvailable.push(crntRow[j].value);
                    }
                }
            }
        }
        let objForGrouping = {
            'dataKey': val.dataKey,
            'header': this.groupByColHeader,
            'values': this.groupByValuesAvailable,
            'groupingFlag' : groupingFlag
        }
        this.setGroupByObserver(objForGrouping);
        this.objForGrouping = objForGrouping;

    }
    public getAvailableGroupByVals() {
        return this.groupByValuesAvailable;
    }
    public getGroupByHeader() {
        return this.groupByColHeader;
    }
    setGroupByObserver(grpObj) {
        this.groupByObj.next(grpObj);
    }
    getGroupByObserver(): Observable<any> {
        return this.groupByObj.asObservable();
    }
    
    // public setRowSelectedByObservable(){
    //     this.selectedValues.next('');
    // }
    // public getRowSelectedByObservable(): Observable<any>{
    //     return this.selectedValues.asObservable();
    // }
    public setRowSelectionobservable(selectedrowvalues){
        this.selValues.next(selectedrowvalues);
    }
    public getRowSelectioinObservable(): Observable<any>{
        return this.selValues.asObservable();
    }
    public setSortingCol(sortValues){
        this.sortedValues.next(sortValues);
    }
    public getSortingCol(): Observable<any>{
        return this.sortedValues.asObservable();
    }
    selectingAllRows(selectedRows){
        this.groupByRows.next(selectedRows);
    }
    getAllRows(): Observable<any> {
        return this.groupByRows.asObservable();
    }
    
    getObgForGrouping() {
        return this.objForGrouping;
    }
    
    
    public setSelectedColumns(selColList){
        this.selectedColumns = selColList;
        if(this.selectedColumns  && this.selectedColumns.length>0){
            this.columns = this.selectedColumns;
        }
    }
    public getSelectedColumns(){
        
        if(this.selectedColumns && this.selectedColumns.length){
        return this.selectedColumns;        
        }
    }
    
    public getAvailableColumns(){
        return this.AvailableColumns;
    }
    public setAvailableColumns(cols){
        this.AvailableColumns = cols;
    }

    //0 = Available Columns, 1= Selected Columns
    swapItemList(source: any, targetArr: any[], list: Array<any>,colType) {
        let sourceIndex = list.map((e) => {
            return e.dataKey
            }).indexOf(source.dataKey);

            let firstSetOfList = list.slice(0,sourceIndex);;
            let secondSetOfList = list.slice(sourceIndex,list.length);
        for(let target of targetArr){


            if(firstSetOfList.indexOf(target)>=0){
                firstSetOfList.splice(firstSetOfList.indexOf(target,1));
            }
            else if(secondSetOfList.indexOf(target)>=0){
                secondSetOfList.splice(secondSetOfList.indexOf(target),1)
            }
        }
        list = firstSetOfList.concat(targetArr,secondSetOfList);
        if(colType ==0){
            this.AvailableColumns    = list;
        }else{
            this.selectedColumns    = list;
            this.columns = list
        }
        return list;
    }
    swapItem(source: any, target:any, list: Array<any>) {
        
        let sourceIndex = list.map((e) => {
        return e.dataKey
        }).indexOf(source.dataKey);
        
        let targetIndex = list.map((e) => {
        return e.dataKey
        }).indexOf(target.dataKey);
        
        var b = list[sourceIndex];
        list[sourceIndex] = list[targetIndex];
        list[targetIndex] = b;
        }
    
    saveColPreferences(availableColumns,selectedColumns){
        this.AvailableColumns = availableColumns;
        this.selectedColumns = selectedColumns;
        this.columns = this.selectedColumns;
    }
   public setGroupCollapsedList(list){
        this.listOfGroupCollapsed = list;
    }
    public getGroupCollapsedList(){
        return this.listOfGroupCollapsed;
    }
  public setFilterlistApplied(list){
    let colFilterdAlreday:boolean = false;
    for(let fltr of this.listofAppliedFilter){
        if(fltr.colObj == list.colObj){
            if(list.length>0){
                fltr = list;
                colFilterdAlreday = true;
            }else{
               this.listofAppliedFilter.splice(this.listofAppliedFilter.indexOf(list),1);
            }
            
            break;
        }
    }

    if(!colFilterdAlreday){
        this.listofAppliedFilter.push(list);
    }
    let dummy = this.listofAppliedFilter
    for(let i=0;i<this.listofAppliedFilter.length;i++){
        if(this.listofAppliedFilter[i].filterValData.length<=0){
            dummy.splice(i,1);
        }
    }
    this.listofAppliedFilter = dummy;
     
  }

  public getFilterlistApplied(){
  return  this.listofAppliedFilter;
  }

 public setGroupingVal(groupingVal){
    this.groupingByCol = groupingVal;
 }
 public getGroupingVal(){
    return  this.groupingByCol;
    }
  

}