import {SortDirection} from "../enums/SortDirection";
import {ICell} from "../interfaces/ICell";
import {IColumn} from "../interfaces/IColumn";
import {IRow} from "../interfaces/IRow";
import {ISortService} from "../interfaces/ISortService";

import * as _ from "lodash";

export class SortService implements ISortService{
    private columnToSort: IColumn;
    private isEnabled: boolean;
    public direction: SortDirection;
    private colBeingSorted:any;
    private serverSideColSorted:any;

    constructor(){
        this.direction = SortDirection.Ascending;
    }

    setColumnToSort(column: IColumn) :void{
        if(!column){
            return;
        }

        this.calculateSortDirection(column);

        this.columnToSort = column;
        // this.serverSideColSorted = column;
    }

    setServerColSorted(col){
        this.serverSideColSorted = col;
    }
    transformRows(rows: Array<IRow>):Array<IRow> {
        if(this.isSortingEnabled() == false || this.isSortingNeeded() == false){
            return rows;
        }

        let res;

        res = this.applySortOnColumn(rows);
        res = this.applySortDirection(res);

        return res;
    }

    isSortingNeeded(): boolean{
        return this.columnToSort != undefined;
    }

    isSortingEnabled(): boolean{
        return this.isEnabled;
    }

    setSortingEnabled(isEnabled: boolean): void{
        this.isEnabled = isEnabled ? true : false;
    }

    isSortedAscending():boolean {
        return this.direction == SortDirection.Ascending;
    }

    isSortedDescending():boolean {
        return this.direction == SortDirection.Descending;
    }

    isSortedByColumn(column:IColumn): boolean {
        if((this.columnToSort || this.serverSideColSorted)&& column){
            if(this.columnToSort){
                return this.columnToSort.dataKey == column.dataKey
            }else if(this.serverSideColSorted){
                return this.serverSideColSorted.dataKey == column.dataKey
            }
        }else{
            return false;
        }
    }

    private applySortOnColumn(rows:Array<IRow>): Array<IRow> {
        let res = _.sortBy(rows, (aRow:IRow) => {
            let index = _.findIndex(aRow.value, (cell:ICell) => {
                return cell.dataKey == this.columnToSort.dataKey;
            });

            return aRow.value[index].value;
        });

        return res;
    }

 calculateSortDirection(column:IColumn) {
        if(!this.columnToSort){
            this.direction = SortDirection.Ascending;
            return;
        }

        if(column.dataKey != this.columnToSort.dataKey){
            this.direction = SortDirection.Ascending;
        }else{
            this.direction = this.direction == SortDirection.Ascending ? SortDirection.Descending : SortDirection.Ascending;
        }
        return this.direction;
    }

    private applySortDirection(res:IRow[]) {
        if(this.direction == SortDirection.Descending){
            res = _.reverse(res);
        }
        return res;
    }
    //To only change the sort direction not to transform rows . sorting will be handled from server
    public changeSortdir(column){
        if(this.colBeingSorted){
            if(column.dataKey != this.colBeingSorted.dataKey){
                this.direction = SortDirection.Ascending;
                this.colBeingSorted = column
            }else{
                this.direction = this.direction == SortDirection.Ascending ? SortDirection.Descending : SortDirection.Ascending;
            }
        }else{
            this.direction = SortDirection.Ascending;
            this.colBeingSorted = column
        }
        
    }
}