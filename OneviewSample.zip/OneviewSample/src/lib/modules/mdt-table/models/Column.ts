import {AlignRule} from "../enums/AlignRule";
import {ColumnType} from "../enums/ColumnType";
import {IColumn} from "../interfaces/IColumn";

export class Column implements IColumn{
    dataKey: string;
    name: string;
    align: AlignRule;
    columnType:ColumnType;
    isInEditMode:boolean;
    isFreeze:boolean;
    isEdit:boolean;
    isGroupingAllowed:boolean;
    isLeftAligned():boolean {
        return this.align === AlignRule.Left;
    };

    isRightAligned():boolean {
        return this.align === AlignRule.Right;
    };
    
   
    
}