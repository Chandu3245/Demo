import {Input, Directive, ElementRef, Inject} from "@angular/core";

import {AlignRule} from "../enums/AlignRule";
import {IColumn} from "../interfaces/IColumn";

@Directive({
    selector: '[mdt-cell-align]'
})
export class MdtCellAlign {

    private el: HTMLElement;

    @Input('mdt-cell-align')
    aColumn: IColumn;

    constructor(@Inject(ElementRef) el: ElementRef){
        this.el = el.nativeElement;
    }

    ngOnInit(){
        switch(this.aColumn.align){
            case AlignRule.Left:
                this.el.classList.add('leftAlignedColumn');
                return;

            case AlignRule.Center:
                return;

            case AlignRule.Right:
                this.el.classList.add('rightAlignedColumn');
                return;

            default:
                throw new Error('Could not align because the align rule ('+this.aColumn.align+') was unknown.');
        }
    }
}