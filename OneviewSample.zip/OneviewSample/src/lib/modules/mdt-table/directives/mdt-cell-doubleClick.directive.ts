import {Input, Directive,HostListener, ElementRef, Inject} from "@angular/core";

import {ColumnType} from "../enums/ColumnType";
import {ICell} from "../interfaces/ICell";
import {IColumn} from "../interfaces/IColumn";

@Directive({
    selector: '[mdt-cell-double-click]'
})
export class MdtCellDoubleClick {

    private el: HTMLElement;
    private cellEditEnabled:boolean;
    @Input('mdt-cell-double-click')
    aColumn: IColumn;
     @Input('mdt-cell-value')
      aCell:ICell;
      @Input()  enableCellLevelEnabled:boolean;
      
    constructor(@Inject(ElementRef) el: ElementRef){
        this.el = el.nativeElement;
    }
@HostListener('dblclick', ['$event'])
  onDblClick(event) {
      this.cellEditEnabled = this.enableCellLevelEnabled;
      if(this.cellEditEnabled && this.aColumn.isEdit){
        switch(this.aColumn.columnType){
            
             case ColumnType.REFERENCE_DATA:
             case ColumnType.TEXT:
                this.aCell.isEdit=true;
                 return;
             case ColumnType.DATE:
                this.aCell.value =  new Date(this.aCell.value);
                this.aCell.isEdit=true;
                 return;
             case ColumnType.LOOK_UP:
                this.aCell.isEdit=true;
                 return;
             case ColumnType.DROP_DOWN:
                this.aCell.isEdit=true;
                 return;
              case ColumnType.ACTION:
                this.aCell.isEdit=true;
                 return;    
             default:
                 
         }
      }
      
  }
    
}