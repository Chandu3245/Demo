export const environment = {
  production: true,
  appURL: 'https://cordoc.swissreapps-np.com/c1v/ws/service/',
  DocURL : 'http://web.swissre.com/webapp/cs1/StreamingServlet',
};
