

import { transition } from '@angular/animations';
import { HttpClientModule } from '@angular/common/http';
import { Component, ChangeDetectorRef, Output, EventEmitter, Inject, Input ,OnChanges, OnInit, AfterViewInit} from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MatSnackBar } from '@angular/material';

import { ClientDataService, ShareDataService } from '../services';

import { environment } from '../../environments/environment';


@Component({
  selector: 'tree-comp',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss']
})
export class TreeComponent implements OnInit{
  private nodeVal:boolean= true;
  private breadCrumbs =[];
  private clickFavorite:boolean=false;
  private clearFieldValue: any = "";
  private listOfFavorite:any=[];
  private favItem:any;
  private infoValue:any;
  private appUrl:any = environment.appURL;
  private iconListtoOpen = ["add","add_circle_outline","expand_more"];
  private iconListtoClose = ["remove","remove_circle_outline","expand_less"];

  @Input() nodes;
  @Input() parent;
  @Input() enableCheckBox;
  @Input() singleModeSelection;
  @Input() typeofIcontoOpen;
  @Input() typeofIcontoClose;
  @Input() treeNodes;
  @Input() enableFavourities;
  @Input() filterTree;
  @Input() enableInputTree:boolean;
   @Input() enableInfoIcon;
   @Input() sourceSystem:any;
   @Input() insuredName:any;
  // @Input() state;

  @Output() listOfFavouritiesEmit: EventEmitter<any> = new EventEmitter();
    @Output() removeFavourities: EventEmitter<any> = new EventEmitter();
  
  
  
  constructor(@Inject(ShareDataService) private shareDataService: ShareDataService , @Inject(ClientDataService)private appService:ClientDataService) {
    //constructor body
     }
  
  
     ngOnInit() {
       //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
       //Add 'implements OnInit' to the class.
       
     }
  //Method to toggle the tree display
  onNodeToggle(node, event: any) {
    let nodeparent;
    node.isOpen = !node.isOpen
    if (node.isOpen) {
      for (let item of node.children) {
        item.isCheck = false;
        item.isOpen = false;
        item.isFavourite = false;
        nodeparent = node
        if (item.key == "INSURED_NAME") {
          item.parent = nodeparent;
        }
        nodeparent = item;
      }
    }
    if (node.isCheck) {
      for (let item of node.children) {
        item.isCheck = true;
      }
    }
  }

  //Method to handle  checkbox selection
  onNodeSelectionChange(clickedNode, currentNode, parent, event: any) {
    this.setBreadCrumbs(clickedNode, parent, 0);
    if (this.singleModeSelection) {

      for (let item of this.nodes) {
        let parentnode = item.parent;
        while (parentnode) {
          let root = parentnode.root;
          if (root) {
            let childrennode = parentnode.children;
            for (let child of childrennode) {
              let childnode = child.children;
              while (childnode && childnode.length > 0) {
                if (childnode[0].value == clickedNode.value && childnode[0].leaf) {
                  childnode[0].isCheck = event;

                }
                else {
                  childnode[0].isCheck = false;
                }
                childnode = childnode[0].children;
              }
              if (child.value == clickedNode.value) {
                child.isCheck = event;
                
              }
              else{
                child.isCheck = false;
              }
            }
          }
        
          parentnode= parentnode.parent;
      }
 
    }
    this.setBreadCrumbs(clickedNode,parent,1);
    }
   else{
     this.checkboxSelectionChange(clickedNode, currentNode,parent, event);
    }
  }
  private checkboxSelectionChange(clickedNode, currentNode,parent, event)
  {
    
    clickedNode.isCheck = event;
    clickedNode.parent = parent;
    if (currentNode.children && currentNode.children.length > 0) {
      currentNode.children.forEach(Childnode => {
        Childnode.isCheck = event;
        if (Childnode.children && Childnode.children.length > 0) {
          this.checkboxSelectionChange(clickedNode, Childnode, parent,event);
        }
      });
    }

    if (clickedNode.parent) {
      //node.parent.isIntermediate=true;
      let parentNode = clickedNode.parent;
     while (parentNode) {
      let result = this.ifAllChildSelected(parentNode, clickedNode, event);
      parentNode.isIntermediate = result.anyChildSelected;
       //  if(parentNode.isSelected!=isAllChildSelected){
        parentNode.isCheck = result.isAllSelected;
        // }
         parentNode = parentNode.parent;
      }

    }
    
  
  }

//method to check if all childs in tree are selected or not
  ifAllChildSelected(parentNode, clickedNode, event: any): any {
  
    let isAllSelected: boolean = true;
    let anyChildSelected: boolean = false;
    if (parentNode.children) {
      parentNode.children.forEach(childNode => {
        if (childNode.key === clickedNode.key && childNode.value === clickedNode.value ) {

          isAllSelected = isAllSelected && event;
          anyChildSelected = anyChildSelected || event;
        } else {
          isAllSelected = isAllSelected && childNode.isCheck;
          anyChildSelected = anyChildSelected || childNode.isCheck;
        }

      })
    }
    return { isAllSelected: isAllSelected, anyChildSelected: anyChildSelected };
  }

  //method to add the items to favourities
  private addToFavourities(node,item)
  {
    let self = this;
    let keyValue: any = [];
    let objKey: any[];
    var dict = []; // create an empty array

    node.isFavourite = true;
    if (this.shareDataService.getFavourities()) {
      this.listOfFavorite = this.shareDataService.getFavourities();
    }
    keyValue[node.key] = node.value;
    this.listOfFavorite.push(keyValue);
    this.shareDataService.setFavourities(this.listOfFavorite);
    this.shareDataService.setTreeByObserver(this.listOfFavorite);
    console.log(this.breadCrumbs);
    let favSaveUrl = this.appUrl + 'userPreference/saveUserFilters';
    this.breadCrumbs.push({'INSURED_NAME':this.insuredName})
    let objToPost:any={
      filterFlag:'F',
      sourceSystem:this.sourceSystem,
      filterData:JSON.stringify(this.breadCrumbs.reverse())
    }
    this.appService.setUrl(favSaveUrl);
    this.appService.PostClientData(objToPost).subscribe(res => {
      if(res.STATUS == 'SUCCESS'){
        let urlToGetFav = self.appUrl + 'userPreference/'+self.sourceSystem;
        self.appService.setUrl(urlToGetFav);
        self.appService.getClientData().subscribe(res =>{
          self.shareDataService.setFavList(res);
        })
      }
    });

  }

  //method to remove breadcrumbs from the list of favourities
  private removeFromFavourities(node, nodeVal) {
    let res = this.shareDataService.getFavourities();
    node.isFavourite = false;
    for (let i = 0; i < res.length; i++) {
      let temp1;
      let temp2;
      temp2=event;
      temp1=   Object.keys(res[i]);
      // temp2=   Object.keys( );
      // if(res[i][temp1[0]] ==nodeVal )
      if(temp1==node.key)
     {
         res.splice(i,1);
         break;
    }
  }
    // this.shareDataService.setFavourities(res);
     this.shareDataService.setTreeByObserver(res);
    
     
              
  }
  private displayInfo(node)
  {
    this.infoValue = node.key + "::" + node.value;
  }

  //Method to set Breadcrumbs,mode:  1 - to display breadcrumbs 
  private setBreadCrumbs(node, parent, mode) {
    this.breadCrumbs = [];
    if (node.key != "INSURED_NAME") {
      let nodeObj:any={};
      nodeObj[node.key] = node.value;
      this.breadCrumbs.push(nodeObj);
    }
    let nodeValues;
    node.parent = parent;
    let parentNode = node.parent;

    while (parentNode) {
      nodeValues = parentNode.value;
      if (parentNode.key != "INSURED_NAME") {
        let nodeObj:any={};
        nodeObj[parentNode.key] = parentNode.value;
        this.breadCrumbs.push(nodeObj);
      }
      
      parentNode = parentNode.parent;
    }

    if(mode==1 ){
      if(node.isCheck && this.singleModeSelection){
    console.log( this.breadCrumbs);
    }
    else if(!this.singleModeSelection)
    {
      console.log( this.breadCrumbs);
    }
  }
}
}