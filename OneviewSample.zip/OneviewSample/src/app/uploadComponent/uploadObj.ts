export interface uploadObject { 
    documentName:any,
    documentType:any,
    documentCategory:any,
    documentDate:any,
    documentId:any,
    fileSelected:boolean
    file:any,
    uploadStatus:any,
    fileToBeUploaded:boolean
    
}  

