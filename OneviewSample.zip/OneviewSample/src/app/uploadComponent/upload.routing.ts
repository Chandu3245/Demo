import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UploadComponent } from '../uploadComponent';

const routes: Routes = [
  { path: '', component: UploadComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);