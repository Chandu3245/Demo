import { transition } from '@angular/animations';
import { HttpClientModule } from '@angular/common/http';
import { Component, ChangeDetectorRef, Output, EventEmitter, Inject } from '@angular/core';
import { FormControl,  FormGroup, FormBuilder } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MatSnackBar } from '@angular/material';

import { ClientDataServices } from './clientService';
import { environment } from './../../environments/environment';
import { ShareDataService } from '../services/share.data.service';
import { uploadObject } from './uploadObj';

import { docName } from './documentTypeExtensions';

@Component({
    selector: 'upload-comp',
    templateUrl: './upload.component.html',
    styleUrls: ['./upload.component.scss']
})
export class UploadComponent {

    // date = new FormControl(new Date());
    private sourceSystemValue;
    private mainFormInvalid:boolean=false;
    private attrFormInvalid:boolean = false;
    private  date=new Date();
    private  uploadForm:  FormGroup;
    private  uploadModel:  any  =  [];
    private typeLookup: FormControl = new FormControl();
    private listOfDocTypectrl:any =[];
    private activeIndex: any = 0;
    public files: any = [];
    public fileData: any = [];
    private uploadSuccess: boolean = false;
    private uploadFileLoad:boolean=false;
    private uploadUnSuccess: boolean = false;
    private docAppliedOnSuccessfully: boolean = false;
    private documentCategory: any;
    private docType: any;
    private sendable: any;
    private docFile: any;
    private uploadFlag: boolean;
    private urlToUploadDoc: any;
    private enableFileSelect:boolean = false;
    private docRes: any;
    private docId: string;
    private uploadObj = {};
    private uploadList: uploadObject[] = [];
    private selectedFilesForUpload = [];
    private btnEnable: boolean = false;
    private fileUploaded: boolean=false;
    private validateFlag: boolean = false;
    private progressFlag: boolean = false;
    private buttonHide: boolean = false;
    private uploadedList: any = [];
    private loadForm = false;
    private dragDropChecked: boolean = true;
    private uploadFormValid: boolean = false;
    private docTypeAll: boolean = false;
    private eventChecked: any;
    private checkedIndex: any;
    private crntEle:any;
    private transitionFieldUrl:any;
    private mainForm:any;
    private attrForm:any;
    private appURL:string;
    private dropDownvalue:any=[];
    private reloadSaveLoad:boolean=false;
    options: FormGroup;
    private attrResponseObj:any;
    private listOfFileNames="";
    private docNameExtensionList = [];

    @Output() refreshSearchEvent: EventEmitter<any> = new EventEmitter();
    @Output() uploadErrorPopup: EventEmitter<any> = new EventEmitter();
   
  
    constructor( @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef,
        @Inject(ClientDataServices) private clientService: ClientDataServices, @Inject(MatSnackBar) public snackBar: MatSnackBar,
        @Inject(FormBuilder) private fb: FormBuilder, @Inject(ShareDataService) public shareDataService:ShareDataService) {
      
        this.uploadModel  =  this.uploadView;
        this.options = fb.group({
            hideRequired: false,
            floatLabel: 'auto',
          });
          this.appURL = environment.appURL;
         this.docNameExtensionList = docName;
         console.log(this.docNameExtensionList)
    }
  ngOnInit(){
      this.transitionFieldUrl=this.appURL+"appUserRoles";
     

  }
  private formVal=[];
  private attributeSizes=[]
    private uploadView = [
        {
            "attributeName": "sourceSystemCode",
            "displayName": "Source System",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "functionCode",
            "displayName": "Function",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "regionCode",
            "displayName": "Region",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
    
        {
            "attributeName": "busAreaCode",
            "displayName": "Business Area",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
            
            ],
        },
    ];

    public dropped(event) {
        this.buttonHide = true;
        this.files = event.files;
        for (var file of event.files) {
            file.fileEntry.file(info => {
                this.fileData.push(info);
                let dummyFile: uploadObject = {
                    documentName: info.name,
                    documentCategory: '',
                    documentType: '',
                    documentId: '',
                    documentDate: '',
                    fileSelected: true,
                    file: info,
                    uploadStatus: '',
                    fileToBeUploaded: false
                };
                this.uploadList.push(dummyFile);
                this.docNameExtensionCheck();
                
               this.ref.detectChanges();

            });
            
        }
    }

    public checkForTrig() {
        document.getElementById('dummyBtn').click();
        return true;
    }

    public loadUplForm() {
        this.loadForm = true;
    }

    public fileOver(event) {
     
    }

    public fileLeave(event) {
       
    }
    public fileUpload(value) {
        for (let item of value.srcElement.files) {
            this.fileData.push(item);

        }
    }
    public getUpload() {

    }
   
    public selectionChanged(event, i) {
        this.eventChecked = event.checked;
        this.checkedIndex = i;
        if (event.checked == true) {
            this.selectedFilesForUpload.push(this.uploadList[i]);
            this.uploadList[i].fileSelected = true;
            this.uploadList[i].fileToBeUploaded = true;
        } else {
            for (let j = 0; j < this.selectedFilesForUpload.length; j++) {
                if (this.selectedFilesForUpload[j].documentName == this.uploadList[i].documentName) {
                    this.selectedFilesForUpload.splice(j, 1);
                }
                this.selectedFilesForUpload.splice(j, 1);
                this.uploadList[i].fileSelected = false;
                this.uploadList[i].fileToBeUploaded = false;
            }
            if (this.selectedFilesForUpload.length > 0) {
                this.btnEnable = true;
            } else {
                this.btnEnable = false;
            }
        }
    }

    public setCalendarDate(event, item) {
       
    }

    public removeFromDom() {
        for (let fl of this.uploadedList) {
            this.uploadList.splice(this.uploadList.indexOf(fl), 1);
            this.fileData.splice(this.fileData.indexOf(fl), 1);
        }
    }

    public dateInServiceFormat(dateToConvert){
        let monthList = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        let monthNUmbers = ["01","02","03","04","05","06","07","08","09","10","11","12"];
        
        let dateVal = String(dateToConvert);
        let formDate = dateVal.split(" ");
        let dateFormat= formDate[3] + "-" + (monthNUmbers[monthList.indexOf(formDate[1])] ) + "-" + formDate[2] ;
        return dateFormat;
    }

    public uploadFile(event) {
        this.uploadFormValid = true;
        for (let ele of this.uploadList) {
            ele.fileToBeUploaded = false;
        }
        for (let item of this.uploadList) {

            let indexOfElement = this.uploadList.indexOf(item)
            item.fileToBeUploaded = true;
            if(item.documentDate==null){
                item.documentDate=this.date;
                } 
            if (item.documentType == '' || item.documentName == '' || item.documentDate == ''
                || !item.documentType || !item.documentDate || !item.documentName) {
                this.uploadFormValid = false;
            }
        }
        if (this.mainForm && this.mainForm.controls) {
            for (let item in this.mainForm.controls) {
                 if (!this.mainForm.controls[item].valid || this.mainForm.controls[item].pristine) {
                    this.mainForm.controls[item].pristine= false;
                    this.mainForm.controls[item].markAsTouched();
                    this.mainFormInvalid = !this.mainFormInvalid;
                    this.mainFormInvalid = true;

                    this.uploadFormValid = false;
                    this.snackBar.open("Please Fill Mandatory Fields To Upload", 'Close', {
                    duration: 5000,
                     });
                 }
            } 
        }else{
            this.uploadFormValid = false;
        }
        if (this.attrForm && this.attrForm.controls) {
            for (let item in this.attrForm.controls) {
                if (!this.attrForm.controls[item].valid ) {
                    this.attrForm.controls[item].pristine = false;
                    this.attrForm.controls[item].markAsTouched();
                    this.attrFormInvalid = !this.attrFormInvalid;
                    this.attrFormInvalid = true;
                    this.uploadFormValid = false;
                    this.snackBar.open("Please Fill Mandatory Fields To Upload", 'Close', {
                        duration: 2000,
                    });
                }
            }
        }else{
            this.uploadFormValid = false;
        }


        if (this.uploadFormValid) {

            this.urlToUploadDoc = this.appURL + 'uploadDocument';
            for (let fl of this.uploadList) {
                if (fl.documentId == '') {
                    this.validateFlag = true;
                    if (fl.documentName != '' && fl.documentType != '' && fl.documentDate != '') {

                        this.sendable = new FormData();
                        this.sendable.append('file', fl.file, fl.file.name);
                        this.sendable.append('DOCUMENT_NAME', fl.documentName)
                        this.sendable.append('DOC_INDEX',this.uploadList.indexOf(fl));

                        this.sendable.append('DOCUMENT_CATEGORY', fl.documentCategory);
                        this.sendable.append('DOCUMENT_TYPE', fl.documentType);
                        this.sendable.append('DOCUMENT_DATE', this.dateInServiceFormat(fl.documentDate));;
                        if (this.mainForm && this.mainForm.controls) {
                            for (let item in this.mainForm.controls) {
                                if (this.mainForm.controls[item].value && this.mainForm.controls[item].value != '') {
                                    if (item == 'sourceSystemCode') {
                                        this.sendable.append('SOURCE_SYSTEM', this.mainForm.controls[item].value);
                                    } else if (item == 'busAreaCode') {
                                        this.sendable.append('BUSINESS_AREA', this.mainForm.controls[item].value);
                                    } else if (item == 'regionCode') {
                                        this.sendable.append('REGION', this.mainForm.controls[item].value);
                                    } else if (item == 'functionCode') {
                                        this.sendable.append('FUNCTION', this.mainForm.controls[item].value);
                                    }
                                }
                            }
                        }
                        if (this.attrForm && this.attrForm.controls) {
                            let dateFormatChange ;
                            for (let item in this.attrForm.controls) {
                                if (this.attrForm.controls[item].value && this.attrForm.controls[item].value != '') {
                                //    let  date= Date.parse(this.attrForm.controls[item].value);
                                   for(let resItem of this.attrResponseObj){
                                    if(resItem.attribute.attributeType == "DATEBOX"){
                                        if(resItem.attribute.attributeName == item ){
                                        // this.dateInServiceFormat(this.attrForm.controls[item].value);
                                        // this.attrForm.controls[item].value =
                                        dateFormatChange =   this.dateInServiceFormat(this.attrForm.controls[item].value);
                                        // this.sendable.append(item, this.dateInServiceFormat(this.attrForm.controls[item].value));
                                        }
                                    }
                                   
                                }
                                // else{
                                    if(dateFormatChange){
                                        this.sendable.append(item, dateFormatChange);
                                        dateFormatChange="";
                                    }
                                    else{
                                    this.sendable.append(item, this.attrForm.controls[item].value)
                                    }
                                // }
                                    // if(isNaN(date)) {
                                    // this.sendable.append(item, this.attrForm.controls[item].value)
                                    // }
                                    // else{
                                    //     this.dateInServiceFormat(this.attrForm.controls[item].value)
                                    // this.sendable.append(item, this.dateInServiceFormat(this.attrForm.controls[item].value));
                                    // }
                                    } 
                                   
                            }
                        }

                        this.progressFlag = true;
                        this.uploadFiles(this.sendable, fl.file);
                    }

                    else {
                        this.snackBar.open("Please Fill Mandatory Fields To Upload", 'Close', {
                            duration: 5000,
                        });
                    }
                }
            }
            this.ref.detectChanges();

        }

    }

    public clearUploadQueue(){
        this.uploadList = [];
        this.fileData = [];
        this.ref.detectChanges();
    }
    public uploadFiles(sendable, fl) {

        let xhr = new XMLHttpRequest();
        let self = this;
        xhr.open('POST', this.urlToUploadDoc, true);
        xhr.withCredentials = true;

        xhr.send(sendable);
        xhr.onreadystatechange = function () {

            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    if (xhr.response != '') {
                       
                        if ( xhr.response.indexOf('User') < 0 &&  xhr.response.indexOf('STATUS') < 0) {
                            let objReturned
                            if(xhr.response.indexOf('\\')>0){
                                let dummy = xhr.response.split(',');
                                let dummy1 = dummy[1].split('""');
                                let dummy2 = dummy1[2].split(':');
                                let dummy3 = dummy2[1].split('}');
                                objReturned = dummy3[0]
                            }else{
                                objReturned = JSON.parse(xhr.response)
                            }
                            self.uploadList[objReturned.docIndex].documentId= objReturned.documentId
                            self.uploadedList.push( self.uploadList[objReturned.docIndex]);
                            self.selectedFilesForUpload.splice(self.selectedFilesForUpload.indexOf(self.uploadList[objReturned.docIndex]), 1);
                                    if (self.selectedFilesForUpload.length <= 0) {
                                        self.btnEnable = false;
                                    }
                            // for (let file of self.uploadList) {
                            //     if (objReturned.fileName==file.documentName && file.documentId=="") {
                            //         file.documentId = objReturned.documentId;
                            //         file.uploadStatus = true;
                            //         self.uploadedList.push(file);
                            //         self.selectedFilesForUpload.splice(self.selectedFilesForUpload.indexOf(file), 1);
                            //         if (self.selectedFilesForUpload.length <= 0) {
                            //             self.btnEnable = false;
                            //         }
                            //     }
                            // }
                            self.validateFlag = false;
                            self.progressFlag = false
                            self.ref.detectChanges();
                            xhr.abort();
                            return;
                        } else {
                            let msg = JSON.parse(xhr.response)
                            self.snackBar.open(msg.STATUS, 'Close', {
                                duration: 5000,
                            });
                        }

                    }
                    else {
                        self.snackBar.open("Upload Failed", 'Close', {
                            duration: 5000,
                        });
                    }

                } else if (xhr.status == 500) {
                    self.progressFlag = false;
                    for (let file of self.uploadList) {
                        if (file.documentName == fl.documentName) {

                            file.uploadStatus = false;
                            break;
                        }
                    }
                    self.uploadErrorPopup.emit(xhr.statusText);
                    return;
                }
            }
            self.progressFlag = false;
            // self.snackBar.open("Upload Success", 'Close', {
            //     duration: 5000,
            //      });
        }

    }


    public tabChangeEvent(event, ind) {
        this.activeIndex = event.index;
    }

    //   method to assign attrForm
  public attrFormChanged(event) {
      this.attrForm = event[0];
      this.attrResponseObj = event[1];
  }
    public formChanged(event){
        this.mainForm = event;
        if(event){
            this.enableFileSelect = true;
        }
        
        for(let ctrl in this.mainForm.controls){
            if(!this.mainForm.controls[ctrl].value || this.mainForm.controls[ctrl].value==''){
                this.enableFileSelect= false;
                break;
            }
        }
        this.uploadList.length=0;
        this.uploadedList.length=0;
        this.fileData.length = 0;
        this.selectedFilesForUpload.length = 0;
        this.uploadFileLoad = false;
    }

public prepareForUpload(event: any) {
    this.listOfFileNames="";
    this.buttonHide = true;
    for (let fl of event.target.files) {
    
        this.fileData.push(fl);
        this.listOfDocTypectrl.push(new FormControl());
        let dummyObj: uploadObject = {
            documentName: fl.name,
            documentCategory: '',
            documentType: '',
            documentId: '',
            documentDate: this.date,
            fileSelected: true,
            file: fl,
            uploadStatus: '',
            fileToBeUploaded: false,
        };
        this.uploadList.push(dummyObj);
        this.docNameExtensionCheck();

        
      
    }


    this.selectedFilesForUpload.push(this.uploadList);
    this.btnEnable = true;
    this.uploadFlag = true;
    this.fileUploaded=true;
    this.uploadFileLoad=true;
    this.ref.detectChanges();
}

private uploadSelectedFile(event){
    this.uploadList=event;
    // this.reloadSaveLoad = !this.reloadSaveLoad
    setTimeout(() =>{
        this.uploadFile(event);
    },200)
    
}

//method to disallow the files to add in the queue  which are not valid document ( checking based on extensions)
private docNameExtensionCheck() {
    let flag = false;
    let index;
    for (let item = 0; item < this.uploadList.length; item++) {
        console.log(this.uploadList[item].documentName);
        let docName = this.uploadList[item].documentName;
        let lastIndex = docName.lastIndexOf(".");
        let docExt = docName.substring((lastIndex + 1), docName.length);
        for (let i = 0; i < this.docNameExtensionList.length; i++) {
            if (this.docNameExtensionList[i].toUpperCase() == docExt.toUpperCase()) {
                flag = false;
                break;
             }
            else {
                index = item;
                flag = true;
            }

        }
    }
    if (flag) {
        this.listOfFileNames = this.listOfFileNames + this.uploadList[index].documentName + "  ,  ";
        this.snackBar.open(this.listOfFileNames + " is not of  valid extension", 'Close', {
            duration: 5000,
        });
        this.uploadList.splice(index, 1);
        this.fileData.splice(index, 1);

    }
}
}