import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ClientDataServices } from './clientService';
import{FileDragDropComponent} from'../fileDragDropComponent/fileDragDrop.Component'; 
import { MyMaterialModule } from '../material.module';
import { SaveLoadFormComponent } from '../saveLoadFormComponent/saveLoadForm.component';
import {routing} from './upload.routing';
import {UploadComponent} from '../uploadComponent';
import{UploadQueueComponent} from '../uploadQueueComponent/uploadQueue.component'


@NgModule({
  declarations: [
        UploadComponent  
         ,SaveLoadFormComponent,
         FileDragDropComponent,
         UploadQueueComponent
  ],
  imports: [
    routing,
    // SaveLoadFormModule,
    CommonModule,FormsModule,MyMaterialModule,ReactiveFormsModule],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  //exports:[UploadComponent],
  providers:[ClientDataServices]
  
})
export class UploadModule { }
