import { Component, Input, Output, EventEmitter, OnInit, Inject ,ChangeDetectorRef} from '@angular/core';

import { ShareDataService } from '../services';

@Component({
    selector: 'file-drag-drop',
    templateUrl: './fileDragDrop.component.html',
    styleUrls: ['./fileDragDrop.component.scss']
})
export class FileDragDropComponent implements OnInit {

    private fileSelect:any;
    @Output() uploadSelectedFiles: EventEmitter<any> = new EventEmitter();

    constructor(  @Inject(ShareDataService) private shareDateService: ShareDataService, ) {
        
            }

    ngOnInit(){

    }
     
    //method triggered when file is dropped in the drop zone
    public fileDroppedEvent(event) {
        console.log(event)
        console.log(this.fileSelect);
        let filesObj = {
            target:{
                files: event.target.files || event.dataTransfer.files 
            }
        };
        this.uploadSelectedFiles.emit(filesObj);
        this.preventDefaultAndStopPropagation(event);
        
    }
dummy(val){
    if(val.files && val.files.length>0){
        val.value = '';
    }
}
    private preventDefaultAndStopPropagation(event) {
        event.preventDefault();
        event.stopPropagation();
      }
}

