import { Component, Input, Output, EventEmitter, OnInit, Inject } from '@angular/core';

import { ShareDataService } from '../services';

@Component({
    selector: 'additional-info',
    templateUrl: './additionalInfo.component.html',
    styleUrls: ['./additionalInfo.component.scss']
})
export class AdditionalInfoComponent implements OnInit {

    private displayKeys: any = [];
    private displayValues:any=[];
    private RowSelectedvalue = [];
    private recentRowVals: any = [];
    private mostRecentRowSelected = [];
    private selectedRowKeys: any;
    

    @Input() summaryCardData;
    @Input() headerName;
    @Output() closeSummaryDataEvent: EventEmitter<any> = new EventEmitter();

    constructor( @Inject(ShareDataService) private shareDateService: ShareDataService, ) {

    }

    ngOnInit() {
        this.additionalInfo();
    }

    // method to create key value arrays from the given object
    public additionalInfo() {
        this.displayKeys = [];
        for (let i = 0; i < this.summaryCardData.row.value.length; i++) {
            this.displayKeys.push(this.summaryCardData.row.value[i].dataKey);
            this.displayValues.push(this.summaryCardData.row.value[i].value);
        }
    }
    
    // method thats triggered when the additional infor card is closed
    public closeSummary() {
        this.closeSummaryDataEvent.emit("false");
    }
}
