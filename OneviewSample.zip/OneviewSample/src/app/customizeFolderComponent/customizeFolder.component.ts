import { Component, OnInit, Inject} from '@angular/core'
import {MAT_DIALOG_DATA,MatSnackBar} from '@angular/material';

import{ environment } from './../../environments/environment';
import { ClientDataService,ShareDataService } from '../services';

@Component({
    selector:'customize-folder',
    templateUrl:'./customizeFolder.component.html',
    styleUrls:['./customizeFolder.component.scss']
})
export class CustomizeFolderComponent implements OnInit {

    private attrList:any=[];

    private listOfAttrSelected:any=[];
    private selectedAttributeList:any=[];
    private saveList=[];
    private customizationUpArray:any=-1;
    private customizationDownArray:any=-2;
    private appURL:string;
    private moveToIndex:any;
    private savingTree:boolean=false;
    private saveObject:any;
    constructor(@Inject(MAT_DIALOG_DATA) public dailogData:any,
    @Inject(ShareDataService) public shareDataService:ShareDataService,
    @Inject(ClientDataService) private clientDataService: ClientDataService,
    @Inject(MatSnackBar) public snackBar: MatSnackBar){
        this.appURL = environment.appURL;
    }

    ngOnInit(){
        //forming dummy object to include checked
        // for(let item of this.dailogData){
        //     let attrObj={
        //         attrName:'',
        //         checked:false
        //     }
        //    attrObj.attrName = item;
        //    attrObj.checked = false;
        //    this.attrList.push(attrObj);
        this.attrList = this.dailogData;
        // }
    }
   
public clearAtrList(){
    this.shareDataService.clearSuccess();
}
    //method to save the attribute selection
    public saveAttrList() {
        this.listOfAttrSelected = [];
        let dummy;
        let saveObj = {
            busAttributeUid: '',
            sourceSystemCode: '',
        }
        for (let item of this.attrList) {
            if (item.checked) {
                if (dummy) {
                    dummy += item.busAttributeUid + ",";
                } else {
                    dummy = item.busAttributeUid + ",";
                }
                saveObj.busAttributeUid = dummy;
                saveObj.sourceSystemCode = item.sourceSystemCode;
                this.listOfAttrSelected.push(item);
            }
            this.shareDataService.setAttrLsit(this.listOfAttrSelected);
        }
        this.saveObject=JSON.stringify(saveObj);
        let saveUrl = this.appURL + 'treeAttributes/saveAttributes';
        this.clientDataService.setUrl(saveUrl);
        this.clientDataService.PostClientData(saveObj).subscribe(result => {
            if(result.STATUS ='STATUS'){
                this.savingTree=true;
                this.shareDataService.setsuccess(this.savingTree);
                this.snackBar.open("Save Sucessful", 'Close', {
                    duration: 5000,
                });
               
            }
          
        })
    }
    // method to handle the drop event , pushing item a step down and the check list
    // and also change the selected attributes accordingly
    public onAttrDrop(event,droppedAtEle){
        if(event.attrName != droppedAtEle.attrName){
            let dropItemIndex = this.attrList.indexOf(droppedAtEle);
            for(let item of this.attrList){
                if(item.checked){
                    if(this.listOfAttrSelected.indexOf(item)<0){
                        this.listOfAttrSelected.push(item);
                    }
                    
                }
            }
            for(let item of this.listOfAttrSelected){
                this.attrList.splice(this.attrList.indexOf(item),1);
            }
            this.listOfAttrSelected.reverse();
            for (let item of this.listOfAttrSelected){
                this.attrList.splice(dropItemIndex,0,item);
            }
        }
        
    }
    //Checking Attribure List for checked or unChecked
    public attributeListChecked(item,event){
        if(event.checked){
            this.selectedAttributeList.push(item);
        }
    }
      //Swapping Selected List Upward on Button Click
    public swappingListUp(attrIndex){
       let eleToSwap = this.attrList[attrIndex];
       if(attrIndex !=0){
        this.attrList[attrIndex] = this.attrList[attrIndex-1];
        this.attrList[attrIndex-1] = eleToSwap 
       }else{
        this.attrList[attrIndex] = this.attrList[this.attrList.length-1];
        this.attrList[this.attrList.length-1] = eleToSwap 
       }
       this.moveToIndex=eleToSwap;
    }
    //Swapping Selected List downward on Button Click
    public swappingListDown(attrIndex){
        let eleToSwap = this.attrList[attrIndex];
        if(attrIndex !=this.attrList.length-1){
            this.attrList[attrIndex] = this.attrList[attrIndex+1];
            this.attrList[attrIndex+1] = eleToSwap 
        }else{
            this.attrList[attrIndex] = this.attrList[0];
            this.attrList[0] = eleToSwap 
        }
        this.moveToIndex=eleToSwap;
    }
    
}