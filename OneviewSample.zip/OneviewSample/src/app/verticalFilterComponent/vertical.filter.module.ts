import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { MyMaterialModule } from '../material.module';
import {VerticalFilterComponent} from './vertical.filter.component';

@NgModule({
  declarations: [
        VerticalFilterComponent   
  ],
  imports: [CommonModule,FormsModule,MyMaterialModule,ReactiveFormsModule],
  exports:[VerticalFilterComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [VerticalFilterComponent]
})
export class VerticalFilterModule { }
