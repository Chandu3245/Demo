import { Component, Input, Output, EventEmitter, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';

import { ShareDataService } from '../services';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'vertical-filter',
  templateUrl: './vertical.filter.component.html',
  styleUrls: ['./vertical.filter.component.scss']
})

export class VerticalFilterComponent implements OnInit {
  // private showId: boolean = false;
  private formList: any = [];
  private formListSlice: any = [];
  private autoLookUpValue:any=[];
  @Input() columnDefs;
  @Input() tableHeader;
  @Input() getData;
  @Input() showTable;
  @Input() showId;

  @Output() closeSummaryToggle: EventEmitter<any> = new EventEmitter();
  @Output() verticalSearchFilter: EventEmitter<any> = new EventEmitter();
  @Output() formVerticalfilter:EventEmitter<any> = new EventEmitter();
  @Output() postFilterOpened:EventEmitter<any> = new EventEmitter();
  @Output() setMinwidth:EventEmitter<any> = new EventEmitter();
  
  
  private verticalSearchForm: FormGroup;
  private lookUpOpts: any = [];
  private clickData: any;
  private verticalFilterButtonActive:any=-1;
  myControl: FormControl = new FormControl();

  options = [
    'One',
    'Two',
    'Three'
  ];

  filteredOptions: Observable<string[]>;
  private filteredDataArray: any = [];
  constructor( @Inject(ShareDataService) private shareDateService: ShareDataService, @Inject(FormBuilder) private fb: FormBuilder) {
   // console.log(this.columnDefs)
    // this.filteredOptions = this.myControl.valueChanges
    //   .startWith('')
    //   .map(val => this.filter(val, this.lookUpOpts));
    // this.filteredOptions = this.myControl.valueChanges
    // .startWith('')
    // .map(val => this.filter(val));
  }
  ngOnInit() {
    this.verticalSearchForm = this.createGroup();
  }
  ngOnChanges() {
   if(this.columnDefs){
   }
  }
  filter(val: string, arrayToBeFiltered): string[] {
   if(val && val.length >=3){
    return val ? arrayToBeFiltered.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
    : arrayToBeFiltered;
   }else{
     return [];
   }
   
  }
  //   filter(val: string): string[] {
  //     return this.options.filter(option =>
  //       option.toLowerCase().indexOf(val.toLowerCase()) === 0);
  //  }
  createGroup() {
    const group = this.fb.group({});
    this.columnDefs.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
    return group;
  }

  createControl(config) {
    const { isDisabled, validation, value } = config;
    //  validation.push(customValidator('&', 'ampersandRequired',new ValidationContext(),new RuleConfigurator());
    // console.log(this.fb.control({ 'value': value, 'disabled': isDisabled }, validation))
    return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  }
  public toggleId() {
    this.formList = []
    for (let i = 0; i < this.columnDefs.length; i++) {
      this.formList.push(this.columnDefs[i]);
    }
    this.formListSlice = this.formList;
    this.showId = !this.showId;
    this.closeSummaryToggle.emit(this.showId);
    if(this.showId){
      this.postFilterOpened.emit()
    }
    else{
      this.setMinwidth.emit(this.showId)
    }

  }

  public showData() {
    let formUnchanged: boolean = true;
    this.filteredDataArray = [];
    let dummy = []
    for (let item in this.verticalSearchForm.controls) {
      if (this.verticalSearchForm.controls[item]["_value"] && this.verticalSearchForm.controls[item]["_value"] != ' ' && this.verticalSearchForm.controls[item]["_value"] != null) {
        formUnchanged = false;
        if (this.filteredDataArray.length <= 0) {
          for (let data of this.getData) {
            if (data[item] == this.verticalSearchForm.controls[item]["_value"]) {
              this.filteredDataArray.push(data);
            }
          }
        } else {
          let dummy = [];
          for (let data of this.filteredDataArray) {
            if (data[item] == this.verticalSearchForm.controls[item]["_value"]) {
              dummy.push(data);
            }
          }
          this.filteredDataArray = dummy;
        }

      }
    }

    this.showId = false;
    if (!formUnchanged) {
      this.verticalSearchFilter.emit({ filterDataInfo: this.filteredDataArray, hidefilter: this.showId });
    } else {
      this.verticalSearchFilter.emit({ filterDataInfo: [], hidefilter: this.showId });
    }

  }
  public optionControlToLookup(data) {
    this.lookUpOpts = [];
    this.clickData = data;
  
    for (let i = 0; i < this.getData.length; i++) {
      for (let j = 0; j < this.getData[i].length; j++) {
        if (this.clickData == this.getData[i][j].dbColumnName) {
          if (this.lookUpOpts.indexOf(this.getData[i][j].value) < 0) {
            this.lookUpOpts.push(this.getData[i][j].value)
          }  
        }
      }
    }
    let control = this.verticalSearchForm.controls[data];
    let self= this;
    this.filteredOptions = this.verticalSearchForm.controls[data].valueChanges
      .startWith(null)
      .map(val => this.filter(val, this.lookUpOpts));
      this.filteredOptions.subscribe(res =>{
        self.controlChange();
    })
  }
  public optionselect(event){
    this.formVerticalfilter.emit(this.verticalSearchForm);
  }
  public controlChange(){
    
  }
  public searchFilter(event,selectedname){
    //this.formVerticalfilter.emit(this.verticalSearchForm);
  }

  //method to clear the value of the FormControl
  public clearControl(ctrl){
    // console.log(this.verticalSearchForm.controls[ctrl].value);
    this.verticalSearchForm.controls[ctrl].reset();
    this.optionselect("");
  }
}