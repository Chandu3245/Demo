import { Pipe, PipeTransform } from '@angular/core';

declare var require: any; 

@Pipe({
  name: 'FilterPipe',
})
export class FilterPipe implements PipeTransform {
    transform(value: any, args?: any): any {
        let stringify = require('json-stringify-safe'); 
        
                if (!value) return null;
                if (!args) return value;
        
                args = args.toLowerCase();
       
                return value.filter(function (item: any) {
                    return stringify(item).toLowerCase().includes(args); 
                });
            }
        }