import { CommonModule } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, FormBuilder , ReactiveFormsModule } from '@angular/forms';

import { AdditionalInfoComponent } from '../additionalInfoComponent/additionalInfo.component';
// import { AdditionalInfoModule } from './../additionalInfoComponent/additionalinfo.module';
import { MyMaterialModule } from '../material.module';
import { MdtTableModule } from './../../lib/modules/mdt-table/mdt-table.module';
// import { SaveLoadFormModule } from '../saveLoadFormComponent/saveLoadForm.module';
//  import { SaveLoadFormComponent } from '../saveLoadFormComponent/saveLoadForm.component';
import {SearchComponent} from './search.component';
import {routing} from './search.routing';


@NgModule({
  declarations: [
        SearchComponent,
        AdditionalInfoComponent,
        //SaveLoadFormComponent
        
  ],

imports: [ 
  routing,
  // SaveLoadFormModule,
  // AdditionalInfoModule,
CommonModule,MyMaterialModule,
ReactiveFormsModule ,FormsModule,MdtTableModule],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
  // exports:[SearchComponent]
  
})
export class SearchModule { 

}
