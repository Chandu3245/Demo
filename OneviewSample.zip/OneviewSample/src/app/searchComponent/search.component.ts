import { trigger, state,style, animate, transition } from '@angular/animations';
import { Component, ChangeDetectorRef, Input, DoCheck, ViewChild, AfterViewInit, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';

import { environment } from '../../environments/environment';
import { docName } from './../uploadComponent/documentTypeExtensions';
// import { TableElement } from './../../lib/modules/mdt-table/components/mdt-tableElement';
import { MdtTableModule } from './../../lib/modules/mdt-table/mdt-table.module';
import { DataService } from './../../lib/modules/mdt-table/services/DataService';
import { ClientDataService, WindowRef, ShareJsonData, ShareDataService } from '../services';
import { VerticalFilterComponent, VerticalFilterModule } from '../verticalFilterComponent';

@Component({
    selector: 'search-comp',
    templateUrl: './search.component.html',
    styleUrls: ['./search.component.scss'],
    animations: [
        trigger(
          'enterAnimation', [
            transition(':enter', [
              style({transform: 'translateX(100%)', opacity: 0}),
              animate('500ms', style({transform: 'translateX(0)', opacity: 1}))
            ]),
            transition(':leave', [
              style({transform: 'translateX(0)', opacity: 1}),
              animate('500ms', style({transform: 'translateX(100%)', opacity: 0}))
            ])
          ]
        )
      ],
})
export class SearchComponent {
    private  changeEDMSColor:boolean = true;
    private  changesharepointColor:boolean;
    private combocolor:boolean;
    private openClickicon:any=["Template1 Edms","Template2 All","Template3 SharPnt"];
    private openSaveIcon:any=["no search "];
    public cardClose:boolean=false;
    public  textValue:String;
    public saveSearchValue:any=[];
    private saveName:any;
    private nameData:any=[];
    private searchTypeName:any;
    private storeCriteria:any=[];
    private listOfActionItem = ["Edit","View","Share","Download","Delete","Additional Info","Attach"];
    private listOfActionMenu= ["Share","Download","Delete","Attach"];
    private showPostFilter:boolean=false;
  
    private dispSummaryCard: boolean = false;
    private widthtobeset:String;
    private additionalInfoCard:boolean=false;
    private toggleCardTop: any = '755px'
    private rowSelected:boolean=false;
    private verticalCardHeight:string;
    private searchVerticalFilter: any;		
     private verticalfilter: boolean = false;
     private getData: any = [];		
    	private listOfSelectedRows:any=[];		
     	private getVerFilterData: any = [];
    private dummydata= [];
    private rowsForTable:any = [];
 private rowData:any=[];
    private columnsForTable= [];
    private columnDefs: any = [];
    private keyWordValue={};
    private additionalInfoData:any;
    private KeyWordSearch:boolean=false;
    private searchList:any=["Documentem","SharePoint"];
    private searchType:any=[
        {searchTypeName:'Content And Attributes',
        checked:true
       },
      {searchTypeName:'Attributes Only',
       checked:false}
];
    private typeSearch:any;
    private attrOnly:boolean=false;
    private mostRecentData:any // to store most recent selection in mdt-table
    //foldersList
    private foldersList = [{
        "created": 1436459938000,
        "name": "T_DOC_INFO.csv",
        "rootUrl": environment.SPURL,
        "modified": 1436460020000,
        "title": "T_DOC_INFO"
    }
    ];

    private advancedSearchForm: FormGroup;
    private advanceSearchModel: any = [];
    private months: any = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    private location: any = ['India', 'Nepal', 'Bhutan'];
    private contentAttrbutes =[
        {
            "attributeName": "documentName",
            "displayName": "Document Name",
            "attributeType": "TEXTBOX",
            "attributeLookupValues": [
            
            ],
        },
        {
            "attributeName": "createdBy",
            "displayName": "Owner",
            "attributeType": "TEXTBOX",
            "attributeLookupValues": [
               
            ],
        },
        // {
        //     "attributeName": "regionCode",
        //     "displayName": "Created Date From",
        //     "attributeType": "DATEBOX",
        //     "attributeLookupValues": [
               
        //     ],
        // },
        // {
        //     "attributeName": "functionCode",
        //     "displayName": "Created Date To",
        //     "attributeType": "DATEBOX",
        //     "attributeLookupValues": [
               
        //     ],
        // },
        {
            "attributeName": "docFormat",
            "displayName": "Document Format",
            "attributeType": "LISTBOX",
            "attributeLookupValues": docName
        },
    ]
    private advanceSearchSharePoint =  [
        {
            "attributeName": "sourceSystemCode",
            "displayName": "Source System",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "functionCode",
            "displayName": "Function",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "regionCode",
            "displayName": "Region",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "busAreaCode",
            "displayName": "Business Area",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
            
            ],
        },
     ];

    private advanceSearchEDMS_UW = [
        {
            "attributeName": "sourceSystemCode",
            "displayName": "Source System",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "functionCode",
            "displayName": "Function",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "regionCode",
            "displayName": "Region",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "busAreaCode",
            "displayName": "Business Area",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
            
            ],
        },
     ];
 

    private advanceSearchEDMS_Claims =  [
        {
            "attributeName": "sourceSystemCode",
            "displayName": "Source System",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "functionCode",
            "displayName": "Function",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "regionCode",
            "displayName": "Region",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
               
            ],
        },
        {
            "attributeName": "busAreaCode",
            "displayName": "Business Area",
            "attributeType": "LISTBOX",
            "attributeLookupValues": [
            
            ],
        },
     ];
    private showFullTextSearch:boolean= true;
    private fileName: any="";
    private urlToGetRoles: string;
    private urlForDownload = environment.DocURL;
    private listOfAvailableSoruces: any = [];
    private oneViewGrid: any = [];
    private serviceLapseTimeList = [];
    private showServiceLapDetails: boolean = false;
    private rolesData: any;
    private listOfServiceCallTime = [];
    private listOfServiceResponse = [];
    private totalLapseTime: any = 0;
    private repoError: boolean = false;
    private listOfSrcSysParsed = [];
    private listOfNoOfRecordsPerSrcSys = [];
    private totNoOfRecords: any = 0;
    private serviceCount = 0;
    private previousSrc: any;
    private winref: any;
    private paginationMargin: any = '5%';
    private initPaginationSet: boolean = false;
    private rowsToBeSkipped: number = -1;
    private pageStartIndex: number = -1;
    private pageLastIndex: number = -1;
    private pageStartIndexEdms: number = -1;
    private pageLastIndexEdms: number = -1;
    private pageStartIndexSharePoint: number = -1;
    private pageLastIndexSharePoint: number = -1;
    private startSPIndex: number = -1;
    private globalSearch: boolean = false;
    private edmsSearch: boolean = false;
    private sharePointSearch: boolean = false;
    private comboSearch: boolean = false;
    private showId: boolean = false;
    private panelWidth: string = '50%';
    private toggleSearchBar: boolean = true;
private jsondata:any;
private searchopen:boolean;
    private deviceType: any = '';
    private deviceOrien: any = '';
    private showFilteredTable: any = [];
    private selectedValue: boolean;
    private verticalCardMaxHeight:String;
    private searchLists:any=[];
private recordCount:any;
private expandSearch:boolean;
private transitionFieldUrl:any;
private searchBoolean:boolean=false;
private appURL:string;
private selectedFilterApply:any=[];
private rowDataBack:any=[];
private mainGroup:any;
private formGroup:any;
private objToBeSent: any = {};
private fullTextSearchInput:any={
   
};
    constructor( @Inject(ClientDataService) private clientService: ClientDataService,
        @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef,
        @Inject(WindowRef) private winRef: WindowRef,
        @Inject(ShareDataService) private shareDateService: ShareDataService,
        @Inject(ShareJsonData) private shareJsonData: ShareJsonData,

        @Inject(MatDialog) public dialog: MatDialog,
        @Inject(FormBuilder) private fb: FormBuilder,
        @Inject(DataService) private dataservice: DataService


    ) {
      
        this.winref = winRef.nativeWindow;
        // this.pageFirstTime = true;
         this.appURL = environment.appURL;
        // this.docUrl = environment.DocURL;
        // this.urlToGetRoles = this.appUrl + 'userAccess/getRoles';
       
    }
ngAfterViewInit() {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    if( this.searchopen){
        this.advancedsearchFile();
                   }
}

    onChange(newValue) {
        this.selectedValue = newValue;
        
    }

    ngOnInit() {
        
        this.transitionFieldUrl=this.appURL+"appUserRoles";
        this.sharePointSearch = false;
        this.edmsSearch = true;
        this.comboSearch = false;
        this.globalSearch = false;
        
        this.advanceSearchModel = this.advanceSearchEDMS_UW;
        this.advancedSearchForm = this.createGroup();
        //this.getVerticalSearchFilter(event);
        for(let item of this.searchList){
            let searchObj={
                searchName:item,
                checked:true
            }
            if(item == 'SharePoint'){
                searchObj.checked = false;
            }
           this.searchLists.push(searchObj);
        }
        this.searchBoolean=true;
        this.expandSearch=false;
        
    }

    public closedStep() {
        this.panelWidth = '50%';
        this.toggleSearchBar = true;
        this.toggleCardTop='60px';
    }
    public openedStep() {
        this.panelWidth = '100%';
        this.toggleSearchBar = true;
        this.toggleCardTop='60px';
    }

    createGroup() {
        const group = this.fb.group({});
        this.advanceSearchModel.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
        return group;
    }
    createControl(config) {
        const { isDisabled, validation, value } = config;
        //  validation.push(customValidator('&', 'ampersandRequired',new ValidationContext(),new RuleConfigurator());
        return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    }

    public toggleId() {
        this.showId = !this.showId;
    }
    
    private doEdmsSearch($event) {
        this.combocolor  =false;
        
        this.changeEDMSColor = true;
        this.changeEDMSColor = true;
        // this.changesharepointColor =false;        
        if(this.changeEDMSColor)
        {
     
        this.edmsSearch = !this.edmsSearch;
        // this.sharePointSearch = false;
        this.comboSearch = false;
        // this.showRes = false;
        this.globalSearch = false;
        // this.comboHide = false;
        // this.sharePointHide = false;
        // this.documentumHide = true;
        this.advanceSearchModel = this.advanceSearchEDMS_UW;
        this.advancedSearchForm = this.createGroup();
        this.changesharepointColor =false;
    }
        if(this.changeEDMSColor&& this.changesharepointColor){
            this.doComboSearch();
        }   
    }

    private doSharePointSearch($event) {
      this.combocolor  =false;
        this.changesharepointColor =true;

        if(this.changesharepointColor){
            this.edmsSearch = false;
            this.sharePointSearch = !this.sharePointSearch;
            this.comboSearch = false;
            this.globalSearch = false;
            // this.showRes = false;
            // this.comboHide = false;
            // this.sharePointHide = true;
            // this.documentumHide = false;
            this.advanceSearchModel = this.advanceSearchSharePoint
            this.advancedSearchForm = this.createGroup();
        }
         if(this.changeEDMSColor && this.changesharepointColor){
            this.doComboSearch();
        }
    }

    private doComboSearch() {
        if(this.changeEDMSColor && this.changesharepointColor){
            this.comboSearch = !this.comboSearch;
            this.sharePointSearch = false;
            this.edmsSearch = false;
            // this.showRes = false;
            // this.comboHide = true;
            // this.sharePointHide = false;
            // this.documentumHide = false;
            this.advanceSearchModel = this.advanceSearchEDMS_Claims;
            this.advancedSearchForm = this.createGroup();
            this.changeEDMSColor =false;
            this.changesharepointColor =false;
            this.changeEDMSColor =false;
            this.changesharepointColor =false;
            this.combocolor  =true;
        }
   
    }
    public openCard()
    {
        if(this.cardClose)
        this.cardClose=false;
        else
        this.cardClose=true;
        
    }
    public closeCardIcon()
    {
        this.cardClose=false;
    }

public tempOpenIcon(item)
{
     var data={DOCUMENT_NAME:'name-1', CREATED_BY:'owner-1',INSURED:'test-1',createdBy:'name-2', modifiedBy:'owner-2'}
   if(item=='Template2 All')
      {
       if(this.comboSearch )
         {
             for(let ctrlAll in this.advancedSearchForm.controls){
            for(let templateAll in data){
                    if(ctrlAll == templateAll){
                        this.advancedSearchForm.controls[ctrlAll].setValue(data[templateAll]);
                }
               }
           }
             }  
            }
            else if(item=='Template3 SharPnt')
            {
                    if( this.sharePointSearch)
                    { 
                       for(let ctrlShare in this.advancedSearchForm.controls){
                            for(let templateShare in data){
                                if(ctrlShare == templateShare){
                                    this.advancedSearchForm.controls[ctrlShare].setValue(data[templateShare]);
                                }
                            }  
                          }   
                        }
                     }
         else if(item=="Template1 Edms")
         {
            if(this.edmsSearch)
            {
                for(let ctrl in this.advancedSearchForm.controls){
               for(let template in data){
                       if(ctrl == template){
                           this.advancedSearchForm.controls[ctrl].setValue(data[template]);
                   }
                  }
                }
         }
        }
     else if(item.name==this.nameData.name)
        {
            for(let ctrl in this.advancedSearchForm.controls){
            for(let ele of this.storeCriteria){
                        if(ctrl == ele.name){
                            this.advancedSearchForm.controls[ctrl].setValue(ele.value);
                        }
                      }       
              }
        }
   }
public clickOk(textValue)
{
  this.openSaveIcon.push(textValue);
  this.saveSearchValue = [];
  this.storeCriteria = [];
  for(let ctrl in this.advancedSearchForm.controls){
      let dummy= {
          name: ctrl,
          value: this.advancedSearchForm.controls[ctrl].value
      }
   this.saveSearchValue.push(dummy);
     }
     var dataList={name:this.textValue, criteria:this.saveSearchValue}
     this.nameData.push(dataList);
    this.textValue='';
    for(let i=0;i<this.nameData.length;i++)
    {
      this.storeCriteria = this.nameData[i].criteria;
    }
    
    }

    public clickCancel()
    {
        this.textValue='';
    }
    public closeCard()
    {
        this.cardClose=false;
    }
    public searchFile(){
        // this.attrFormChanged(this.advancedSearchForm);
    }
           //   method to assign attrForm, Advance SerachForm , Basic Form
    public attrFormChanged(event) {
        this.fullTextSearchInput= {}
        if(this.fileName.length <=0){
        this.KeyWordSearch=true;
        }else{
        this.KeyWordSearch=false;
        this.keyWordValue=
        {
            "searchParams":this.fileName
         }
        this.searchopen = false;
        let self = this;
        for (let item in event) {
            if (event[item] && event[item].controls) {
                this.formGroup = event[item]
                for (let item in this.formGroup.controls) {
                    if (this.formGroup.controls[item].value && this.formGroup.controls[item].value != "") {
                        this.fullTextSearchInput[item] = this.formGroup.controls[item].value;
                    } 
                }
            }
        }
        let keyValue =Object.assign({}, this.keyWordValue, this.fullTextSearchInput);
     let keyValueStringfy=JSON.stringify(keyValue)
    let colUrl = this.appURL + 'columns/'
    this.clientService.setUrl(colUrl);
    this.clientService.getClientData().subscribe(res =>{
        self.columnsForTable =   res.data;
        let fullTextUrl=self.appURL+'search/fullTextSearch/';
        self.clientService.setUrl(fullTextUrl,keyValueStringfy+'/0/10');
        self.clientService.getClientData().subscribe(res => {
            self.rowsForTable = res.data;
            self.searchopen = true;
            self.rowData=self.rowsForTable;
            self.rowDataBack=self.rowData;
            self.recordCount= self.rowData.length;
        });
    });
}
}
    public searchFormChanged(event) {
        this.searchopen = false;
        let self = this;
        for(let item in event){
            if(event[item] && event[item].controls){
                this.mainGroup=event[item]
            for(let item in this.mainGroup.controls){
                if (this.mainGroup.controls[item].value && this.mainGroup.controls[item].value != ''){
                this.objToBeSent[item]=this.mainGroup.controls[item].value;
                }
            }
            }
        }
        let colUrl = this.appURL + 'columns/'
        this.clientService.setUrl(colUrl);
        this.clientService.getClientData().subscribe(res =>{
            self.columnsForTable =   res.data;
            let urlForSearch = self.appURL +'search/';
            self.clientService.setUrl(urlForSearch,self.objToBeSent);
            self.clientService.getClientData().subscribe(res => {
                self.rowsForTable = res.data;
                self.searchopen = true;
                self.rowData=self.rowsForTable;
                self.rowDataBack=self.rowData;
                self.recordCount= self.rowData.length;
            });
        });
       
    }

    private advancedsearchFile()
    { 
        let self=this;
        if(this.attrOnly){
        let colDataUrl = self.appURL +'columns';
        this.clientService.setUrl(colDataUrl)
        this.clientService.getClientData().subscribe(res => {
            self.columnsForTable =   res.data;
            let rowDataUrl = this.appURL +'search/{"BUSINESS_AREA":"GBL","SOURCE_SYSTEM":"MANHATTAN","REGION":"EMEA","FUNCTION":"TA","TASK_NUMBER":"799984" }';
            this.clientService.setUrl(rowDataUrl);
            this.clientService.getClientData().subscribe(res => {
                self.rowsForTable = res.data;
                self.searchopen = true;
                self.rowData=self.rowsForTable;
                self.rowDataBack=self.rowData;
                self.recordCount= self.rowData.length;
            });
        });
    }else{
        let colDataUrl = self.appURL +'columns';
        this.clientService.setUrl(colDataUrl)
        this.clientService.getClientData().subscribe(res => {
            self.columnsForTable =   res.data;
        let fullTextUrl=self.appURL+'search/fullTextSearch/{"searchParams":"underwriting"}/0/10';
        this.clientService.setUrl(fullTextUrl)
        this.clientService.getClientData().subscribe(res => {
            self.rowsForTable = res.data;
            self.searchopen = true;
            self.rowData=self.rowsForTable;
            self.rowDataBack=self.rowData;
            self.recordCount= self.rowData.length;
        });
    });
    }
    
    }
        public formChanged(form){
            for(let item in form.controls){
                if(item == "TYPE_OF_SEARCH"  ){
                    if(form.controls[item].value == "Attribute Search"){
                        this.showFullTextSearch = false;
                    }else{
                        this.showFullTextSearch = true;
                    }
                    
                }
            }
        }
	public displayOnLookUp(form) {
        // this.verticalCardHeight ="550px";
        // this.verticalCardHeight ="250px";
        this.showFilteredTable = [];
        let formChanged:boolean = false;
       
        let dummy = []
        for (let item in form.controls) {
            if (form.controls[item].value && form.controls[item].value.length !=0  && form.controls[item].value != ' ' && form.controls[item].value != null) {
               formChanged= true;
                if (this.showFilteredTable.length <= 0) {
                        for (let i = 0; i < this.rowsForTable.length; i++) {
                            for (let j = 0; j < this.rowsForTable[i].length; j++) {
                                if (this.rowsForTable[i][j].value == form.controls[item].value ) {
                                      this.showFilteredTable.push(this.rowsForTable[i]);
                                    
                                }
                            }
                        }
                       this.rowData=this.showFilteredTable;
                }
                else {
                    let dummy = [];
                        for (let i = 0; i < this.showFilteredTable.length; i++) {
                            for (let j = 0; j < this.showFilteredTable[i].length; j++) {
                             if (this.showFilteredTable[i][j].value  == form.controls[item].value) {
                              dummy.push(this.showFilteredTable[i]);
                            
                             }
                          }
                        }
                    
                    this.rowData=dummy;
                }
            }
            else{
                if(!formChanged){
                    this.rowData= this.rowsForTable;
                }
            }
        }
    }
        public getVerticalSearchFilter(e: any) {
            // // this.rowSelectedÃ‚Â =Ã‚Â false; 
            // // this.verticalfilter = true;
            // this.searchVerticalFilter = e.filterDataInfo;
            // this.getVerFilterData = this.searchVerticalFilter
            
            // //this.getCloseSummaryToggle(event)
            // if(this.getVerFilterData.length==0){
              this.getVerFilterData=this.getData;
            // }
            // // this.pageStartIndex = 1;
            // // this.pageLastIndex = this.rowsPerPage;
            // // this.atFirstPage = true;
            // if(this.pageLastIndex > this.getVerFilterData.length){
            //     this.pageLastIndex = this.getVerFilterData.length;
            //     this.atLastPage
            // }
    
            // if(this.getVerFilterData.length < 20){
            //     this.gridHeight = this.getVerFilterData.length * 42 +115 + 'px';
            // }
            // else{
            //     this.gridHeight ="910px" ;
            // }
        }
        public rowSelectedEvent(event) {
            this.listOfSelectedRows = event;
        }

     public actionTriggered(event){
        if(event.actionItem=="Additional Info")
           {
              if(this.additionalInfoCard=true)
              this.showPostFilter = false;
                    {
                     this.widthtobeset ="73%"
                     this.verticalCardHeight = "550px";
                     this.additionalInfoData = event;
                     }
          }
}
  private closeSummaryCard(event)
     {
         this.additionalInfoCard = !this.additionalInfoCard;
         if(this.additionalInfoCard){
            this.showPostFilter = false;
         }
        this.widthtobeset = "98.5%";
        this.verticalCardHeight = "290px";
     
      }

      //method to capture most recent row selection in mdt-TableElement
      //also handles assigning data to additional info if open
      public mostRecentRowSelection(event){
          console.log(event)
        this.mostRecentData = event;
        if(this.additionalInfoCard){
            this.showPostFilter = false;
            let cardData={
                actionItem:"Additional Info",
                row:event
            }
            this.actionTriggered(cardData);
        }
      }

    //   method to close additional info card on post filter toggle
    public postFilterToggled(){
        this.showPostFilter = true;
        this.additionalInfoCard = false;
        this.widthtobeset = "98.5%";
        this.verticalCardHeight ="550px";
    }

    public setWidthEvent()
    {
        // this.verticalCardHeight ="290px";
    }
    public searchTable(searchAttr) {
        if (searchAttr == this.searchType[0]) {
            this.attrOnly = false;
            this.searchBoolean = true;
            this.expandSearch=false;
            this.searchTypeName='Content And Attributes';
        } else if (searchAttr == this.searchType[1]) {
            this.attrOnly = true;
            this.searchBoolean = false;
            this.expandSearch=true;
            this.searchTypeName='Attributes Only';
        }
    }
    public contentAndAttributes(){
    }

       // column level filter On Remove button  for table 
    public applyColFilterWithOutServer(event){
        if(event.length>0){
            this.rowData=this.rowDataBack;
            this.applyColFilter(event)
        }
       else{
        this.rowData=this.rowDataBack;
       }
    }
    // column level filter apply for table 
    public applyColFilter(event) {
        this.selectedFilterApply = [];
        let colSelectedValue = event[event.length-1];
        // for(let colSelectedValue of event){
        for(let entireRow of this.rowData){
            for(let entireRowDb of entireRow){
                if( colSelectedValue.colObj.dbColumnName==entireRowDb.dbColumnName && colSelectedValue.filterValData.indexOf(entireRowDb.value)>=0){
                    // if(colSelectedValue.filterValData.indexOf(entireRowDb.value)>=0){
                        this.selectedFilterApply.push(entireRow);
                        break;
                    // }
                    
                }
            }
            }
    // }
   this.rowData=this.selectedFilterApply
    }

    //method to trigger radio button change event
    private searchTableChange()
    {
        this.searchopen= false;
    }
}