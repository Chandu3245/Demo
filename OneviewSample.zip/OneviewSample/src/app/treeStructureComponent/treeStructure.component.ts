import { transition } from '@angular/animations';
import { HttpClientModule } from '@angular/common/http';
import { Component, ChangeDetectorRef, Output, EventEmitter, Inject, Input } from '@angular/core';
import { FormControl,  FormGroup, FormBuilder } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MatSnackBar } from '@angular/material';

import { ShareDataService } from './../services/share.data.service';
import { tree} from './treeJson';



@Component({
    selector: 'tree-structure-comp',
    templateUrl: './treeStructure.component.html',
    styleUrls: ['./treeStructure.component.scss']
})
export class TreeStructureComponent {
    private treenodes:any;
   
    
    @Input() nodes;
    @Input() parent;
    @Input() enableCheckBox;
    @Input() singleModeSelection;
    @Input() typeofIcontoOpen;
    @Input() typeofIcontoClose;
    @Input() treeNodes;
    @Input() enableFavourities;
    @Input() filterTree;
    @Input() enableInputTree:boolean;
     @Input() enableInfoIcon;
     @Input() sourceSystem;
     @Input() insuredName:any;

     @Output() listOfFavouritiesEmit: EventEmitter<any> = new EventEmitter();
    
    constructor(@Inject(ShareDataService) private sharedService:ShareDataService) {
       
        // this.enableCheckBox =true;
        // let url = "https://cordoc-dev.swissreapps-np.com/c1v/service/loadTreeDocuments/%7B%22SOURCE_SYSTEM%22:%22CORFLOW%22,%22ADD_SRC_SYS%22:%22DGF,MAN,MANHATTAN,IPA,RES%22,%22FUNCTION%22:%22UW%22,%22INSURED_NAME%22:%22Jaguar%20Holdings%20Inc.%22%7D"
        // this.sharedService.setTreeDataList(url);
        // this.sharedService.getTreeDataList().subscribe(res => {
        //     this.treenodes = res;
        //     this.treenodes[0].isOpen=false;
        //     this.treenodes[0].isCheck = false;
        //     // this.state= true;
        //     console.log(this.treenodes);
        // });
       
    }

    private listOfFavouritiesEvent(event)
    {
        this.listOfFavouritiesEmit.emit(event);
    }
    
}