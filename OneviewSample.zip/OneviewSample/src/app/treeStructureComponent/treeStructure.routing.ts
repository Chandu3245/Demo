import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TreeStructureComponent } from './treeStructure.component';

const routes: Routes = [
  { path: '', component: TreeStructureComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);