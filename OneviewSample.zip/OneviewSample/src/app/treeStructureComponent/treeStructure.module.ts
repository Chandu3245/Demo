import { CommonModule } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MyMaterialModule } from '../material.module';
//import { SaveLoadFormComponent } from './../saveLoadFormComponent/saveLoadForm.component';
import { TreeComponent } from '../treeComponent/tree.component';
import { TreeStructureComponent } from './treeStructure.component';
import { routing } from './treeStructure.routing';

@NgModule({
  declarations: [
    TreeStructureComponent , 
    TreeComponent,
        
  ],
  imports: [
    routing,
    // SaveLoadFormModule,
    CommonModule,FormsModule,MyMaterialModule,ReactiveFormsModule],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  //exports:[UploadComponent],
 
  
})
export class TreeStructuteModule { }
