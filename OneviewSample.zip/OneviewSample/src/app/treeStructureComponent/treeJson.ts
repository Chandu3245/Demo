export var tree =
{
	"treeHeader":
	[{
	"root": true,
	"leaf": false,
	"level": 0,
	"children": [{
		"root": false,
		"leaf": false,
		"level": 1,
		"children":[],
		"key": "DEAL_ID1",
		"value": "CFDL5038",
		"isCheck": "false",
		"isOpen": "true"
	}],
	"key": "root1",
	"value": "root",
	"isCheck": "false",
	"isOpen": "true"
}]
}