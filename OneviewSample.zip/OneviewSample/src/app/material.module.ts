import { CommonModule }  from '@angular/common';
import { NgModule, ModuleWithProviders }      from '@angular/core';
import {MatButtonModule, MatCheckboxModule,MatIconModule,MatInputModule,MatAutocompleteModule,
  MatDatepickerModule,
    MatRippleModule,MatRadioModule,MatSelectModule,MatChipsModule,MatMenuModule,MatSidenavModule,
MatDialogModule,MatSliderModule,MatTabsModule,MatCardModule,MatExpansionModule,MatProgressSpinnerModule,MatTooltipModule,MatProgressBarModule,MatNativeDateModule,MatToolbarModule,MatStepperModule,MatSlideToggleModule ,MatSnackBarModule
} from '@angular/material';


@NgModule({
  
  imports: [
    CommonModule,
   MatButtonModule,MatMenuModule, MatCheckboxModule,MatIconModule,MatInputModule
   ,MatAutocompleteModule,MatDatepickerModule,MatRippleModule,MatRadioModule,MatSelectModule,MatChipsModule,
MatDialogModule,MatSliderModule,MatTabsModule,MatCardModule,MatExpansionModule,MatProgressSpinnerModule,MatTooltipModule,MatProgressBarModule,MatNativeDateModule,MatToolbarModule,MatStepperModule,MatSlideToggleModule,
MatSnackBarModule,MatSidenavModule
    
  ],
  exports: [
   
     CommonModule,
   MatButtonModule,MatMenuModule, MatCheckboxModule,MatIconModule,MatInputModule,MatAutocompleteModule,
   MatDatepickerModule,MatRippleModule,MatRadioModule,MatSelectModule,MatChipsModule,
MatDialogModule,MatSliderModule,MatTabsModule,MatCardModule,MatExpansionModule,MatProgressSpinnerModule,MatTooltipModule,MatProgressBarModule,MatNativeDateModule,MatToolbarModule,MatStepperModule,MatSlideToggleModule,
MatSnackBarModule,MatSidenavModule
   
  ],

})
export class MyMaterialModule {
  
  }
