import { ModuleWithProviders  } from '@angular/core';  
import { Routes, RouterModule } from '@angular/router'; 

import {ExplorerResultComponent} from './explorerResultComponent';
import {SearchComponent} from './searchComponent';
import {UploadComponent} from './uploadComponent';


const appRoutes: Routes = [
 
    // { path: 'search',loadChildren:'./searchComponent/search.module#SearchModule'},
    //  { path: 'upload',loadChildren:'./uploadComponent/upload.module#UploadModule'},
    // // { path: 'dashboard',loadChildren:'./dashboardComponent/dashboard.module#DashboardModule' },
    // { path: 'explorer',loadChildren:'./explorerResultComponent/explorer.result.module#ExplorerResultModule' },
     { path: 'search', component:SearchComponent},
     { path: 'upload', component:UploadComponent},
    // { path: 'dashboard',loadChildren:'./dashboardComponent/dashboard.module#DashboardModule' },
    { path: 'explorer', component:ExplorerResultComponent},
    { path: '', redirectTo: '/explorer', pathMatch: 'full'
  },
  ];
  export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);



  