import { docName } from './../uploadComponent/documentTypeExtensions';

import { Component, Input, Output, EventEmitter, OnInit, Inject ,OnChanges, ChangeDetectorRef} from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

import { ClientDataServices } from './clientService';
import { environment } from './../../environments/environment';
import { ShareDataService} from '../services';


@Component({
    selector: 'upload-queue',
    templateUrl: './uploadQueue.component.html',
    styleUrls: ['./uploadQueue.component.scss'],
    providers:[ClientDataServices]
})
export class UploadQueueComponent implements OnInit {
      
   @Input() uploadList;
   @Input() fileData;
   @Input() listOfDocTypectrl;
   @Input() selectedFilesForUpload;
   @Input() btnEnable;
   @Input() uploadedList;
   @Input() mainForm;
   @Input() progressFlag;

   @Output() emitUploadFiles: EventEmitter<any> = new EventEmitter();
   @Output() clearQueue: EventEmitter<any> = new EventEmitter()

   private typeHoverIndex: number = -1;
    private dateHoverIndex: number = -1;
    private uploadUnSuccess: boolean = false;
    private options:FormGroup
    private   filteredOptions: any;
    public docTypeVals = [];
    public documnetTypeandCategory: any;
    public docTypeKeys: any;
    private appURL:string;
    private docTypeCheck = []; 
    private uploadClick:any;
    private showDocDateError= [];
    private showDocNameError= [];
    private docNameExtensionList = [];

    constructor(  @Inject(ShareDataService) private shareDateService: ShareDataService, @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef,
                        @Inject(ClientDataServices) private clientService: ClientDataServices, @Inject(FormBuilder) private fb: FormBuilder) {
   
             
             this.options = fb.group({
             hideRequired: false,
             floatLabel: 'auto',
          });
          this.appURL=environment.appURL;
          this.docNameExtensionList = docName;
            }

    ngOnInit() {
   
    }
    ngOnChanges(){
        if(this.mainForm){
            this.getDocType();
        }
    }

    public getCancel() {
        // this.uploadUnSuccess = true;
        this.uploadList= [];
        this.fileData = [];
        this.clearQueue.emit()
    }

    public uploadFile() {
        
        this.uploadClick = true;
       if(this.docTypeCheck.indexOf(true) == -1  &&  this.showDocNameError.indexOf(true) == -1){
        
            this.emitUploadFiles.emit(this.uploadList);
    
      
    }
    } 
 
    public optionControlToLookup(indexOfFileBeingSet) {
        this.filteredOptions = this.listOfDocTypectrl[indexOfFileBeingSet].valueChanges
            .startWith(null)
            .map(val => this.filterResult(val, this.docTypeKeys, indexOfFileBeingSet));
    }

    public filterResult(val, options, indexOfFileBeingSet) {
        return val ? options.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0) : options
    }

    public testFun(event, i) {
        this.uploadList[i].documentType = event.option.value
        this.updateDocType(this.uploadList[i].documentType, i)
    }
    //method to apply selected document date to all file
    public docDateForAll(j) {
        
         for (let i = 0; i < this.uploadList.length; i++) {
             if(this.uploadList[i].documentId == ''){
                this.uploadList[i].documentDate = this.uploadList[j].documentDate;
             }
             
         }
     }
    //method to apply selected document type to all file
     public docTypeForAll(j,docTypeName?) {
        for (let i = 0; i < this.uploadList.length; i++) {
            if(this.uploadList[i].documentId == ''){
                this.uploadList[i].documentType = this.uploadList[j].documentType;
                this.updateDocType(this.uploadList[i].documentType, i)
             }
             if(this.uploadList[i].documentType != ''){
                this.docTypeValueChanges(docTypeName,i)
             }
            
        }
       
    }
    //method to update category based on type selection
     public updateDocType(item, i) {
        let category: any = ''
        for (var datakey in this.documnetTypeandCategory) {
            let dummy1 = this.documnetTypeandCategory[datakey];
            if (dummy1.indexOf(item) > -1) {
                category = datakey;
                this.ref.detectChanges();
                break
            }
        }

        this.uploadList[i].documentCategory = category;
    }
    //method to get type and category
    public getDocType() {
        let self = this;
        let objToBeSent:any={};
        for(let item in this.mainForm.controls){
            objToBeSent[item] = this.mainForm.controls[item].value;
        }
        let docTypeUrl = environment.appURL+'document/getDocTypes/';
        this.clientService.setUrl(docTypeUrl,objToBeSent);
        this.clientService.getClientData().subscribe(function (typeAndCategory) {
            if (typeAndCategory.data) {

                self.docTypeKeys = [];
                self.docTypeVals = Object.keys(typeAndCategory.data);
                self.documnetTypeandCategory = typeAndCategory.data;
                for (var datakey in typeAndCategory.data) {
                    let dummy = typeAndCategory.data[datakey];
                    for (let i = 0; i < dummy.length; i++) {
                        if (self.docTypeKeys.indexOf(dummy[i]) == -1) {
                            self.docTypeKeys.push(dummy[i]);
                        }
                    }
                }

            }
            self.ref.detectChanges();

        });
   }
 //method to delete file
    public getRemove(index) {
        
                this.selectedFilesForUpload.push(this.uploadList[index]);
                this.uploadList[index].fileSelected = true;
                let dummySelectedFile = [];
                let dummyUploadList = [];
                dummySelectedFile = this.selectedFilesForUpload;
                dummyUploadList = this.uploadList;
                for (let selFl of this.selectedFilesForUpload) {
                    if (this.uploadList.indexOf(selFl) >= 0) {
                        this.uploadList.splice(this.uploadList.indexOf(selFl), 1);
                        this.fileData.splice(this.uploadList.indexOf(selFl), 1);
                    }
        
                }
                this.docTypeCheck.splice(index,1);
                this.showDocNameError.splice(index,1);
            }

            //method to get user typed value to check valid or not
            public docTypeValueChanges(docTypeValue,index)
            {
                for(let item of this.docTypeKeys ){
                if(docTypeValue != item && docTypeValue != ""){
                    this.docTypeCheck[index] = true;
                }
                else{
                    this.docTypeCheck[index]  =false;
                    break;
                }
            }
            }
//method to check valid document name
            public docNameChange(event,docName,index){
                let lastIndex = docName.lastIndexOf(".");
              let docExt = docName.substring( (lastIndex + 1), docName.length);
             for(let i=0;i< this.docNameExtensionList.length;i++){
                 if( this.docNameExtensionList[i].toLowerCase() != docExt.toLowerCase())
                 {
                       this.showDocNameError[index] = true;
                 }
                 else{
                    this.showDocNameError[index] = false;
                    break;
                 }
             
            }
            
        }

       
       
}

