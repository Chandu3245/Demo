import { Injectable,Inject } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import {Http,Headers,RequestOptions,HttpModule} from '@angular/http';

import "rxjs/add/operator/map";

@Injectable()
export class ClientDataServices{
    private url:any;
    private attributesToGetData:any;
    constructor(@Inject(Http) private _http: Http){
        
    }
    
    public setUrl(url,attr?){
        if(attr){
            if(typeof(attr) !='string'){
                this.attributesToGetData = JSON.stringify(attr);    
            }else{
                this.attributesToGetData = attr;
            } 
            this.url = url+this.attributesToGetData;
        }else{
            this.url = url
        }
        
        
    }
    
    
    public getClientData(){
        // return this._http.get(this.url).map(res => res.json());
        return this._http.get(this.url).map(response => response.json());
       
    }
    
}