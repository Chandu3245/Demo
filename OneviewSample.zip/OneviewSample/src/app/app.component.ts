import { Component,ElementRef,DoCheck,OnInit,Inject } from '@angular/core';
import {Router} from '@angular/router';
import {OverlayContainer} from '@angular/cdk/overlay';
import{ environment } from '../environments/environment';
import { ClientDataService,ShareDataService,WindowRef } from './services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements DoCheck,OnInit {
  
  private showExploreComp:any = false;
  private sideNavOpen:boolean= false;
  private viewHeadlineIcon:any = true;
  private rightArrowlineIcon:any = false;
  private sideNavWithNames:any = true;
  private sideNavWithOutNames:any = false;
  private leftArrowlineIcon:any = false;
  private showOnlyIcons:boolean = false;
  private showminimizeSideNavIcon:boolean = false;
  private compSelected:any;
  private checkshowminimizeSideNavIconStatus:boolean = true;
  private navItemName:string = "";
  private userName:any=''
  private trans1:any = 'Business Documents Transactional';
  private trans2:any = 'Business Documents non-Transactional';
  private isMobileLen:any;
  private isTabLen:any=[320, 414];
  private deviceType:any='';
  private deviceOrien:any='';
  private appURL:string;
   private sidenavWidth:string="175px";
   private toolbarMargin:String = "0px";
   private navMode :String='side';
   private activeSideItem:any=0;
   private availTheme:any=[
      {themeName:'Indigo',value:"indigo-theme",activeTheme:true},
      {themeName:'Green',value:"green-theme",activeTheme:false},
      {themeName:'Purple',value:"purple-theme",activeTheme:false}
    ]
   private theme:any="indigo-theme"
   private selectedTheme:any=0;
   private transitionFieldUrl:any;
   private UrlForForm:any;

  constructor(@Inject(ElementRef) private _element: ElementRef,@Inject(OverlayContainer) private overlayContainer: OverlayContainer,
  @Inject(Router) private router: Router, 
  @Inject(ClientDataService) private clientService:ClientDataService,
  @Inject(ShareDataService)  private sharedataService:ShareDataService,
  @Inject(WindowRef)  private winref:WindowRef
              ) {
                this._element.nativeElement.classList.add("indigo-theme")
                 this.overlayContainer.getContainerElement().classList.add("indigo-theme");
        this.appURL = environment.appURL;
       this.isMobileLen =[320, 414];
       this.getuserName();
      
      let self = this;
      window.addEventListener("orientationchange", function() {
        if(typeof((<any>window).screen.orientation) !== 'undefined'){
          self.deviceOrien = (<any>window).screen.orientation.type ;
        }else{
          self.deviceOrien = 'landscape-primary';
        }
        self.sharedataService.setOrientation(self.deviceOrien);
        if((<any>window).screen.width >= 320 && window.screen.width <= 767){
            self.sharedataService.setDevice('isMobile');
            self.deviceType = 'isMobile';
        } else if((<any>window).screen.width >= 768 && window.screen.width <= 1023){
            self.sharedataService.setDevice('isTab');
            self.deviceType = 'isTab';
        }
        else{
            self.sharedataService.setDevice('isWindow');
            self.deviceType = 'isWindow';
        }
        
      }, false);
  }
  
  ngOnInit(){
    
    this.setDeviceDetails();
    this.router.navigateByUrl('/search');
    this.UrlForForm =  this.appURL+"appUserRoles"; 
   this.clientService.setUrl(this.UrlForForm);
   let self=this;
   this.clientService.getClientData().subscribe(function (res) {
     self.transitionFieldUrl=res;
     self.sharedataService.SetMainFormObj(res);
     self.sharedataService.setUploadForm(self.transitionFieldUrl);
   });
  }
  ngDoCheck(){ 
    this.navItemName = window.location.href.substr(window.location.href.lastIndexOf('/') + 1);
  }
  onorientationchange(event){
  }
  
  private setDeviceDetails(){
    if(typeof((<any>window).screen.orientation) !== 'undefined'){
      this.deviceOrien = (<any>window).screen.orientation.type ;
    }else{
      this.deviceOrien = 'landscape-primary';
    }
        this.sharedataService.setOrientation(this.deviceOrien);
        if((<any>window).screen.width >= 320 && window.screen.width <= 767){
            this.sharedataService.setDevice('isMobile');
            this.deviceType = 'isMobile';
        } else if((<any>window).screen.width >= 768 && window.screen.width <= 1023){
            this.sharedataService.setDevice('isTab');
            this.deviceType = 'isTab';
        }
        else{
            this.sharedataService.setDevice('isWindow');
            this.deviceType = 'isWindow';
        }
  }
  
  private getuserName(){
      let self=this;
      let getNameUrl = this.appURL + 'users';
      this.clientService.setUrl(getNameUrl);
      this.clientService.getClientData().subscribe(res => self.userName = res);
  }
  title = 'app works!';
  toggleFullscreen() {
    let elem = this._element.nativeElement.querySelector('.demo-content');
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.webkitRequestFullScreen) {
      elem.webkitRequestFullScreen();
    } else if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
    } else if (elem.msRequestFullScreen) {
      elem.msRequestFullScreen();
    }
  }
  
  public changeRoute(routeName,sideNavRef){
    
    if(this.checkshowminimizeSideNavIconStatus){
     
        if(this.compSelected != routeName){
        
          this.showminimizeSideNavIcon = !this.showminimizeSideNavIcon;
        }
    this.checkshowminimizeSideNavIconStatus = false;
    }
    
    this.compSelected = routeName;
    this.router.navigateByUrl(routeName);
   this.navItemName = routeName.substr(1, routeName.length);
   if(this.navItemName != 'expResult'){
        this.showExploreComp = false;
      }
    
  }
  public openExploreComp(sideNavRef){
   if(this.checkshowminimizeSideNavIconStatus){
      this.showminimizeSideNavIcon = !this.showminimizeSideNavIcon;
      this.checkshowminimizeSideNavIconStatus = false;
      
   }
   if(this.showExploreComp){
       this.sharedataService.setSideNavStatus(true);
   }
    this.showExploreComp = !this.showExploreComp;
      if(!this.sideNavWithNames){
          this.sideNavWithNames = !this.sideNavWithNames;
          this.viewHeadlineIcon = !this.viewHeadlineIcon;
      }
     
  }
  
  public showAndViewIcon(clickValue:any){
   
     this.sideNavWithNames = !this.sideNavWithNames;
     this.sideNavWithOutNames = !this.sideNavWithOutNames; 
      this.viewHeadlineIcon = !this.viewHeadlineIcon;
      this.rightArrowlineIcon = !this.rightArrowlineIcon;
      this.toolbarMargin="10px";
    
  }
   
   public showIconNames(){
      this.viewHeadlineIcon = !this.viewHeadlineIcon;
       this.sideNavWithNames = !this.sideNavWithNames;
       this.sidenavWidth="175px"; 
       this.toolbarMargin = "0px"
   }
   
   public minimizeSideNav(){
    this.sidenavWidth="60px"; 
    this.toolbarMargin = "20px"
     this.sideNavWithNames = false;
      this.viewHeadlineIcon = !this.viewHeadlineIcon;
      if(this.navItemName == 'expResult'){
        this.showExploreComp = false;
      }
      if(this.showExploreComp){
        this.showExploreComp = !this.showExploreComp;
      }
   }
   
   public closeLeftPanel(){
     this.showminimizeSideNavIcon =false;
     this.sideNavOpen = !this.sideNavOpen;
     this.sharedataService.setSideNavStatus(this.sideNavOpen);
     this.checkshowminimizeSideNavIconStatus = true;
    //  this.compSelected="";
    //  this.navItemName = "";
     this.sidenavWidth = "120";
     if (window.innerWidth >992 ) {
      this.navMode = "side";
      } else {
      this.navMode = "open";
      } 
    
   }
  
   public themeFunction(themevalue,selTheme){
    this.theme=themevalue;
    for(let themeVal of this.availTheme){
      themeVal.activeTheme=false
    }
    selTheme.activeTheme=true
    if(themevalue=="indigo-theme"){
    this._element.nativeElement.classList.add("indigo-theme");
    this.overlayContainer.getContainerElement().classList.add("indigo-theme");
    this._element.nativeElement.classList.remove("green-theme");
    this.overlayContainer.getContainerElement().classList.remove("green-theme");
    this._element.nativeElement.classList.remove("purple-theme");
    this.overlayContainer.getContainerElement().classList.remove("purple-theme");
    }
    else if(themevalue=="green-theme"){
      this._element.nativeElement.classList.add("green-theme");
      this.overlayContainer.getContainerElement().classList.add("green-theme");
      this._element.nativeElement.classList.remove("indigo-theme");
      this.overlayContainer.getContainerElement().classList.remove("indigo-theme");
      this._element.nativeElement.classList.remove("purple-theme");
      this.overlayContainer.getContainerElement().classList.remove("purple-theme");
    }
    else{
      this._element.nativeElement.classList.add("purple-theme");
      this.overlayContainer.getContainerElement().classList.add("purple-theme");
      this._element.nativeElement.classList.remove("green-theme");
      this.overlayContainer.getContainerElement().classList.remove("green-theme");
      this._element.nativeElement.classList.remove("indigo-theme");
      this.overlayContainer.getContainerElement().classList.remove("indigo-theme");
    }
   }
}
  