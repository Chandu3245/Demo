import { CommonModule } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, FormBuilder , ReactiveFormsModule } from '@angular/forms';

import { MdtTableModule } from './../../lib/modules/mdt-table/mdt-table.module';
import { MyMaterialModule } from '../material.module';
import { ClientDataService } from './../services/app.service';
// import {SearchComponent} from './search.component';
// import {routing} from './search.routing';
import { SaveLoadFormComponent } from './saveLoadForm.component';

@NgModule({
  declarations: [
        SaveLoadFormComponent,
        //SaveLoadFormComponent
        
  ],

imports: [ 
  //routing,
CommonModule,MyMaterialModule,
ReactiveFormsModule ,FormsModule,MdtTableModule],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  // exports:[SearchComponent]
  providers:[ClientDataService]
})
export class SaveLoadFormModule { 

}
