import { DataService } from './../../lib/modules/mdt-table/services/DataService';
import { MdtCellDoubleClick } from './../../lib/modules/mdt-table/directives/mdt-cell-doubleClick.directive';
import { Component, OnInit, Inject,ChangeDetectorRef} from '@angular/core'
import {MAT_DIALOG_DATA,MatSnackBar} from '@angular/material';

import{ environment } from './../../environments/environment';
import { ClientDataService,ShareDataService } from '../services';

@Component({
    selector:'available-selection-config-folder',
    templateUrl:'./available-Selection-Config.component.html',
    styleUrls:['./available-Selection-Config.component.scss']
})
export class AvailableSelectionConfigComponent implements OnInit  {

    private attrList:any=[];

    private listOfAttrSelected:any=[];
    private selectedAttributeList:any=[];
    private saveList=[];
    private customizationUpArray:any=-1;
    private customizationDownArray:any=-2;
    private appURL:string;
    private moveToIndex:any;
    private savingTree:boolean=false;
    private saveObject:any;

    private availableDialogData:any=[];
    private defaultDisplayYes:any=[];
    private defaultDisplayNo:any=[];
    private chosenAvailableColumn:any=[];
    private selectedColumnsLeftArrowCheckbox:boolean=false;
    private selectedColumnsRightArrowCheckbox:boolean=false;
    private dragStartSection:string='';
    private chosenSelectedList: any= [];
    private selCols:any=[];
    constructor(@Inject(MAT_DIALOG_DATA) public dailogData:any,
    @Inject(ShareDataService) public shareDataService:ShareDataService,
    @Inject(ClientDataService) private clientDataService: ClientDataService,
    @Inject(DataService) private dataService: DataService,
    @Inject(MatSnackBar) public snackBar: MatSnackBar,
    @Inject(ChangeDetectorRef) public ref:ChangeDetectorRef){
        //this.appURL = environment.appURL;
    }
    ngOnInit(){
        console.log(this.dailogData)
        this.availableDialogData=this.dailogData;
       for (let defaultIndex of this.availableDialogData)
       if(defaultIndex.defaultDisplayInd=="N"){
        this.defaultDisplayNo.push(defaultIndex);
       }
       else{
        this.defaultDisplayYes.push(defaultIndex)
       }
    }

    public draggingStart(event,dragStartFlag){
        this.dragStartSection = dragStartFlag
    }
    
    public onDrop(evn,col:any=[],dragStopflag){
        let dropColumn = evn;
       
        if(dragStopflag == 0){
            if(dragStopflag != this.dragStartSection){
                this.addToSelectedColumns();
            }else{
                this.defaultDisplayNo = this.dataService.swapItemList(col,this.chosenAvailableColumn, this.defaultDisplayNo,0);
                this.ref.detectChanges();
            }
            
        }
   }
//SelectingData from available selection to selected section
    public availableSelectionChanged(element, event) {
        if (event.checked) {
            this.chosenAvailableColumn.push(element);
            this.selectedColumnsRightArrowCheckbox=true;
        } else if (this.chosenAvailableColumn.indexOf(element) >= 0) {
            this.chosenAvailableColumn.splice(this.chosenAvailableColumn.indexOf(element, 1));
            this.selectedColumnsRightArrowCheckbox=true;
        }
    }

//SelectingData from Selected selection to selected section by CheckBox
    public selectedSelctionChanged(element, event, ind?) {
        if (event.checked) {
            this.chosenSelectedList.push(element);
            this.selectedColumnsLeftArrowCheckbox=true;
        } else {
            if (this.chosenSelectedList.indexOf(element) >= 0) {
                this.chosenSelectedList.splice(this.chosenSelectedList.indexOf(element), 1);
            }
        }
    }
////transferringData from Selected selection to Available  section on middle button click
    public removeFromSelectedColumns() {
             for (let i = 0; i < this.chosenSelectedList.length; i++) {
                let eleIndex = this.defaultDisplayYes.indexOf(this.chosenSelectedList[i]);
                let dummy = this.defaultDisplayYes.splice(eleIndex, 1)
                this.selCols.push(dummy[0]);
            }
          this.defaultDisplayNo = this.defaultDisplayNo.concat(this.chosenSelectedList);
              this.chosenSelectedList = [];
    
            //   if (this.chosenSelectedList.length ==1) {
            //     this.selectSelectedColumns = false;
            // }
            // else{
            //     this.selectSelectedColumns = false;
            // }
            // this.selectedColumnsLeftArrowCheckbox=false;
        }

    //transferringData from available selection to selected section on middle button click
    public addToSelectedColumns() {
        for (let i = 0; i < this.chosenAvailableColumn.length; i++) {
            let eleIndex = this.defaultDisplayNo.indexOf(this.chosenAvailableColumn[i]);
            this.defaultDisplayNo.splice(eleIndex, 1);
        }
        this.defaultDisplayYes = this.defaultDisplayYes.concat(this.chosenAvailableColumn);
        this.chosenAvailableColumn = [];
    }
    //save available Selection Config Value on Button  
    public saveColSetting(){
        console.log(this.defaultDisplayYes)
        for(let item of this.defaultDisplayYes){
           if(this.availableDialogData.indexOf(item)>0){
            this.availableDialogData[this.availableDialogData.indexOf(item)].defaultDisplayInd = 'Y'
           }
        }
        for(let item of this.defaultDisplayNo){
            if(this.availableDialogData.indexOf(item)>0){
             this.availableDialogData[this.availableDialogData.indexOf(item)].defaultDisplayInd = 'N'
            }
         }
    //    this.shareDataService.setAttrObj(this.availableDialogData)
    }
}