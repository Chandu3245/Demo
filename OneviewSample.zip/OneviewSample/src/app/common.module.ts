import { CommonModule } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { FilterPipe } from './pipes/filter.pipe';
import { SortPipe } from './pipes/sort.pipe';
//import { SaveLoadFormComponent } from './../saveLoadFormComponent/saveLoadForm.component';




@NgModule({
  declarations: [
    FilterPipe,SortPipe
  ],
  imports: [],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  exports:[FilterPipe,SortPipe],
 
  
})
export class OneViewCommonModule { }
