import { SearchFormComponent } from './searchFormComponent/search-form.component';
import { CommonModule,LocationStrategy, HashLocationStrategy } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { HttpModule,BrowserXhr } from '@angular/http';
// import { MaterialModule } from '@angular/material';
import { DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import { RouterModule, Routes } from '@angular/router';

import { AdditionalInfoComponent } from './additionalInfoComponent/additionalInfo.component';
// import{AdditionalInfoModule} from './additionalInfoComponent/additionalinfo.module'
import { AppComponent } from './app.component';
import {routing} from './app.routing';
import {CustomBrowserXhr} from './custom-browser-xhr';
import { SwissRe_DATE_FORMATS, SwissReDateAdapter } from './customDateAdapter';
import { CustomizeFolderComponent } from './customizeFolderComponent/customizeFolder.component';
import { AvailableSelectionConfigComponent } from './availableSelectionConfig/available-Selection-Config.component';
import { OneViewCommonModule } from './common.module';
import {ExplorerComponent } from './explorerComponent/explorer.component';
import { ExplorerResultComponent} from './explorerResultComponent/explorer.result.component';
import {FileDragDropComponent} from './fileDragDropComponent/fileDragDrop.Component';
import { MdtTableModule } from './../lib/modules/mdt-table/mdt-table.module';
import { MyMaterialModule } from './material.module';
// import { SearchModule } from './SearchComponent/search-module';
import { SaveLoadFormComponent } from './saveLoadFormComponent/saveLoadForm.component';
import { SearchComponent} from './searchComponent/search.component';
import { ClientDataService,WindowRef,ShareDataService,ShareJsonData } from './services';
import { TreeComponent } from './treeComponent/tree.component';
import { TreeStructureComponent } from './treeStructureComponent/treeStructure.component';
import { TreeStructuteModule } from './treeStructureComponent/treeStructure.module';
import { UploadComponent} from './uploadComponent/upload.component';
import{UploadQueueComponent} from'./uploadQueueComponent/uploadQueue.component';
import {ClientDataServices} from './uploadComponent/clientService';
import { VerticalFilterModule } from './verticalFilterComponent/vertical.filter.module';

// upload Related
// import { AngularFileDropzoneModule } from 'angular-file-dropzone'
// import { FileDropModule } from 'angular2-file-drop';
import { DragDropDirectiveModule} from "angular4-drag-drop";


@NgModule({
  declarations: [
    AppComponent,SearchComponent,ExplorerComponent,SaveLoadFormComponent,ExplorerResultComponent,
    UploadComponent,AdditionalInfoComponent, CustomizeFolderComponent,TreeComponent, TreeStructureComponent,
    FileDragDropComponent,UploadQueueComponent,SearchFormComponent,AvailableSelectionConfigComponent

  ],
  imports: [
    BrowserModule, FormsModule,ReactiveFormsModule,OneViewCommonModule,
    HttpModule,MyMaterialModule,routing,VerticalFilterModule,
    // SaveLoadFormModule,
     BrowserAnimationsModule,MdtTableModule,
     DragDropDirectiveModule
    //  Ng2FileDropModule,
    //  Ng2FileDropModule,
    //  AdditionalInfoModule,
    //  FileDropModule
  ],
  providers:  [ ClientDataServices,ClientDataService,WindowRef,
    ShareDataService,ShareJsonData, 
    { provide: BrowserXhr, useClass: CustomBrowserXhr }, 
    {
      provide: DateAdapter, useClass: SwissReDateAdapter
  },
  {
      provide: MAT_DATE_FORMATS, useValue: SwissRe_DATE_FORMATS
  },
  { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],

  entryComponents:[CustomizeFolderComponent,AvailableSelectionConfigComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }


// @NgModule({
//   declarations: [
//     AppComponent
//    ],
//   imports: [
//     BrowserModule, FormsModule,ReactiveFormsModule,
//     HttpModule,,
//     MyMaterialModule, BrowserAnimationsModule
    

//   ],
//   providers: [ClientDataService,WindowRef,ShareDataService,ShareJsonData],

//   bootstrap: [AppComponent]
// })
// export class AppModule { }
