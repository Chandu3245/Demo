import { Component, ChangeDetectorRef, Input, Output, EventEmitter, OnInit, AfterViewInit,Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder ,Validators} from '@angular/forms';
import { MatSnackBar,MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


import { docName } from './../uploadComponent/documentTypeExtensions';
import{ environment } from '../../environments/environment';
import { ClientDataService } from './../services/app.service';
import { ShareDataService } from '../services/share.data.service';
import { AvailableSelectionConfigComponent }  from  './../availableSelectionConfig/available-Selection-Config.component';


@Component({
    selector: 'search-form',
    templateUrl: './search-form.component.html',
    styleUrls: ['./search-form.component.scss']
})
export class SearchFormComponent implements OnInit {
    @Input() uploadModel;
    @Input() transitionFieldUrl;
    @Input() formName;
    @Input() reloadSaveLoad;
    @Input() mainFormInvalid;
    @Input() attrFormInvalid;
    @Input() parentComp;
    @Input() availSelectedConfig;
    @Input() searchMode:any;
    @Output() formValueChangeEvent:EventEmitter<any> = new EventEmitter();
    @Output() attrFormChangeEvent:EventEmitter<any> = new EventEmitter();
    

    private advancedSearchForm: FormGroup;
    private basicSearchForm: FormGroup;
    public cardClose: boolean = false;
    public textValue: string;
    private sizeOfInput:any;
    private setSelectValue:any;
    private openSaveIcon: any = ["no search "];
    private openClickicon: any=[];
    public saveSearchValue: any = [];
    private saveName: any;
    private nameData: any = [];
    private storeCriteria: any = [];
    private spinnerFlagTransactional:boolean=false;;
    private spinnerStrokeWidth:any="6%";
    private spinnerDiameter:any="35";
    private clearAttrFieldValue:any;
    private showAttrForm:boolean=false;
    private attrForm:FormGroup;
    private attrResponseObj:any;
   private clearFieldValue:any="";
   private appURL:string;
   private inputVal:any;
   private defaultAttrIndex:any=[];
   private docFormat:any=[];
   private basicFormUrl:any;
   private getBasicFormUrl:any;
   private displayBasicForm:any=[];
   private convertedVal:any;
   private categoryTypeCombo:any;
    constructor(@Inject(FormBuilder) private fb: FormBuilder,
    @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef, 
    @Inject(ClientDataService) private clientService: ClientDataService,
    @Inject(ShareDataService) public shareDataService:ShareDataService,
    @Inject(MatSnackBar) public snackBar: MatSnackBar,
    @Inject(MatDialog) public dialog: MatDialog) {
        this.appURL = environment.appURL;
    }
    ngOnInit() {
        this.docFormat =docName;
        if(this.searchMode == 'attributeOnly'){
            this.spinnerFlagTransactional = true;
            let mainForm= this.shareDataService.getMainObj();
            if(mainForm){
             this.spinnerFlagTransactional=false;
             this.mapLookup(mainForm);
             this.initializeForms();
            }else{
             let self=this;
             this.shareDataService.getUploadForm().subscribe(res=>{
                 self.spinnerFlagTransactional=false;
                self.mapLookup(res);
                self.initializeForms();
           });
        }
        this.getBasicFieldUrl();
    }else{
        // this.mapLookup(this.uploadModel)
        this.spinnerFlagTransactional = false;
        this.initializeForms();
    }
        
        // //Basic Form Url code 
       
       
    }
    ngOnChanges() {
        if(this.mainFormInvalid && this.advancedSearchForm){
            for(let ctrl in this.advancedSearchForm.controls){
                // this.advancedSearchForm.controls[ctrl].pristine = false;
                this.advancedSearchForm.controls[ctrl].markAsTouched();
            }
        }
        if(this.attrFormInvalid && this.attrForm){
            for(let ctrl in this.attrForm.controls){
                // this.advancedSearchForm.controls[ctrl].pristine = false;
                this.attrForm.controls[ctrl].markAsTouched();
            }
        }
       
    }

    public initializeForms() {
        if (this.uploadModel) {
            this.advancedSearchForm = this.createGroup();
            // console.log("======")
            // console.log(this.advancedSearchForm)
        }

    }


    // createGroup() {
    //     const group = this.fb.group({});
    //     this.uploadModel.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
    //     return group;
    // }

    // createControl(config) {
    //     const { isDisabled, validation, value } = config;
    //     return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    // }


    createGroup() {
        const group = this.fb.group({});
        this.uploadModel.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
        return group;
    }
    createControl(config) {
        if(config.attributeType == 'LISTBOX' 
        && this.searchMode == 'attributeOnly'
        && config.attributeName != 'busAreaCode'){
            config.value = config.attributeLookupValues[0].code
        }
        const { isDisabled, validation, value } = config;
        //  validation.push(customValidator('&', 'ampersandRequired',new ValidationContext(),new RuleConfigurator());
        let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
        let self = this;
        let attributeName=config.attributeName;
        control.valueChanges.subscribe(res =>{
            self.controlChanged(control,attributeName);
        })
        return control;
        
    }

    public controlChanged(ctrl, nameOfAttribute) {
        if(nameOfAttribute == 'DOCUMENT_CATEGORY'){
            for(let item in this.categoryTypeCombo){
                if(item == ctrl.value){
                    for(let prop of this.attrResponseObj){
                        if('DOCUMENT_TYPE' == prop.attribute.attributeName){
                            prop.attribute.attributeLookupValues =[];
                            for(let ele of this.categoryTypeCombo[item]){
                                let objt:any={
                                    attributeLookUpValue: ele
                                }
                                prop.attribute.attributeLookupValues.push(objt);
                            }
                            break;
                        }
                    }
                    break;
                }
            }
        }
        if (ctrl.parent == this.advancedSearchForm) {
            if ( (this.searchMode == 'attributeOnly') &&  this.advancedSearchForm.controls["busAreaCode"].value
                && this.advancedSearchForm.controls["sourceSystemCode"].value
                && this.advancedSearchForm.controls["regionCode"].value
                && this.advancedSearchForm.controls["functionCode"].value 
            ) {
                this.createNewForm();
                let objToBeSent:any={};
                for(let item in this.advancedSearchForm.controls){
                    objToBeSent[item] = this.advancedSearchForm.controls[item].value;
                }
                let docTypeUrl = environment.appURL+'document/getDocTypes/';
                this.clientService.setUrl(docTypeUrl,objToBeSent);
                this.clientService.getClientData().subscribe(res =>{
                    this.categoryTypeCombo = res.data;
                })
            }
            let dummy;
            dummy={
                advanceSearchForm:this.advancedSearchForm,
                attrForm:this.attrForm,
               basicSearchForm:this.basicSearchForm
            }
        }
        else {
            //attrResponseObj is the json response from service
            //nameOfAttribute is the form name of that field 
            if(this.attrResponseObj){
                for (let element of this.attrResponseObj) {
                    if (nameOfAttribute == element.attribute.attributeName) {
                        if(element.attribute.attributeType == 'DATEBOX'){
                            if(ctrl.value != this.convertedVal){
                                this.convertedVal = this.dateInServiceFormat(ctrl.value);
                                ctrl.setValue(this.convertedVal);
                            }
                            break;
                        }
                        this.sizeOfInput = element.attributeSize;
                        if (ctrl.value && this.sizeOfInput < ctrl.value.length) {
                            this.attrForm.controls[nameOfAttribute].setValue(ctrl.value.slice(0, this.sizeOfInput));
                            break;
                        }
                    }
                }
                let obj=[];
                obj.push(this.attrForm)
                obj.push(this.attrResponseObj);
            }
           
            // this.attrFormChangeEvent.emit(this.attrForm);
            
        }
        if(this.displayBasicForm){
            for (let ele of this.displayBasicForm){
                if(nameOfAttribute == ele.attributeName && ele.attributeType =='DATEBOX'){
                    
                    if(ctrl.value != this.convertedVal){
                        this.convertedVal = this.dateInServiceFormat(ctrl.value);
                        ctrl.setValue(this.convertedVal);
                    }
                    break;
                }
            }
        }
        
    }

    public openCard() {
        if (this.cardClose)
            this.cardClose = false;
        else
            this.cardClose = true;

    }
    public closeCardIcon() {
        this.cardClose = false;
    }
    public closeCard() {
        this.cardClose = false;
    }

    public clickCancel() {
        this.textValue = '';
    }

    public saveForm(textValue) {
        // this.openSaveIcon.push(textValue);
        this.saveSearchValue = [];
        this.storeCriteria = [];
        for (let ctrl in this.advancedSearchForm.controls) {
            let dummy = {
                name: ctrl,
                value: this.advancedSearchForm.controls[ctrl].value
            }
            this.saveSearchValue.push(dummy);
        }
        var dataList = { formName: this.formName, name: this.textValue, criteria: this.saveSearchValue }
        this.nameData.push(dataList);
        this.textValue = '';
        for (let i = 0; i < this.nameData.length; i++) {
            this.storeCriteria = this.nameData[i].criteria;
        }
    }

    public tempOpenIcon(item) {

        for (let ctrl in this.advancedSearchForm.controls) {
            for (let ele of item.criteria) {
                if (ctrl == ele.name) {
                    this.advancedSearchForm.controls[ctrl].setValue(ele.value);
                }
            }
        }

    }
    public onChange (listofval,event){
      
    }
    //hitting Transition Field Url in ngOnInit
    public getTransitionFieldUrl(){
        let self = this;
        let res= self.shareDataService.getUploadForm()
        if(res){
            self.mapLookup(res);
            self.spinnerFlagTransactional=false;
        }else{
        let docTypeUrl =this.transitionFieldUrl;
        this.clientService.setUrl(docTypeUrl);
        this.clientService.getClientData().subscribe(function (res) {
            self.spinnerFlagTransactional=false;
            self.mapLookup(res);
        });       
    
         }
    }
    // method to checkif value is already pushed to lookup
    public checkIfValExist(prop,dummyAttrVal){
        let uniqueVal = true;
        for(let item of prop.attributeLookupValues){
            if(item.value == dummyAttrVal.value){
                uniqueVal = false;
                break;
            }
        }
        return uniqueVal;
    }

    // to map the lookup or dropdown based on service response
    public mapLookup(res){
        for(let item of res){
            for(let prop of this.uploadModel){
                let dummyAttrVal={
                    value:'',
                    code:''
                }
                if(item.region[prop.attributeName]){
                    dummyAttrVal.value = item.region.regionName;
                    dummyAttrVal.code = item.region.regionCode
                    let uniqueVal = this.checkIfValExist(prop,dummyAttrVal)
                    if(uniqueVal){
                        prop.attributeLookupValues.push(dummyAttrVal)
                    }
                }
               else if(item.sourceSystem[prop.attributeName]){
                dummyAttrVal.value = item.sourceSystem.sourceSystemName;
                dummyAttrVal.code =item.sourceSystem.sourceSystemCode;
                let uniqueVal = this.checkIfValExist(prop,dummyAttrVal)
                if(uniqueVal){
                    prop.attributeLookupValues.push(dummyAttrVal)
                }
                }
                else if(item.function[prop.attributeName]){
                    dummyAttrVal.value = item.function.functionName;
                    dummyAttrVal.code = item.function.functionCode;
                    let uniqueVal = this.checkIfValExist(prop,dummyAttrVal)
                    if(uniqueVal){
                        prop.attributeLookupValues.push(dummyAttrVal)
                    }
                }
                else if(item.busArea[prop.attributeName]){
                    dummyAttrVal.value = item.busArea.busAreaName;
                    dummyAttrVal.code = item.busArea.busAreaCode;
                    let uniqueVal = this.checkIfValExist(prop,dummyAttrVal)
                    if(uniqueVal){
                        prop.attributeLookupValues.push(dummyAttrVal)
                    }
                }
            }
        }
      
    }
    // method to create new form based on the service response post Region , business area, 
    // function and source system selection
    public createNewForm(){
        let self =this
        let objToFetch={
            "busAreaCode": this.advancedSearchForm.controls['busAreaCode'].value,
            "sourceSystemCode": this.advancedSearchForm.controls['sourceSystemCode'].value,
            "regionCode": this.advancedSearchForm.controls['regionCode'].value,
            "functionCode": this.advancedSearchForm.controls['functionCode'].value,
            "actionType":"searchAttribute"
        }
        this.clientService.setUrl(self.appURL+'attributes/',objToFetch,);
        this.clientService.getClientData().subscribe(res => {
            self.attrResponseObj = res;

            //sorting the service response according to orderNo 
            self.attrResponseObj.sort(function(a, b) {
                return parseFloat(a.orderNo) - parseFloat(b.orderNo);
            });

            let copyOfRes = res.map(x => Object.assign({}, x))
            for(let item of res){
              if(item.attribute.attributeType == 'DATEBOX'){
                  let itemFrom= Object.assign({},item)
                  itemFrom.attribute = Object.assign({},item.attribute)
                  let itemTo =  Object.assign({},item)
                  itemTo.attribute = Object.assign({},item.attribute)
                  itemFrom.attribute.attributeName = itemFrom.attribute.attributeName + "_From"
                  itemFrom.attribute.displayName = itemFrom.attribute.displayName + " From";
                  itemTo.attribute.attributeName = itemTo.attribute.attributeName + "_To"
                  itemTo.attribute.displayName = itemTo.attribute.displayName + " To";
                  let indexOfItem:any;
                  for(let ele of copyOfRes){
                      if(ele.attribute.attributeName == item.attribute.attributeName){
                          indexOfItem = copyOfRes.indexOf(ele);
                          break;
                      }
                  }
                  copyOfRes.splice(indexOfItem,1,itemFrom,itemTo)
              }
            }
            self.attrResponseObj = copyOfRes;



            self.attrForm = self.createAttrForm();
            let obj=[];
            obj.push(self.attrForm)
            obj.push(self.attrResponseObj);
            self.showAttrForm = true;
            self.availSelectedConfig=true;
        })
    }

    // method to create attrForm
    public createAttrForm(){
        const group = this.fb.group({});
        this.attrResponseObj.forEach(control => {
            let attrName = control.attribute.attributeName;
            group.addControl(control.attribute.attributeName, this.createControlsForAttrForm(control))
            
            
        });
        return group;
    }

    // method to crerate controls for attrform
    public createControlsForAttrForm(config){
        const { isDisabled, value ,validation } = config;
        
       
        //  validation.push(customValidator('&', 'ampersandRequired',new ValidationContext(),new RuleConfigurator());
        let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
        let self = this;
        let attributeName=config.attribute.attributeName;
        control.valueChanges.subscribe(res =>{
            self.controlChanged(control,attributeName); 
        })
        return control;
    }
    // method triggered when the control of attrForm changes
    public attrfomrCtrlChanged(){
        this.attrFormChangeEvent.emit(this.attrForm);
    }
    //method for clearing entered Attribute list
    public clearAttDeatail(ctrl){
        this.attrForm.controls[ctrl].reset();
    }
    //setting Drop down values based on LEGAL_ENTITY_NAME_NA for LEGAL_ENTITY_ID_NA and COUNTRY_OF_LEGAL_ENTITY_NA'
    public setLegalEntity(ctrlName,valSelected){
        if(ctrlName == 'LEGAL_ENTITY_NAME_NA'){
            for(let ele of this.attrResponseObj){
                if(ele.attribute.attributeName == 'LEGAL_ENTITY_ID_NA' || ele.attribute.attributeName == 'COUNTRY_OF_LEGAL_ENTITY_NA' ){
                    let ctrlToSet = ele.attribute.attributeName;
                    for(let val of ele.attribute.attributeLookupValues){
                        if(valSelected.attributeLookupValueUid == val.attributeParentId){
                            this.attrForm.controls[ctrlToSet].setValue(val.attributeLookUpValue)
                        }
                    }
                }
            }
        }
    }
   
//    public checkIfOneOptionMnForm(ctrlName,options){
//     if(options.length == 1){
//         this.advancedSearchForm.controls[ctrlName].setValue(options.value)
//     }
//    }
//    public checkIfOneOptionAttrForm(ctrlName,options){
//     if(options.length == 1){
//         this.advancedSearchForm.controls[ctrlName].setValue(options.attributeLookUpValue)
//     }
//    }
public openFormDialog(){
    let self=this;
    let dialogRef = this.dialog.open(AvailableSelectionConfigComponent, {
        height: '420px',
        width: '500px',
        data: self.attrResponseObj
      });
  
      dialogRef.afterClosed().subscribe(result => {
        // let val = self.shareDataService.getAttrObj();
        // console.log(val);
      });
    }
    

      //hitting Basic Form Url in ngOnInit
      public getBasicFieldUrl(){
        this.basicFormUrl =  this.appURL+"attributes"; 
        this.clientService.setUrl(this.basicFormUrl);
        let self=this;
        self.clientService.getClientData().subscribe(function (res) {
         self.displayBasicForm = self.handleDateToCreateExtraCtrl(res);
            self.basicSearchForm=self.createBasicFormGroup();
        });
    }
    //Create Form for basic Form Field
    createBasicFormGroup() {
        const group = this.fb.group({});
        this.displayBasicForm.forEach(control => {
            group.addControl(control.attributeName, this.createControl(control))
        });
        return group;
    }
    createBasicFormControl(config) {
        const { isDisabled, validation, value } = config;
        //  validation.push(customValidator('&', 'ampersandRequired',new ValidationContext(),new RuleConfigurator());
        let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
        let self = this;
        let attributeName=config.attributeName;
        control.valueChanges.subscribe(res =>{
            self.controlChanged(control,attributeName);
        })
        return control;
        
    }
    public handleDateToCreateExtraCtrl(formList){
        let copyOfRes = formList.map(x => Object.assign({}, x))
        for(let item of formList){
          if(item.attributeType == 'DATEBOX'){
              let itemFrom= Object.assign({},item)
              let itemTo =  Object.assign({},item)
              itemFrom.attributeName = itemFrom.attributeName + "_From"
              itemFrom.displayName = itemFrom.displayName + " From";
              itemTo.attributeName = itemTo.attributeName + "_To"
              itemTo.displayName = itemTo.displayName + " To";
              let indexOfItem:any;
              for(let ele of copyOfRes){
                  if(ele.attributeName == item.attributeName){
                      indexOfItem = copyOfRes.indexOf(ele);
                      break;
                  }
              }
              copyOfRes.splice(indexOfItem,1,itemFrom,itemTo)
          }
        }
        return copyOfRes;
    }


    public dateInServiceFormat(dateToConvert){
        let monthList = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        let monthNUmbers = ["01","02","03","04","05","06","07","08","09","10","11","12"];
        
        let dateVal = String(dateToConvert);
        let formDate = dateVal.split(" ");
        let dateFormat= formDate[3] + "-" + (monthNUmbers[monthList.indexOf(formDate[1])] ) + "-" + formDate[2] ;
        return dateFormat;
    }

    public sendFormsToSearch(){
        let dummy;
        dummy={
            advanceSearchForm:this.advancedSearchForm,
            attrForm:this.attrForm,
           basicSearchForm:this.basicSearchForm
        }
        this.formValueChangeEvent.emit(dummy);
    }
}