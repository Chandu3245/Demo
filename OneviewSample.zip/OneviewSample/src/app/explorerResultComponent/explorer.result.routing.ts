import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ExplorerResultComponent } from '../explorerResultComponent';

const routes: Routes = [
  { path: '', component: ExplorerResultComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);