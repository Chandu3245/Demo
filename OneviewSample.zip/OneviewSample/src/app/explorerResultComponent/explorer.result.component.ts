import { ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { Component, OnDestroy, OnInit, DoCheck, EventEmitter, ChangeDetectorRef, Inject, Input, Output, OnChanges, ViewChild } from '@angular/core';
import { MatSnackBar,MatTabChangeEvent,MatDialog } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';

import { CustomizeFolderComponent } from './../customizeFolderComponent/customizeFolder.component';
// import {DashboardComponent } from '../DashboardComponent/dashboard.component'
import{ environment } from './../../environments/environment';
// import {ExplorerComponent } from '../explorerComponent/explorer.component'
import { DataService } from './../../lib/modules/mdt-table/services/DataService';
import { ClientDataService, ShareDataService } from '../services';
//import { ShareDataService } from '../services/share.data.service';


@Component({
    selector: 'explorer-result',
    templateUrl: './explorer.result.component.html',
    styleUrls: ['./explorer.result.component.scss'],
    animations: [
        trigger(
            'enterAnimation', [
                transition(':enter', [
                    style({ transform: ' translate3d(-100%, 0, 0)', opacity: 0 }),
                    animate('300ms ease-in-out', style({ transform: 'translateX(0)', opacity: 1 }))
                ]),
                transition(':leave', [
                    style({ transform: 'translateX(0)', opacity: 1 }),
                    animate('200ms ease-in-out', style({ transform: ' translate3d(-100%, 0, 0)', opacity: 0 }))
                ])
            ]
        ),
        trigger(
            'leaveAnimation', [
                transition(':enter', [
                    style({ transform: ' translate3d(100%, 0, 0)', opacity: 0 }),
                    animate('400ms ease-in-out', style({ transform: 'translateX(0)', opacity: 1 }))
                ]),
                transition(':leave', [
                    style({ transform: 'translateX(0)', opacity: 1 }),
                    animate('1000ms ease-in-out', style({ transform: ' translate3d(100%, 0, 0)', opacity: 0 }))
                ])
            ]
        )


    ],


})


export class ExplorerResultComponent implements OnInit, DoCheck {
    @ViewChild('treeRoot') private elementRef: ElementRef;
    private dummydata: any = [];
    private folderName: any;
    private ListOfFldrToDisp: any = [];
    private nameSearched: any;
    private listOfCheckedStateOfFolders: any = [];
    private enableAdd: boolean = false;
    private allFoldersChecked: boolean = false;
    private listOfFoldersToBeAddedToExplorer: any = [];
    private gridToBeShown: any = 'docGrid'
    private compName = 'Explorer Result';
    private listOfActionMenu = ["Share", "Download", "Delete", "Attach"];
    private breadCrumbList: any = [];
    private date1: any;
    private date2: any;
    private appURL:string;
    private sourceSystem = 'CORFLOW'
    private totalTime: any;
    private showServiceLapDetails: boolean = false;
    public trans1: any = 'Business Documents Transactional';
    public trans2: any = 'Business Documents non-Transactional';
    private rootFilteredVal:any;
    
    
    
    
    
    
    
    
    private inductionName:any="Swisscom AG"
    private rootFilOptions:any=["Trafford Park Insurance Limited",
    "Swisscom AG",
    "Swiss Re America Holding Corporation",
    "Lazard Brothers Asset Management Ltd",
    "Fiat Group North America",
    "Anglo Platinum Limited",
    "Allianz Colombia-BOGOTA , Colombia",
    "ACS Accountancy Services Ltd",
    "AA & Co. Solicitors",
    "A. Duie Pyle Companies",
    "A I Sampson & Co"
    ]
    private rootEditMode:boolean = false;
    private treeRootControl:FormControl = new FormControl();
    //below are variables related to the functionailty copied from searchComponent
    private explorerAddIcon: any;
    private fileName: any = 'a';
    private sharePointSearchURL: string;
    private foldersList: any = [];
    private foldersList1: any = [];
    private cardopened: boolean;
    private toggleSideExplorer: boolean = false;
    private currentHeader = " ";
    private rowsForTable: any = [];
    private columnsForTable = [];
    private listOfActionItem = ["Edit","View", "Share", "Download", "Delete", "Additional Info", "Attach"];
    private collapseFavorite: boolean = false;
    private collapseClaims: boolean = false;
    private collapseUw: boolean = false;
    private collapseCorDocs: boolean = false;
    private activeExplorerHeading: any = -1;
    private additionalInfoCard: boolean = false;
    private additionalInfoData: any;
    private widthtobeset: string;
    private tableMarginLeft: string;
    private listOfSelectedRows:any=[];		
    private mostRecentData: any // to store most recent selection in mdt-table
    private toolTipPositionRight = 'right';
    private explorerTableSmoothScrolling: boolean = true;
    private clearFieldValue: any = "";
    private rowData: any = [];
    private columnDefs: any = [];
    private getData: any = [];
    private showId: boolean = false;
    private showPostFilter: boolean = false;
    private showFilteredTable: any = [];
    private userValue:any=[];
    private clientValue:any=[];
    private attrList:any=[];
    private treenodes:any;
    private treeData:any;
    private enableCheckBox:boolean;
    private favouriteKeys:any=[];

    private treeFavKeyList:any;
    private treeFavValList:any;
    private favBreadCrumb:any;
   // private toggleSideExplorerButton:any=0

    // private foldersList = [
    //     {
    //         name:'CorDocs',
    //         fldrUrl: 'https://shp.swissre.com/sites/csinfdocs/InformationIntegration Document Repository/CorDocs'
    //     },
    //     {
    //         name:'CorDocs1',
    //         fldrUrl: ''
    //     },
    //     {
    //         name:'CorDocs-all',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs gen2',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs GWT',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs gen1',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs gw',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs aa',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs docu',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs 111',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs bsf',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs as',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs sds',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs ww',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs gsd',
    //         fldrUrl: 'http://akdal'
    //     },
    //     {
    //         name:'CorDocs 22',
    //         fldrUrl: 'http://akdal'
    //     }
    //     ]


    private claimsFldr = [
        {
            '642536': {
                '105408': [
                    {
                        'TEST TAG': [{
                            'Discover': [{ 'Court Documents': [''] }]
                        }]
                    },
                ]
            }
        },
        // {
        //     'Doument Category':{
        //         'Activity Id':[
        //             {
        //                 'NA':[{
        //                     'UW':[{'Aviation':['']}]
        //                 }]
        //             },
        //             {
        //                 'LATAM':[{
        //                     'Claims':[{'Marine':['']}]
        //                 }]
        //             }
        //         ]
        //     }
        // },
        // {
        //     'Claim Number':
        //     {
        //         'Policy Number':[
        //             {
        //                 'NA':[{
        //                     'UW':[{'Aviation':['']}]
        //                 }]
        //             },
        //             {
        //                 'LATAM':[{
        //                     'Claims':[{'Marine':['']}]
        //                 }]
        //             }
        //         ]
        //     }  
        // }

    ]

    private UwFldr =
    [
        {
            'govt of the Kingdom of Saudi Arabia': {
                'CFDL20044': [
                    {
                        '98948.3.01122016': [{
                            '112 FIRE LOP': [{ '2016-12-01': [''] }]
                        }]
                    },
                ]
            }
        },

    ]

    private corDocsFldr = [
        {
            'Avation': {
                'Document Type': [
                    {
                        'NA': [{
                            'UW': [{ 'Aviation': [''] }]
                        }]
                    },
                    {
                        'LATAM': [{
                            'Claims': [{ 'Marine': [''] }]
                        }]
                    }
                ]
            }
        },


    ]

    private listOfFoldersShown: any = [];
    private getActiveFolderTree: any;
    private listOfFavorite: any = [];
    private displayFavoriteList = [];
    private recordCount: any;
    private drillDownAttr: any = [];
    private selectedFilterApply:any=[];
    private rowDataBack:any=[];
    private displayAttrList:any=[];
    private rootName:any;
    private openRootItem:boolean;
    public subscriber: any = {};
    private menuTriggerIndex:any;
    @Input() nodes;
    @Input() typeofIcontoOpen;
    @Input() typeofIcontoClose;

    constructor( @Inject(ActivatedRoute) private route: ActivatedRoute,
        @Inject(ClientDataService) private clientDataService: ClientDataService,
        @Inject(ShareDataService) private shareDataService: ShareDataService,
        @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef,
        @Inject(DataService) private dataservice: DataService,
        @Inject(MatDialog) public dialog: MatDialog,
        @Inject(MatSnackBar) public snackBar: MatSnackBar) {
        this.calljson();
        this.appURL = environment.appURL;
        this.createTree();  
    this.shareDataService.setFavourities([]);
    this.shareDataService.setTreeByObserver([]);
       
    }
      //method to get the table data from service
    private calljson() {
        // this.columnsForTable =   Cols.tableHeader;
        // this.rowsForTable = rows.data;
        let self = this;
        let colDataUrl = './assets/tableCols.json';
        this.clientDataService.setUrl(colDataUrl)
        this.clientDataService.getClientData().subscribe(res => {
            self.columnsForTable = res.tableHeader;
        });
        let rowDataUrl = './assets/tableRow.json';
        this.clientDataService.setUrl(rowDataUrl)
        this.clientDataService.getClientData().subscribe(res => {
            self.rowsForTable = res.data;
            self.rowData = self.rowsForTable;
            self.rowDataBack=self.rowData;
            self.recordCount = self.rowData.length;
        });

    }

    

    public filterResult(val, options) {
        return val ? options.filter(s => s.toLowerCase().indexOf(val.toLowerCase()) === 0) : options
    }

    ngOnInit() {
        this.getFavList();
        this.folderName = this.clientDataService.getSharePointName();
        this.gridToBeShown = this.shareDataService.getGridToBeShown();
       this.addToFavourities();
       this.rootFilteredVal = this.treeRootControl.valueChanges.startWith(null)
       .map(val => this.filterResult(val,this.rootFilOptions))
       let self = this;
       this.shareDataService.getFavList().subscribe(res =>{
        self.createTreeFavList(res)
          
       });
       
    }
    ngOnChanges(){

       
    }
    ngDoCheck() {
        this.folderName = this.clientDataService.getSharePointName();
        this.gridToBeShown = this.shareDataService.getGridToBeShown();
        this.breadCrumbList = this.shareDataService.getBreadCrumbsArr();

        // alert(this.foldersList1.length);
        //  alert(this.foldersList1.length);
        // for(let i =0;i<this.foldersList.length;i++){
        //  }
        //  alert(this.folderName +'cc  '+ this.nameSearched);
        if (this.folderName != this.nameSearched) {
            this.date1 = new Date();
            this.getSharePointDocuments(this.folderName);
            this.findFldrsToDisp();
        }

    }
//method to form favourites based on response
    public createTreeFavList(res){
        let self = this;
        self.treeFavKeyList = [];;
        self.treeFavValList = [];
        self.favBreadCrumb = res;
        for(let fav of res){
            let breadCrumb = JSON.parse(fav.filterData)
            let crumbs =Object.keys(breadCrumb).map(key => breadCrumb[key]) // Object.values(breadCrumb);
            let crumbVals:any =[];
            let crumbKeys:any =[];
            for(let item of breadCrumb){
             for(let ele in item){
                 crumbVals.push(item[ele]);
                 crumbKeys.push(ele)
             }
            }
            self.treeFavKeyList.push(crumbKeys);
            self.treeFavValList.push(crumbVals);
        //  self.treeFavList.push(crumbVals);
        }
    }
    public getFavList(){
        let self = this;
        let favUrl = this.appURL + 'userPreference/' + this.sourceSystem;
        this.clientDataService.setUrl(favUrl);
        this.clientDataService.getClientData().subscribe(res => {
            self.createTreeFavList(res)
        })
    }
    // ngAfterViewChecked() {
    //     this.scrollbarService.initScrollbar('#customScroll', {  axis:  'y', theme:  'minimal-dark', });
    //     this.scrollbarService.initScrollbar('#customscrolldiv', {  axis:  'y', theme:  'minimal-dark', });
    // }
    //method to call tree structure
    private createTree(objToPost?){
        
        this.enableCheckBox =true;
        let obj = {
            "SOURCE_SYSTEM":"CORFLOW",
            "ADD_SRC_SYS":"DGF,MAN,MANHATTAN,IPA,RES",
            "FUNCTION":"UW",
            "INSURED_NAME":this.inductionName
        }
        if(objToPost){
            obj  = objToPost;
        }
        let url = this.appURL +"loadTreeDocuments/";
        this.clientDataService.setUrl(url,obj);

        // let decodeUrl= url;
        // let docName = decodeURIComponent(decodeUrl);
        // let lastIndex = docName.lastIndexOf('/');
        // let docExtn = docName.substring((lastIndex + 1), docName.length);
        // let data = JSON.parse(docExtn);
         this.rootName= obj.INSURED_NAME;

        this.clientDataService.getClientData().subscribe(res => {
   	    let treeChildNodes;
            this.treenodes = res;
            for(let items of this.treenodes)
            { 
            items.isOpen=false;
            items.isCheck = false;
            items.isFavourite =false;
            }
            this.treenodes = res[0].children;
            if(this.treenodes && this.treenodes.length>0){
            for(let items of this.treenodes)
            { 
            items.isOpen=false;
            items.isCheck = false;
            items.isFavourite =false;
            if(items.key =="INSURED_NAME"){
                this.treenodes = this.treenodes[0].children;
                } 
            treeChildNodes = items.children;
            while(treeChildNodes && treeChildNodes.length>0){
                for(let items of  treeChildNodes){
                    items.isOpen=false;
                    items.isCheck = false;
                    items.isFavourite =false;
                    treeChildNodes =  items.children ;
                }

            }
            }
          
            
            this.treeData= res;
            this.treenodes[0].isOpen=false;
            this.treenodes[0].isCheck = false;
            this.treenodes[0].isFavourite =false; 
            this.shareDataService.setFavourities([]);
            this.shareDataService.setTreeByObserver([]);
        }
        });
       
    }
    private findFldrsToDisp() {

        this.ListOfFldrToDisp = [];
        this.ref.detectChanges();
        this.listOfCheckedStateOfFolders = [];
        this.allFoldersChecked = false;
        this.enableAdd = false;
        for (let i = 0; i < this.foldersList.length; i++) {
            if (this.foldersList[i].name.indexOf(this.folderName) >= 0) {
                this.ListOfFldrToDisp.push(this.foldersList[i]);
                this.listOfCheckedStateOfFolders.push(false);
            }
        }
        this.nameSearched = this.folderName;
        this.ref.detectChanges();

    }
    getFolderTreeOutput(event) {
        this.getActiveFolderTree = event;
    }
    private folderBackground(event) {
        this.currentHeader = event;
    }
    
    private checkAllFolders() {
        let checkAll = true;
        for (let i = 0; i < this.listOfCheckedStateOfFolders.length; i++) {
            this.folderChecked(i, checkAll);
        }
        this.allFoldersChecked = !this.allFoldersChecked;
    }

    private folderChecked(index, checkAll?) {
        if (checkAll) {
            this.listOfCheckedStateOfFolders[index] = !this.allFoldersChecked;
        } else {
            this.listOfCheckedStateOfFolders[index] = !this.listOfCheckedStateOfFolders[index];
        }
        for (let i = 0; i < this.listOfCheckedStateOfFolders.length; i++) {
            if (this.listOfCheckedStateOfFolders[i]) {
                this.enableAdd = true;
                break;
            } else {
                this.enableAdd = false;
            }
        }
    }

    private addFoldersToExplorer() {
        this.listOfFoldersToBeAddedToExplorer = [];
        for (let i = 0; i < this.listOfCheckedStateOfFolders.length; i++) {
            if (this.listOfCheckedStateOfFolders[i]) {
                this.listOfFoldersToBeAddedToExplorer.push(this.foldersList[i].attributes.name);
            }
        }
        this.shareDataService.setFoldersToBeAdded(this.listOfFoldersToBeAddedToExplorer);
    }

    private getSharePointDocuments(folderName) {
        this.foldersList = [];
        this.foldersList1 = [];
        this.ref.detectChanges();
        this.sharePointSearchURL = 'http://localhost:9080/webapp/jee6/rest/ebasService/docSearch/' + folderName;
        this.clientDataService.setUrl(this.sharePointSearchURL);
        let self = this;
        this.clientDataService.getClientData().subscribe(function (result) {
            for (let i = 0; i < result.length; i++) {
                self.foldersList1.push(result[i].documents);
            }
            self.foldersList = self.foldersList1[0];

        });
        //this.totalLapseTime = this.totalLapseTime/this.listOfAvailableSoruces.length;
        self.date2 = new Date();
        this.totalTime = (self.date2 - self.date1) / 1000;
        self.ref.detectChanges();

        this.showServiceLapDetails = true;
    }
    private iscardopened() {
        if (this.cardopened) {
            this.cardopened = false;
        }
        else {
            this.cardopened = true;
        }
    }

    private hideExplorer() {
        this.toggleSideExplorer = !this.toggleSideExplorer;
        this.explorerAddIcon = "-13px";
        //to toggle additonal info card
        if (!this.toggleSideExplorer) {
            this.additionalInfoCard = false;
            this.widthtobeset = "100%"
            this.tableMarginLeft = "15px";
        }
        else {
            this.tableMarginLeft = "0px";
        }
    }
    public getListOfFavoriteOutput(event) {
        // if (event.length > 10) {
        //     this.snackBar.open("To add more favorite, remove some favorite from list", 'Close', {
        //         duration: 5000,
        //     });
        // }else{
            this.displayFavoriteList = event;
        // }
    }
    // public spliceFavoriteList(listIndex){
    // }

    // onLinkClick(event: MatTabChangeEvent) {
    //     this.scrollbarService.initScrollbar('#customscrolldiv', {  axis:  'yx', theme:  'minimal-dark', });
    //     this.scrollbarService.initScrollbar('#customScroll', {  axis:  'yx', theme:  'minimal-dark', });
    // }

    // private scrollbarevent(index) {
    //     if (index == "0") {
    //         this.scrollbarService.initScrollbar('#customScroll', {  axis:  'yx', theme:  'minimal-dark', });

    //     }
    //     else {
    //         this.scrollbarService.initScrollbar('#customscrolldiv', {  axis:  'yx', theme:  'minimal-dark', });

    //     }
    // }
    public actionTriggered(event) {
        if (event.actionItem == "Additional Info") {
            if (this.additionalInfoCard = true)
                this.showPostFilter = false;
            this.toggleSideExplorer = true;
            this.tableMarginLeft = "0px";
            this.explorerAddIcon = "-13px";
            {
                this.widthtobeset = "75%"
                this.additionalInfoData = event;
            }
        }
    }
    private closeSummaryCard(event) {
        this.additionalInfoCard = !this.additionalInfoCard;
        if (this.additionalInfoCard) {
            this.showPostFilter = false;
        }
        this.widthtobeset = "100%";


    }
    public rowSelectedEvent(event) {
        this.listOfSelectedRows = event;
    }
    //method to capture most recent row selection in mdt-TableElement
    //also handles assigning data to additional info if open
    public mostRecentRowSelection(event) {
        this.mostRecentData = event;
        if (this.additionalInfoCard) {
            this.showPostFilter = false;
            let cardData = {
                actionItem: "Additional Info",
                row: event
            }
            this.actionTriggered(cardData);
        }
    }

    public openCustomizeDailog() {
        let self = this;
        self.attrList=[];
        self.displayAttrList=[];
        let dialogRef = this.dialog.open(CustomizeFolderComponent, {
            height: '370px',
            width: '310px',
            data: self.attrList,
        });
      this.subscriber=  self.shareDataService.getsuccess().subscribe(res=>{
         if(res){
             self.createTree();
             }
        dialogRef.afterClosed().subscribe(result  =>  {
            })
         this.subscriber.unsubscribe();
        });
        dialogRef.backdropClick().subscribe(result  =>  {
            this.shareDataService.clearSuccess();
        })
        this.getCustomizationFieldUrl();
       
    }
    public toggleId() {
        this.showId = !this.showId;
    }
    public getVerticalSearchFilter(e: any) {
    }
    public displayOnLookUp(form) {
        // this.verticalCardHeight ="550px";
        // this.verticalCardHeight ="250px";
        this.showFilteredTable = [];
        let formChanged: boolean = false;

        let dummy = []
        for (let item in form.controls) {
            if (form.controls[item].value && form.controls[item].value.length != 0 && form.controls[item].value != ' ' && form.controls[item].value != null) {
                formChanged = true;
                if (this.showFilteredTable.length <= 0) {
                    for (let i = 0; i < this.rowsForTable.length; i++) {
                        for (let j = 0; j < this.rowsForTable[i].length; j++) {
                            if (this.rowsForTable[i][j].value == form.controls[item].value) {
                                this.showFilteredTable.push(this.rowsForTable[i]);

                            }
                        }
                    }
                    this.rowData = this.showFilteredTable;
                }
                else {
                    let dummy = [];
                    for (let i = 0; i < this.showFilteredTable.length; i++) {
                        for (let j = 0; j < this.showFilteredTable[i].length; j++) {
                            if (this.showFilteredTable[i][j].value == form.controls[item].value) {
                                dummy.push(this.showFilteredTable[i]);

                            }
                        }
                    }

                    this.rowData = dummy;
                }
            }
            else {
                if (!formChanged) {
                    this.rowData = this.rowsForTable;
                }
            }
        }
    }
    //   method to close additional info card on post filter toggle
    public postFilterToggled() {
        this.showPostFilter = true;
        this.additionalInfoCard = false;
        this.widthtobeset = "98.5%";
        // this.verticalCardHeight ="550px";
    }
    public setWidthEvent() {
        // this.verticalCardHeight ="290px";
    }
     //hitting customization folder Url in ngOnInit
     public getCustomizationFieldUrl(){
       let self = this;
        let userUrl = self.appURL + "treeAttributes/CORFLOW";
        this.clientDataService.setUrl(userUrl);
        this.clientDataService.getClientData().subscribe(function (res) {
           
          self.userValue=res;
          for (let item of self.userValue) {
              self.drillDownAttr=item.attributeName;
                  let attrObj = {
                      attrName: '',
                      displayName:'',
                      checked: true,
                  }
                 
                  attrObj.attrName =  self.drillDownAttr;
                  attrObj.displayName =  item.displayName;
                  attrObj.checked = true;
                  self.displayAttrList.push(attrObj);
          }
            let clientUrl = self.appURL + "attributes/%7B%22busAreaCode%22:%22PROP%22,%22sourceSystemCode%22:%22CORFLOW%22,%22regionCode%22:%22NA%22,%22functionCode%22:%22UW%22,%22actionType%22:%22drillDownAttributes%22%7D";
            self.clientDataService.setUrl(clientUrl);
            self.clientDataService.getClientData().subscribe(function (res) {
                self.clientValue=res;

                for(let fldr of self.displayAttrList){
                    for(let folder of self.clientValue){
                        if(fldr.attrName == folder.attribute.attributeName){
                            let attrObj = {
                                attrName: folder.attribute.attributeName,
                                displayName: folder.attribute.displayName,
                                checked:true,
                                busAttributeUid:folder.busAttributeUid,
                                sourceSystemCode:folder.sourceSystemVO.sourceSystemCode,
                                }
                                let folderPushed = false;
                                for(let item of self.attrList){
                                    if(item.attrName == attrObj.attrName){
                                        folderPushed = true;
                                    }
                                }
                                if(!folderPushed){
                                    self.attrList.push(attrObj);
                                }
                        }
                    }
                }

                for(let folder of self.clientValue){
                    let folderPushed:boolean = false;
                    for(let fldr of self.displayAttrList){
                        if(fldr.attrName == folder.attribute.attributeName){
                            folderPushed = true;
                            break
                        }
                    }
                    if(!folderPushed){
                        let attrObj = {
                            attrName: folder.attribute.attributeName,
                            displayName: folder.attribute.displayName,
                            checked:false,
                            busAttributeUid:folder.busAttributeUid,
                            sourceSystemCode:folder.sourceSystemVO.sourceSystemCode,
                            }
                            self.attrList.push(attrObj)
                    }
                }
                // for (let item of self.clientValue) {
                //     // self2.drillDownAttr=item.attribute.displayName;s
                //     let attrObj = {
                //     attrName: '',
                //     displayName: '',
                //     checked: false,
                //     busAttributeUid:'',
                //     sourceSystemCode:'',
                //     }
                //     attrObj.attrName = item.attribute.attributeName;
                //     attrObj.displayName = item.attribute.displayName;
                //     attrObj.checked = false;
                //     attrObj.busAttributeUid=item.busAttributeUid;
                //     attrObj.sourceSystemCode=item.sourceSystemVO.sourceSystemCode;
                //     self.clientlist.push(attrObj);
                //     // let checkAvailable=false;
                //     for (let data of self.displayAttrList) {
                //     if (data.attrName==attrObj.attrName) {
                //         attrObj.checked=true;
                //         self.attrList.push(attrObj);
                   
                //     }else{
                //         attrObj.checked=false;
                //         self.attrList.push(attrObj)
                //     }
                //     }
                //     // for (let data of self.clientlist) {
                //     //     for (let item of self.attrList) {
                //     //         if (data.attrName!=item.attrName) {
                //     //             self.attrList.push(attrObj);
                //     //          console.log(self.attrList);
                //     //         break;
                //     //         } 
                //     //     }                       
                //     //  }
                //     } 
            });
        });
    }
    //pushing attributes list
     public mapLookup(res) {
       
        }
          // column level filter On Remove button  for table 
          public applyColFilterWithOutServer(event){
            if(event.length>0){
                this.rowData=this.rowDataBack;
                this.applyColFilter(event)
            }
           else{
            this.rowData=this.rowDataBack;
           }
        }
        // column level filter apply for table 
        public applyColFilter(event) {
            this.selectedFilterApply = [];
            let colSelectedValue = event[event.length-1];
            // for(let colSelectedValue of event){
            for(let entireRow of this.rowData){
                for(let entireRowDb of entireRow){
                    if(colSelectedValue.colObj.dbColumnName==entireRowDb.dbColumnName
                    && colSelectedValue.filterValData.indexOf(entireRowDb.value)>=0
                    ){
                        this.selectedFilterApply.push(entireRow);
                        break;
                }
                }
            }
           
        // }
       this.rowData=this.selectedFilterApply
        }

        public addToFavourities()
        {
            let self=this;
            self.shareDataService.gettreeByObserver().subscribe(res=>{
                if(res && res.length<=0)
                {
                    this.displayFavoriteList=[];
                }
                else{
                    self.displayFavoriteList=[];
                    for(let item of res){    
                        let temp1 ;
                         temp1=   Object.keys(item);
                           // if(self.displayFavoriteList.indexOf(temp1)<0) 
                           //if(self.displayFavoriteList.indexOf(temp1)<0 && self.displayFavoriteList.indexOf(item[temp1])<0)
                            // {
                                self.displayFavoriteList.push(item[temp1[0]]);
                            // }
                    } 
                }
        });  
        console.log(this.displayFavoriteList)
        }
        

        public spliceFavoriteList(listIndex){
            this.displayFavoriteList.splice((listIndex),1);
        }
        public editTreeRoot(){
            this.rootEditMode = true;
            
            this.treeRootControl.setValue("");
            this.treeRootControl.markAsDirty()
            // let ipt = document.getElementById('treeRootIpt');
            // ipt.focus();
            // this.elementRef.nativeElement.focus();
            // this.treeRootControl.focus()
        }

        public setTreeRoot(event){
            // 
            // this.treeRootControl.markAsPristine();
            this.inductionName = event.option.value;
         
            this.createTree()
            this.rootEditMode = false;
        }
        public hideRootControl(){
            this.rootEditMode = false;
        }
        public closeRootCtrl(){
            let ele = document.getElementById('treeRootId');
            ele.blur();
            this.rootEditMode = false;
        }

        public markAsUnFav(favInd){
            let self = this;
            let urlToUnFav = this.appURL + 'userPreference/deleteUserFilters'
            let objToPost={
                userfilterPrefenencesUid: this.favBreadCrumb[favInd].userfilterPrefenencesUid
            }
            this.clientDataService.setUrl(urlToUnFav);
            this.clientDataService.PostClientData(objToPost).subscribe(res =>{
               if(res.STATUS == 'SUCCESS'){
                self.getFavList()
               }
            });
        }
}