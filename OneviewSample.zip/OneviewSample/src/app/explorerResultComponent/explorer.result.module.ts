import { CommonModule } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';

import {routing} from './explorer.result.routing';
import {ExplorerResultComponent} from '../explorerResultComponent';
import { MdtTableModule } from './../../lib/modules/mdt-table/mdt-table.module';
import { TreeComponent } from '../treeComponent/tree.component';
import { TreeStructuteModule } from './../treeStructureComponent/treeStructure.module';

import { MyMaterialModule } from '../material.module';

@NgModule({
  declarations: [
    ExplorerResultComponent,
    TreeComponent
    

  ],
  imports: [routing,CommonModule,FormsModule,MyMaterialModule,MdtTableModule,TreeStructuteModule],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
  
})



export class ExplorerResultModule { }
