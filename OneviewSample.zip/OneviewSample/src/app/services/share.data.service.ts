import { Injectable, Inject } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class ShareDataService{
    
    private fldrsToBeAdded:any=[];
    private docTransType:any;
    private fldrsAndTransType:any;
    private gridToBeShown:any='';
    private sideNavOpen:boolean;
    private breadCrumbsArr:any =[];
    private globalSearchList:any =[];
    private columnDefs:any=[];
    private device:string;
    private orientation:string;
    private selectedRowDetails:any=[];
    private slideToggle:boolean;
    private resentSelectedDoc:any;
    private totalSetOfRecords:any =[];
    private listOfFoldersOpened:any=[];
    private selAttrListCustomizeFldr:any=[];
    private treeDataUrl:any;
    private urlForForm: Subject<any> = new Subject();
    private dataUrl :any;
    private treeFavorities: Subject<any> = new Subject();
    private favlist:any;
    private formObj:any;
    private loadingTree:Subject<any> = new Subject();
    private favListObservable:Subject<any> = new Subject();
    private attrObjAvailable:any;

    constructor(@Inject(Http) private http:Http){
        
    }
    public setTotRecords(data){
        this.totalSetOfRecords = data;
    }
    public getTotRecords(){
        return this.totalSetOfRecords;
    }
    
    public setFoldersToBeAdded(listOfFldrs){
        this.fldrsToBeAdded = listOfFldrs;
    }
    public getFoldersToBeAdded(){
        this.fldrsAndTransType = {
            fldrList:this.fldrsToBeAdded,
            docTransType:this.docTransType
        }
        return this.fldrsAndTransType;
    }
    
    public setDocTransType(transtype){
        this.docTransType = transtype;
    }
    public getDocTransType(){
        return this.docTransType;
    }
    
    public setGridToBeShown(gridName){
        this.gridToBeShown = gridName;
    }
    public getGridToBeShown(){
        return this.gridToBeShown;
    }
    
    public setSideNavStatus(sideNavOpen){
        this.sideNavOpen = sideNavOpen;
    }
    public getSideNaveStatus(){
        return this.sideNavOpen;
    }
    
    public setBreadCrumbsArr(listofFldrsAccessed){
        this.breadCrumbsArr = listofFldrsAccessed;
    }
    public getBreadCrumbsArr(){
        return this.breadCrumbsArr;
    }
    
    public setGlobalSearchList(globalSearchList){
        this.globalSearchList = globalSearchList;
    }
    public getGlobalSearchList(){
        return this.globalSearchList;
    }
    
    public setColumnDefs(columnDefs){
        this.columnDefs = this.columnDefs;
    }
    
    public getColumnDefs(){
        return this.columnDefs;
    }
    
    public setDevice(device){
        this.device = device;
    }
    
    public getDevice(){
        return this.device;
    }
    
    public setOrientation(orientation){
        this.orientation = orientation;
    }
    
    public getOrientation(){
        return this.orientation;
    }
    
    public setSelectedRowDetails (rowDetails){
        this.selectedRowDetails = rowDetails;
    }
    public getSelectedRowDetails(){
        return this.selectedRowDetails;
    }
    
    public setSlideToggle(slideToggle){
        this.slideToggle = slideToggle;
    }
    
    public getSlideToggle(){
        return this.slideToggle;
    }
    
    public setResentSelectedDoc(resentSelectedDoc){
        this.resentSelectedDoc = resentSelectedDoc;
    }
    
    public getResentSelectedDoc(){
        return this.resentSelectedDoc;
    }

    public setListOfFoldersOpened(list){
        this.listOfFoldersOpened = list;
    }
    public getListOfFoldersOpened(){
        return this.listOfFoldersOpened;
    }

    //getter setter for attrList in customizefolder
    public setAttrLsit(list){
        this.selAttrListCustomizeFldr = list;
    }
    public getAttrList(){
        return this.selAttrListCustomizeFldr;
    }
    //getter setter for re loading tree 
    public setsuccess(loadTree){
        this.loadingTree.next(loadTree);
    }
    public getsuccess(){
        return this.loadingTree.asObservable();
    }
    clearSuccess() {
        this.loadingTree.next(false);
    }

    //method to set url for table data
    public setUrl(url,attr?)
    {
        this.dataUrl = url;
    }
    //method to get column data for table  using http call
    public getColumnData() {
        let configUrl =  './assets/tableCols.json';
        // return this.http.get(configUrl);
        return this.http.get(this.dataUrl).map(res => res.json());
    }

    //method to get row data for table  using http call
    public getRowData() {
        let rowDataUrl =  './assets/tableRow.json';
        // return this.http.get(configUrl);
        return this.http.get(this.dataUrl).map(res => res.json());
    }

    //getter setter for tree structure in explorer
    public setTreeDataList(list){
        this.treeDataUrl = list;
    }
    public getTreeDataList() {
        return this.http.get(this.treeDataUrl).map(res => res.json());
    }

    //method to set and get the tree data using observable
    setTreeByObserver(grpObj) {
        this.treeFavorities.next(grpObj);
    }
    gettreeByObserver(): Observable<any> {
        return this.treeFavorities.asObservable();
    }
     //setter and getter for getting tree data favourities
    public setFavourities(list)
    {
    this.favlist = list;
    }
  public getFavourities()
  {
      return this.favlist;
  }
  //setter and getter for upload form data
  setUploadForm(url) {
    this.urlForForm.next(url);
}
getUploadForm(): Observable<any> {
    return this.urlForForm.asObservable();
}
public SetMainFormObj(obj){
    this.formObj=obj
}
public getMainObj(){
    return this.formObj;
}
public setAttrObj(attrObjAvailable){
this.attrObjAvailable=attrObjAvailable;
}
public getAttrObj(){
   return this.attrObjAvailable;
    }

    // observable for Favorite
    public setFavList(favList){
        this.favListObservable.next(favList);
    }
    public getFavList(){
        return this.favListObservable.asObservable();
    }
}