import { HttpClientModule } from '@angular/common/http'; 
import { Injectable, Inject } from '@angular/core';
import {Http,Headers,RequestOptions,HttpModule} from '@angular/http';

import "rxjs/add/operator/map";

@Injectable()
export class ClientDataService{
    private url:any;
    private sharePointsearchFldrName:any;
    private attributesToGetData:any;
    private urlToXml:any;
    private headers:any;
    private options:any;
    constructor(@Inject(Http) private _http: Http){
        
    }
    
    public setUrl(url,attr?){
        if(attr){
            if(typeof(attr) !='string'){
                this.attributesToGetData = JSON.stringify(attr);    
            }else{
                this.attributesToGetData = attr;
            } 
            this.url = url+this.attributesToGetData;
        }else{
            this.url = url
        }
        
    }
    
    public PostClientData(attr?){
        this.headers = new Headers();
        if(attr && typeof(attr) !='string'){
            this.attributesToGetData = JSON.stringify(attr);
        }else{
            this.attributesToGetData = attr;
        }
       this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)



                   //   let dummy =  JSON.stringify(this.attributesToGetData); 

       return this._http.post(this.url,this.attributesToGetData,this.options).map(response => response.json());
    }
    
    public getClientData(){
        // return this._http.get(this.url).map(res => res.json());
        return this._http.get(this.url).map(response => response.json());
       
    }
    public setXmlUrl(url){
        this.urlToXml = url;
    }
    public getXml(){
        return this._http.get(this.urlToXml).map(response => response)
    }
    
    public setSharePointName(nameToSearch){
        this.sharePointsearchFldrName = nameToSearch;
    }
    public getSharePointName(){
        return this.sharePointsearchFldrName;
    }
}