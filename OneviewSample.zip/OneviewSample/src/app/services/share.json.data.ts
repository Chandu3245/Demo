import { Injectable } from '@angular/core';

import {environment} from '../../environments/environment';

@Injectable()
export class ShareJsonData{
    private getSharePointJsonData = [ {
			"created": "28 September 2016",
			"name": "T_DOC_INFO.csv",
            "rootUrl": environment.SPURL,
			"modified": "28 January 2016",
			"title": "T_DOC_INFO"
		},
        {
			"created": "28 September 2016",
			"name": "T_FLOOD_ZONE_disable_constraint.sql",
            "rootUrl": environment.SPURL,
			"modified": "28 February 2016",
			"title": "T_FLOOD_ZONE_disable_constraint"
		},
        
        {
			"created": "28 September 2016",
			"name": "T_FLOOD_ZONE_enable_constraint.sql",
            "rootUrl": environment.SPURL,
			"modified": "28 March 2016",
			"title": "T_FLOOD_ZONE_enable_constraint"
		},
        {
			"created": "28 September 2016",
			"name": "T_GEOZONE.FLOOD_ZONES_FLAG_update.sql",
             "rootUrl": environment.SPURL,
			"modified": "28 April 2016",
			"title": "T_GEOZONE.FLOOD_ZONES_FLAG_update"
		},
        {
			"created": "28 September 2016",
			"name": "Claims_G_2.png",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_G_2",
			"contentType": "image/png\n\nGeneral"
		},
         {
			"created": "28 September 2016",
			"name": "Claims_Manager_In-box_CTMF_Error.tif",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_Manager_In-box_CTMF_Error",
			"contentType": "General"
		},
        {
			"created": "28 September 2016",
			"name": "Claims_company.gif",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
			"title": "Claims_company",
             "rootUrl": environment.SPURL,
			"contentType": "General"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Authority Database_Business_Case_V1.doc",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
			"title": "Claims Authority Database_Business_Case_V1",
             "rootUrl": environment.SPURL,
			"contentType": "application/msword\n\nGeneral"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Documents for the second quarter 2009  FDEA _08_41_56.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims Documents for the second quarter 2009  FDEA ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Manager Notification - Pickup DecisionTazur  26CBA _08_30_40.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims Manager Notification - Pickup DecisionTazur  26CBA ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Manager Notification - Pickup DecisionTazur  26CBE _08_30_40.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims Manager Notification - Pickup DecisionTazur  26CBE ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims_G_2.png",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_G_2",
			"contentType": "image/png\n\nGeneral"
		},
         {
			"created": "28 September 2016",
			"name": "Claims_Manager_In-box_CTMF_Error.tif",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_Manager_In-box_CTMF_Error",
			"contentType": "General"
		},
        {
			"created": "28 September 2016",
			"name": "Claims_company.gif",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_company",
			"contentType": "General"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Authority Database_Business_Case_V1.doc",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims Authority Database_Business_Case_V1",
			"contentType": "application/msword\n\nGeneral"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Documents for the second quarter 2009  FDEA _08_41_56.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims Documents for the second quarter 2009  FDEA ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Manager Notification - Pickup DecisionTazur  26CBA _08_30_40.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims Manager Notification - Pickup DecisionTazur  26CBA ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Manager Notification - Pickup DecisionTazur  26CBE _08_30_40.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims Manager Notification - Pickup DecisionTazur  26CBE ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims_G_2.png",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_G_2",
			"contentType": "image/png\n\nGeneral"
		},
         {
			"created": "28 September 2016",
			"name": "Claims_Manager_In-box_CTMF_Error.tif",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_Manager_In-box_CTMF_Error",
			"contentType": "General"
		},
        {
			"created": "28 September 2016",
			"name": "Claims_company.gif",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
			"modified": "28 September 2016",
             "rootUrl": environment.SPURL,
			"title": "Claims_company",
			"contentType": "General"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Authority Database_Business_Case_V1.doc",
			"contentTypeId": "0x010100CDE681F030294046A7CE5196AE19110E005EE7372436AB4FAFB053C5BB1137B9680065D9C4ED7E7EDB44B8F16B44EAC7E3A000F4C891A400672645A12040E4F5CC92E9",
		    "modified": "28 May 2017",
             "rootUrl": environment.SPURL,
			"title": "Claims Authority Database_Business_Case_V1",
			"contentType": "application/msword\n\nGeneral"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Documents for the second quarter 2009  FDEA _08_41_56.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
		    "modified": "28 May 2017",
             "rootUrl": environment.SPURL,
			"title": "Claims Documents for the second quarter 2009  FDEA ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Manager Notification - Pickup DecisionTazur  26CBA _08_30_40.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 May 2017",
             "rootUrl": environment.SPURL,
			"title": "Claims Manager Notification - Pickup DecisionTazur  26CBA ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        {
			"created": "28 September 2016",
			"name": "Claims Manager Notification - Pickup DecisionTazur  26CBE _08_30_40.eml",
			"contentTypeId": "0x0101000B484A70B6BB4A80819354C21312FC91009C903079F2643C4FBCF92E2BE1577374",
			"modified": "28 May 2017",
             "rootUrl": environment.SPURL,
			"title": "Claims Manager Notification - Pickup DecisionTazur  26CBE ",
			"contentType": "message/rfc822\n\nSwiss Re Harmon.ie Mail"
		},
        
        {
			"created": "28 September 2016",
			"name": "Underwriting_strategy.aspx",
			"contentTypeId": "0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF390064DEA0F50FC8C147B0B6EA0636C4A7D40039AF475BBA1FF14EA1EF7F2CB7042D85",
			"modified": "28 September 2016",
            "rootUrl": "https://ep-dev.swissre.com/sites/NewsCentre/SwissReNews/",
			"title": "Underwriting Strategy",
			"contentType": "text/html; charset=utf-8\n\nWelcome Page"
		},
        {
			"created": "28 September 2016",
			"name": "Underwriting.jpg",
			"contentTypeId": "0x0101003A24273DD3C64844A212D3FDA9ADFDE2",
			"modified": "28 April 2017",
             "rootUrl": "https://ep-dev.swissre.com/sites/NewsCentre/SwissReNews/",
			"title": "Underwriting",
			"contentType": "image/jpeg\n\nDocument"
		},
        {
			"created": "28 September 2016",
			"name": "Underwriting.aspx",
			"contentTypeId": "0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF3900242457EFB8B24247815D688C526CD44D0063FA9A078F9D8E47A654A558B66242FF0074217AA1BCFDD14BAA4665A33B9453C7",
			"modified": "28 May 2017",
               "rootUrl": "https://shp-dev.swissre.com/sites/wire2017/",
			"title": "Underwriting",
			"contentType": "text/html; charset=utf-8\n\nNEP Structured Content Page"
		},
        {
			"created": "28 September 2016",
			"name": "Underwriting Capacity for Credit Risk Reinsurance Business.pdf",
			"contentTypeId": "0x0101009AC8E87F3CA2714BA9E4A95E2392281F",
			"modified": "28 March 2017",
             "rootUrl": "https://shp-dev.swissre.com/sites/wire2017/",
			"title": "Underwriting Capacity for Credit Risk Reinsurance Business",
			"contentType": "application/pdf\n\nDocument"
		},{
			"created": "28 September 2016",
			"name": "Underwriting 7.docx",
			"contentTypeId": "0x010100774E5C96DF8E476E8C463A3C65F17EF1006135A7814EBB44F589AA32B060A5996A003510451406765847BFE5BCCFC127811101010101004F06BFB9C2757C4AA1A1744A28078DF0",
			"modified": "28 May 2017",
             "rootUrl": "https://shp-dev.swissre.com/sites/wire2017/",
			"title": "Underwriting 7",
			"contentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document\n\nTreaty Document"
		}
        
        
    ];
    
    public getSharePointJsonList(){
        return this.getSharePointJsonData;
    }
     
}