import { CommonModule } from '@angular/common';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';

import {ExplorerComponent} from './explorer.component';
import { MyMaterialModule } from '../material.module';
import { SearchModule } from './../searchComponent/search.module';


@NgModule({
  declarations: [
    ExplorerComponent   
  ],
  imports: [CommonModule,FormsModule,MyMaterialModule],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  exports:[ExplorerComponent]
  
})
export class ExplorerModule { }
