import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ExplorerComponent } from '../explorerComponent';
import { SearchModule } from './../searchComponent/search.module';

const routes: Routes = [
  { path: '', component: ExplorerComponent ,
  children: [
    {
      path: '',
      loadChildren: '../searchComponent/search.module#SearchModule'
     }
]
}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);