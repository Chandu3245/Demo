import { Component, ChangeDetectorRef, EventEmitter, DoCheck, Input, OnInit, Output, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

import { ClientDataService, ShareDataService } from '../services';


@Component({
    selector: 'explorer-comp',
    templateUrl: './explorer.component.html',
    styleUrls: ['./explorer.component.scss']
})
export class ExplorerComponent implements DoCheck {


    @Input() docTransType;
    @Input() treeData;
    @Input() explorerHeading;
    @Input() listOfFavorite;

    @Output() explorerHeadingOutput: EventEmitter<any> = new EventEmitter();

   private opened: boolean;
    // private treeData:any;
    private flatArray: any = [];
    private curele: any;
    // private listOfFavorite:any=[];
    private previousLevel: any;
    private paddingBasedOnLevel: any;
    private paddingToBeApplied: any;
    private paddingforIcon: any;
    private widthToBeApplied: any;
    private listOfFolderDisplayed: any = [];
    private openedFoldersList: any = [];
    private listOfFoldersClosed: any = [];
    private listOfFolders: any = [];
    private listOfDirectChild: any = [];
    public scrollbarOptions = { axis: 'yx', theme: 'minimal-dark' };
    private folderIndex: any = 0;
    private sharePointFldrIndex: any;
    private sharePointFldrName: any;
    private sharePointFoldersList: any = [];
    private showShareointFolders: boolean = false;
    private transTypeToAddFldr: any;
    private breadCrumbFldr: any = [];
    private shareFldrAccessed: boolean = false;
    private fldrs: any = [];
    private breadBackUp: any = [];
    private dummyList: any = [];
    private parnTocrnt: any = "";
    private treedata: any = [];
    private breadCrumbList = [];
    private mostRecentlyVistedFldr: any = '';
    private activeFolderTree: any = -1;
    private selectedFolderValue: any;
    private parentFoldersList: any = [];
    @Output() activeFolderTreeOutput: EventEmitter<any> = new EventEmitter();
    @Output() listOfFavoriteOutput: EventEmitter<any> = new EventEmitter();

    constructor( @Inject(ChangeDetectorRef) private ref: ChangeDetectorRef,
        @Inject(Router) private router: Router,
        @Inject(ClientDataService) private clientDataService: ClientDataService,
        @Inject(ShareDataService) private shareDataService: ShareDataService,
        @Inject(MatSnackBar) public snackBar: MatSnackBar) {
            // constructor body
    }
    ngOnInit() {
        this.breadCrumbList = this.shareDataService.getBreadCrumbsArr();    //to load breadCrumbs , disable for now
    }
    ngOnChanges() {
        this.breadCrumbFldr = [];
        this.breadCrumbFldr.push(this.docTransType);
        if (this.treeData) {
            this.createTree();
        }
    }
    ngDoCheck() {
        let listOfFldrs = [];
        listOfFldrs = this.shareDataService.getFoldersToBeAdded().fldrList;
        if ((listOfFldrs.length > 0) && (listOfFldrs != this.sharePointFoldersList)) {
            this.showShareointFolders = true;
            this.addSharePointFolders();
        }
    }
    //method to emit output on folder select
    folderTree() {
        this.activeFolderTree = 0;
        this.activeFolderTreeOutput.emit(this.activeFolderTree);
    }

    // method to create tree from the input
    private createTree() {
        let keysIntreedata = Object.keys(this.treeData);
        let treeLevel = 0;
        let unparsedTree: any;
        let parentEle = '';
        this.listOfFolderDisplayed.push(keysIntreedata[0]);
        for (let i in this.treeData) {
            unparsedTree = this.treeData[i];
            let currentEle = i;
            this.createFlatArray(unparsedTree, treeLevel, parentEle, currentEle)
        }
        for (let i = 2; i < this.flatArray.length; i = i + 2) {
            this.listOfFolders.push(this.flatArray[i]);
        }
        for (let j = 0; j < this.flatArray.length; j = j + 3) {
            this.parentFoldersList.push(this.flatArray[j]);
        }

    }

    // method to create flat Array , this will be used to create the tree
    //Flat Array Structure Parent 
    private createFlatArray(treeToBeParsed, treeDepth, parentNode, currentNode) {
        let depth = treeDepth;
        let tree = treeToBeParsed;
        let parele = parentNode;
        if (typeof (currentNode) != 'object' && (this.curele != currentNode)) {
            this.flatArray.push(parentNode, treeDepth, currentNode);
            this.curele = currentNode;
            depth++;
        }
        if (typeof (tree) == 'object' && tree.length) {
            for (let i = 0; i < treeToBeParsed.length; i++) {
                let arrayOfKeyInCurrentEle = Object.keys(tree[i]);
                for (let j = 0; j < arrayOfKeyInCurrentEle.length; j++) {
                    this.createFlatArray(tree[i], depth, currentNode, arrayOfKeyInCurrentEle[j]);
                }
            }
        } else if (typeof (tree) == 'object') {
            for (let i in treeToBeParsed) {
                tree = treeToBeParsed[i];
                this.createFlatArray(tree, depth, currentNode, i);
            }
        } else {
            let i = 0;
            while (i <= 2) {
                this.flatArray.pop();
                i++;
            }
            this.flatArray.push(parentNode, treeDepth, tree);
            this.curele = tree;
        }
    }

    // method to check if the item passed from HTMl is tree node or depth
    private checkIfLevelOrItem(item, i) {
        //if true then its node
        if ((i + 1) % 3 == 0) {
            return true;
        } else {
            if (Number(item) != NaN) {
                this.previousLevel = this.previousLevel ? this.previousLevel : Number(item);
                this.paddingBasedOnLevel = 10 * Number(item);
                this.paddingToBeApplied = this.paddingBasedOnLevel + 'px';
                this.paddingforIcon = Number(172) - this.paddingBasedOnLevel;
                this.paddingforIcon = this.paddingforIcon + "px"
                this.widthToBeApplied = this.paddingBasedOnLevel + 190;
                this.widthToBeApplied = this.widthToBeApplied + 'px';
                this.previousLevel = Number(item);
            }
            return false;
        }
    }
    //method to check if the folder is displayed , the folder will be displayed if the parent folder is open
    private checkIfFolderDisplayed(ele) {
        let showFolder = false;
        if (this.listOfFolderDisplayed.indexOf(ele) >= 0) {
            showFolder = true;
            this.treedata.push(ele);
        }
        return showFolder;
    }
    //method to check if folder is opened
    public checkIfFolderOpened(item) {
        if (this.openedFoldersList.indexOf(item) >= 0) {
            return true;
        } else {
            return false;
        }
    }
    //dummy method.
    private testFunc() {

    }
    //method to check if the folder is set as favourite
    public checkFavorite(item) {
        if (this.listOfFavorite && this.listOfFavorite.indexOf(item) < 0) {
            if(this.listOfFavorite.length<10){
            this.listOfFavorite.push(item);
        }
        else{
            this.snackBar.open("To add more favorite, remove some favorite from list", 'Close', {
                        duration: 5000,
                    });
        }
            this.listOfFavoriteOutput.emit(this.listOfFavorite);
        }
    }
    //method to make the folder not favourite
    public undoFavorite(item) {
        if (this.listOfFavorite.indexOf(item) >= 0) {
            this.listOfFavorite.splice(this.listOfFavorite.indexOf(item), 1);
            this.listOfFavoriteOutput.emit(this.listOfFavorite);
        }
    }
    //method to toggle folder state . to open and close folder
    private toggleFolderState(item) {
        this.explorerHeadingOutput.emit(this.explorerHeading);
        this.mostRecentlyVistedFldr = item;
        //block to open folder
        if (this.openedFoldersList.indexOf(item) < 0) {
            this.openedFoldersList.push(item);
            for (let i = 0; i < this.flatArray.length; i = i + 3) {
                if (this.flatArray[i] == item) {
                    let eleIndex = i + 2;
                    this.listOfFolderDisplayed.push(this.flatArray[eleIndex]);
                }
            }
        }   //block to close sub-folder    
        else {
            if (this.openedFoldersList.indexOf(item) >= 0) {
                this.openedFoldersList.splice(this.openedFoldersList.indexOf(item), 1);
                this.opened = false;
            }
            for (let i = 0; i < this.flatArray.length; i = i + 3) {
                if (item == this.flatArray[i]) {
                    let fldrToBePopped = this.flatArray[i + 2];
                    if (this.openedFoldersList.indexOf(fldrToBePopped) >= 0) {
                        this.openedFoldersList.splice(this.openedFoldersList.indexOf(fldrToBePopped), 1);
                        this.listOfDirectChild.push(fldrToBePopped);
                    }
                    if (this.listOfFolderDisplayed.indexOf(fldrToBePopped) >= 0) {
                        this.listOfFolderDisplayed.splice(this.listOfFolderDisplayed.indexOf(fldrToBePopped), 1);
                    }
                }
            }
            this.traverseAndCloseSubFolders(this.listOfDirectChild);
        }
        this.shareDataService.setListOfFoldersOpened(this.openedFoldersList)
        this.setBreadCrumbs(item);
    }
    //method to save the folders traversed in a breadcrumb
    private setBreadCrumbs(fldrName, shareFldr?) {
        this.dummyList = [];
        for (let i = 2; i < this.flatArray.length; i = i + 3) {
            this.dummyList.push(this.flatArray[i]);
        }
        if (this.breadCrumbFldr.indexOf(fldrName) < 0) {
            if (shareFldr) {
                this.breadBackUp = this.breadCrumbFldr;
                this.breadCrumbFldr = [];
                this.breadCrumbFldr[0] = this.docTransType;
                this.breadCrumbFldr.push(fldrName);
                this.shareFldrAccessed = true;
            } else {
                let shareFldr = this.shareDataService.getFoldersToBeAdded().fldrList;
                for (let i = 0; i < shareFldr.length; i++) {
                    if (this.breadCrumbFldr.indexOf(shareFldr[i]) > 0) {
                        this.breadCrumbFldr.splice(this.breadCrumbFldr.indexOf(shareFldr[i]), 1);
                    }
                }
                this.fldrs = [];
                this.loopToFindParents(fldrName);
                 this.breadCrumbFldr.length = 1;
                this.fldrs = this.fldrs.reverse();
                for (let i = 0; i < this.fldrs.length; i++) {
                    if (this.breadCrumbFldr.indexOf(this.fldrs[i]) < 0) {
                        this.breadCrumbFldr.push(this.fldrs[i]);
                    }
                }
                this.breadCrumbFldr.push(fldrName);
                this.shareFldrAccessed = false;
            }
        }
        else if (this.breadCrumbFldr.indexOf(fldrName) != this.breadCrumbFldr.length) {
            this.breadCrumbFldr.splice(this.breadCrumbFldr.indexOf(fldrName) + 1, this.breadCrumbFldr.length);
        }
        this.shareDataService.setBreadCrumbsArr(this.breadCrumbFldr);
    }

    //method to find the parent of current node
    private loopToFindParents(crntFldr) {
        let indexInFldrArr = this.dummyList.indexOf(crntFldr);
        let prntToCrntIndex = indexInFldrArr * 3;
        this.parnTocrnt = this.flatArray[prntToCrntIndex]
        while (prntToCrntIndex > 0) {
            if (this.flatArray[prntToCrntIndex] != "") {
                this.fldrs.push(this.flatArray[prntToCrntIndex]);
                indexInFldrArr = this.dummyList.indexOf(this.flatArray[prntToCrntIndex]);
                prntToCrntIndex = indexInFldrArr * 3;
            }
        }
    }
    //method to travers throught the flat array and close all the child nodes 
    private traverseAndCloseSubFolders(listToBeLooped) {
        for (let i = 0; i < listToBeLooped.length; i++) {
            for (let j = 0; j < this.flatArray.length; j = j + 3) {
                if (this.flatArray[j] == listToBeLooped[i]) {
                    let fldrToBeClosed = this.flatArray[j + 2];
                    if (this.openedFoldersList.indexOf(fldrToBeClosed) >= 0) {
                        this.openedFoldersList.splice(this.openedFoldersList.indexOf(fldrToBeClosed), 1);
                    }
                    if (this.listOfFolderDisplayed.indexOf(fldrToBeClosed) >= 0) {
                        this.listOfFolderDisplayed.splice(this.listOfFolderDisplayed.indexOf(fldrToBeClosed), 1);
                        let subFolderToBeLooped: any = [];
                        subFolderToBeLooped.push(this.flatArray[j + 2]);
                        this.traverseAndCloseSubFolders(subFolderToBeLooped);
                    }
                }
            }
        }
    }
    //method triggered on Hover of folder
    private mouseOverFolder(i, repo?) {
        if (repo) {
            this.sharePointFldrIndex = i;
        } else {
            this.folderIndex = i;
        }
    }
    //method triggered on mouse leave of folder
    private mouseLeaveFolder(repo?) {
        if (repo) {
            this.sharePointFldrIndex = -1;
        } else {
            this.folderIndex = -1;
        }
    }
    //method to route to a particular page based on folder
    private rouoteToRes(showDocGrid?) {
        this.router.navigateByUrl('', { skipLocationChange: true });
        this.clientDataService.setSharePointName(this.sharePointFldrName);
        if (showDocGrid) {
            this.shareDataService.setGridToBeShown('docGrid');
        } else {
            this.shareDataService.setGridToBeShown('folderGrid');
        }
        this.router.navigateByUrl('/explorer');
    }
    //method related to breadcrumb must be re written
    private addSharePointFolders() {
        let fldrAndTrans = this.shareDataService.getFoldersToBeAdded()
        this.sharePointFoldersList = fldrAndTrans.fldrList;
        this.transTypeToAddFldr = fldrAndTrans.docTransType;
    }
    //method related to breadcrumb . must be re written
    private setTransType() {
        this.shareDataService.setDocTransType(this.docTransType);
    }
    // method related to breadcrumb .should be re written
    public checkIfCompActive() {
        if (this.openedFoldersList == this.shareDataService.getListOfFoldersOpened()) {
            return true
        } else {
            return false;
        }
    }
    // method to check if the element is a parent 
    public checkIfParent(item) {
        if (this.parentFoldersList.indexOf(item) >= 0) {
            return true;
        }
        else {
            return false;
        }
    }

}