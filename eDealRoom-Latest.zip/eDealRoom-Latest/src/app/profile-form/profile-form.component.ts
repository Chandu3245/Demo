
import { Component, OnInit, Inject, EventEmitter, Output, Input } from '@angular/core';
import { FormControl, FormGroup, FormBuilder,Validators,ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { environment } from './../../environments/environment';
import { MatDialog,MatDialogModule, MatDialogRef } from '@angular/material';
import { CreateProfileDialogComponent } from '../create-profile-dialog/create-profile-dialog.component';
import { ClientDataService } from './../services/app.service';

@Component({
  selector: 'app-profile-form',
  templateUrl: './profile-form.component.html',
  styleUrls: ['./profile-form.component.scss']
})
export class ProfileFormComponent implements OnInit {
 @Input() isUsedIn;
  @Input() formObj;
  @Input() colmd6:boolean;
  @Input() activeClick: any;
  @Input() compId;
   @Input() userId;
   @Input() disableCheckBox: boolean;
   @Input() closeDialogAfterCreation: boolean;
  @Input() progressBarForCompany;
  @Output() updateList:EventEmitter<any>=new EventEmitter();
  @Output() disableDelete:EventEmitter<any>=new EventEmitter();
  @Output() createCompanyList:EventEmitter<any>=new EventEmitter();
  @Output() stopProgressEvent:EventEmitter<any>=new EventEmitter();
 @Output() getNewUserListByServer:EventEmitter<any>=new EventEmitter();
 @Output() getCompanyCreated:EventEmitter<any>=new EventEmitter();
  private companyId=6;
  private profileFormGroup: FormGroup;
  private companyDetails=[];
  private appUrl: any;
  private errorCode:any;
  private alphaNumericErrorMsg:boolean=false;
  private controlValue:any;
  constructor( @Inject(FormBuilder) private fb: FormBuilder,  @Inject(MatDialog)private dialog: MatDialog,
  @Inject(ClientDataService) private clientDataService: ClientDataService,
  @Inject(MatSnackBar) public snackBar: MatSnackBar) {
    this.appUrl = environment.appURL;
    }

  ngOnInit() {}
  ngOnChanges(){
    if( this.formObj && this.formObj.length!==0 ){
      this.profileFormGroup = this.createGroup();
      let count=0;
      console.log(this.formObj.values[0]);
      for(let item of this.formObj.properties){
        let data=item.attributeName;

        if(this.formObj.values[0][data]){
           
          this.profileFormGroup.controls[item.attributeName].setValue(this.formObj.values[0][data]);
        }
      }
     
    }
  }
  createGroup() {
    const group = this.fb.group({});
    this.formObj.properties.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
    return group;
  }
  createControl(config) {
    const { isDisabled,value } = config;
     let validation =[
      this.regexValidator(new RegExp(''), {'checkEmpty': ''}),
      this.regexValidator(new RegExp('^[a-zA-Z]+[a-zA-Z0-9]*$'), {'number': ''}),
      this.regexValidator(new RegExp('^[a-zA-Z0-9]+$'), {'precision': ''})
    ]
 
    let control= this.fb.control({ 'value': value, 'disabled': isDisabled},validation);
    let attributeName = config.attributeName;
    let self=this;
    control.valueChanges.subscribe(res => {
        self.controlChanged(control, attributeName);
    })
    return control;
  }
  public controlChanged(ctrl, nameOfAttribute) {
    if(ctrl.value.match('^[a-zA-Z0-9]+$')==null){
    if(ctrl.value== ''){
      ctrl.setErrors({'checkEmpty':true});
    
    }else{
      ctrl.setErrors({'precision':true});
    }
   }
   else if(ctrl.value.match('^[a-zA-Z]+[a-zA-Z0-9]*$')==null){
      ctrl.setErrors({'number':true});
  }
  }
  regexValidator(regex: RegExp, error: ValidationErrors): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      return valid ? null : error;
    };
  }

  openAddProfileDialog(): void{

    this.dialog.open(CreateProfileDialogComponent, {width: '450px'} )

  }
  // updating user/company
   update(){
    if(this.isUsedIn=="company")
  {
     let self=this;
     self.progressBarForCompany=true;
     self.stopProgressEvent.emit(self.progressBarForCompany)
      let formObj=
    {
     "id": 64,
     "creationUser": null,
     "creationDate": null,
     "lastModifiedUser": null,
     "lastModifiedDate": null,
     "name": "ACE Bermuda Insurance Limited",
     "activeInd": false,
     "internalInd": true,
     "marketName": "swiss re Market7 updated",
     "users": null
   } 
     formObj.id=this.compId;
   for(let ctrl in this.profileFormGroup.controls){
      if(ctrl== 'activeInd'){
        formObj.activeInd=this.profileFormGroup.controls[ctrl].value;
      }if(ctrl== 'name'){
        formObj.name=this.profileFormGroup.controls[ctrl].value;
      }if(ctrl== 'marketName'){
        formObj.marketName=this.profileFormGroup.controls[ctrl].value;
      }if(ctrl== 'internalInd'){
        formObj.internalInd=this.profileFormGroup.controls[ctrl].value;
      }if(ctrl== 'users'){
        formObj.users=this.profileFormGroup.controls[ctrl].value;
      }
      }
    this.activeClick=null;
    let postSelectedList= this.appUrl + "companies/"+ JSON.stringify(this.compId);
    this.clientDataService.setUrl(postSelectedList);
   this.clientDataService.PutClientData(formObj).subscribe(res => {
     
      self.updateList.emit();
      self.disableDelete.emit(true);
      self.progressBarForCompany=false;
      self.stopProgressEvent.emit(self.progressBarForCompany)
      self.getNewUserListByServer.emit('updated');  
      self.openSnackBar("Company List has been updated succefully");
	  
    },err =>{
      let errVal = JSON.parse(err._body);
     this.errorCode=errVal.errorMessages;
      self.progressBarForCompany=false;
      self.stopProgressEvent.emit(self.progressBarForCompany)
      self.openSnackBar(errVal.errorMessages);
     }
  );
   }
   else if(this.isUsedIn=="user"){
    let formObj=
    {
      "id":this.userId,
      "orgUserId": "",
      "company": {
                      "id": this.compId,
      },
      "firstName": "",
      "lastName": "",
      "emailAddress": "",
   }
    for(let ctrl in this.profileFormGroup.controls)
    {
        if(ctrl== 'firstName'){
          formObj.firstName=this.profileFormGroup.controls[ctrl].value;
        }if(ctrl== 'lastName'){
          formObj.lastName=this.profileFormGroup.controls[ctrl].value;
        }if(ctrl== 'orgUserId'){
          formObj.orgUserId=this.profileFormGroup.controls[ctrl].value;
        }if(ctrl== 'emailAddress'){
          formObj.emailAddress=this.profileFormGroup.controls[ctrl].value;
        }
    }
    let putSelectedList= this.appUrl + "users/" + JSON.stringify(this.userId);
    this.clientDataService.setUrl(putSelectedList);
    this.clientDataService.PutClientData(formObj).subscribe(res => {
      this.getNewUserListByServer.emit('updated');  
      this.openSnackBar("User List has been updated successfully");
      }
      ,err =>{
        let errVal = JSON.parse(err._body);
        this.errorCode=errVal.errorMessages;
        this.openSnackBar(errVal.errorMessages);
       }
    );
  } 
  }
  //creating user/company
  create(){
    let self=this;
   if(this.isUsedIn=="company"){
   
    self.progressBarForCompany=true;
    self.stopProgressEvent.emit(self.progressBarForCompany)
    let formObj=
    {
     "id": 0,
     "creationUser": null,
     "creationDate": null,
     "lastModifiedUser": null,
     "lastModifiedDate": null,
     "name": "ACE Bermuda Insurance Limited",
     "activeInd": false,
     "internalInd": true,
     "marketName": "swiss re Market7 updated",
     "users": null
   }
   formObj.id=0;
 for(let ctrl in this.profileFormGroup.controls){
    if(ctrl== 'activeInd'){
      formObj.activeInd=this.profileFormGroup.controls[ctrl].value;
    }if(ctrl== 'name'){
      formObj.name=this.profileFormGroup.controls[ctrl].value;
      this.getCompanyCreated.emit(formObj.name);
    }if(ctrl== 'marketName'){
      formObj.marketName=this.profileFormGroup.controls[ctrl].value;
    }if(ctrl== 'internalInd'){
      formObj.internalInd=this.profileFormGroup.controls[ctrl].value;
    }if(ctrl== 'users'){
      formObj.users=this.profileFormGroup.controls[ctrl].value;
    }
    }
    let postSelectedList= this.appUrl + "companies/" ;
    this.clientDataService.setUrl(postSelectedList);
    this.clientDataService.PostClientData(formObj).subscribe(res => {
          self.createCompanyList.emit();
          self.progressBarForCompany=false;
          self.stopProgressEvent.emit(self.progressBarForCompany)
          self.getNewUserListByServer.emit('created');  
          self.openSnackBar("New Company has been added in company List");
          this.closeDialog();
    },err =>{
      let errVal = JSON.parse(err._body);
      this.errorCode=errVal.errorMessages;
      self.progressBarForCompany=false;
      self.stopProgressEvent.emit(self.progressBarForCompany)
      self.openSnackBar(errVal.errorMessages);
     }
  );
}
 else if(this.isUsedIn=="user"){
    let formObj=
    {
      "orgUserId": "",
     "company": {
                      "id": this.compId,
      },
      "firstName": "",
      "lastName": "",
      "emailAddress": "",
    }
    for(let ctrl in this.profileFormGroup.controls)
      {
          if(ctrl== 'firstName'){
            formObj.firstName=this.profileFormGroup.controls[ctrl].value;
          }if(ctrl== 'lastName'){
            formObj.lastName=this.profileFormGroup.controls[ctrl].value;
          }if(ctrl== 'orgUserId'){
            formObj.orgUserId=this.profileFormGroup.controls[ctrl].value;
          }if(ctrl== 'emailAddress'){
            formObj.emailAddress=this.profileFormGroup.controls[ctrl].value;
          }
      }
      let postSelectedList= this.appUrl + "users" ;
      this.clientDataService.setUrl(postSelectedList);
      this.clientDataService.PostClientData(formObj).subscribe(res => {
        this.getNewUserListByServer.emit('created');  
      
       self.openSnackBar("New User has been added in user List");
  },err =>{
        let errVal = JSON.parse(err._body);
        this.errorCode=errVal.errorMessages;
        self.openSnackBar(errVal.errorMessages);
  }
    );
    }
}
  
    // generic method to handle snackbar
    public openSnackBar(msg){
      this.snackBar.open(msg, 'Close', {
          duration: 5000,
      });
  }
  
  //close dialog after company creation from create deal
  closeDialog(){
    if( this.closeDialogAfterCreation){
      this.dialog.closeAll();
    }
  }
  
//Method to check validation on save button
public checkIfFormValid(){
  //Dont remove this commented code  , ll use in future
  // ==================================
  // for(let ctrl in this.profileFormGroup.controls){
  //  if(!this.profileFormGroup.controls[ctrl].value){
  //   return true;
  //  }
  // }
  // ================
//   if(this.profileFormGroup){
//     if(this.isUsedIn=='company'){
//       if(!this.profileFormGroup.controls['name'].value || !this.profileFormGroup.controls['marketName'].value)
//       {
//          return true;
//           }
//     }
// else if(this.isUsedIn=="user"){
//   if(!this.profileFormGroup.controls['firstName'].value || !this.profileFormGroup.controls['lastName'].value || !this.profileFormGroup.controls['emailAddress'].value || !this.profileFormGroup.controls['orgUserId'].value)
//   {
//      return true;
//       }
//     }
//   }
if(this.profileFormGroup){
for(let ctrl in this.profileFormGroup.controls){
if(this.profileFormGroup.controls[ctrl].invalid){
return true;
}
}
return false;
}
}
}
