import { Component, OnInit, Inject } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { ClientDataService } from '../../../services/app.service';
import { BusinessProfileService } from '../business-profile.service';

@Component({
  selector: 'app-data-sources',
  templateUrl: './data-sources.component.html',
  styleUrls: ['./data-sources.component.scss']
})
export class DataSourcesComponent implements OnInit {

  private dataSourceName: any = [];
  private dataSourceValues: any = [];
  private appUrl: string;
  constructor(@Inject(ClientDataService) private clientDataService: ClientDataService, @Inject(BusinessProfileService) private businessProfileService: BusinessProfileService) {
    this.appUrl = environment.appURL;
   }

  ngOnInit() {
    this.getDataSourceDataFromServer();
  }

  getDataSourceDataFromServer(){
    let dataUrl = this.appUrl + 'dataSource';
    console.log(dataUrl);
    this.clientDataService.setUrl(dataUrl);
    this.clientDataService.getClientData().subscribe( dataSource =>
      {
        console.log(dataSource);
        this.dataSourceValues = dataSource;
      }
    );
  }
}
