import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { environment } from '../../../../../environments/environment';
import { ClientDataService } from '../../../../services/app.service';

@Component({
  selector: 'app-data-source-configuration',
  templateUrl: './data-source-configuration.component.html',
  styleUrls: ['./data-source-configuration.component.scss']
})
export class DataSourceConfigurationComponent implements OnInit {

  private appUrl: string;
  private dataSourceId: number;
  constructor(@Inject(ActivatedRoute) private route: ActivatedRoute, @Inject(ClientDataService) private clientDataService: ClientDataService) { 

    this.dataSourceId = +this.route.snapshot.paramMap.get('id');
    this.appUrl = environment.appURL;
   }

  ngOnInit() {
    
    console.log(this.dataSourceId);
    this.getDataSourceFormFromServer()
  }
  getDataSourceFormFromServer(){
    let dataUrl = this.appUrl + '/dataSource/' + JSON.stringify(this.dataSourceId);
    this.clientDataService.setUrl(dataUrl);
    this.clientDataService.getClientData().subscribe(data => 
      {
       console.log(data);
       
      }
    );
  }

}
