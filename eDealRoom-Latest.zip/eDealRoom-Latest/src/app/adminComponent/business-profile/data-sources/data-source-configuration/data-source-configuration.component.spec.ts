import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataSourceConfigurationComponent } from './data-source-configuration.component';

describe('DataSourceConfigurationComponent', () => {
  let component: DataSourceConfigurationComponent;
  let fixture: ComponentFixture<DataSourceConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataSourceConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataSourceConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
