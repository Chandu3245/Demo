

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomGroupsComponent } from './custom-groups/custom-groups.component';
import { ApplicationPermissionsComponent } from './application-permissions/application-permissions.component';
import { BusinessHierarchyComponent } from './business-hierarchy/business-hierarchy.component';
import { ProfileFieldsComponent } from './profile-fields/profile-fields.component';
import { ProfileFieldsGroupDialogComponent } from './profile-fields/profile-fields-group-dialog/profile-fields-group-dialog.component';
import { ProfileFieldsDialogComponent } from './profile-fields/profile-fields-dialog/profile-fields-dialog.component';
import { AddGroupDialogComponent } from './profile-fields/add-group-dialog/add-group-dialog.component';
import { AddProfilefieldDialogComponent } from './profile-fields/add-profilefield-dialog/add-profilefield-dialog.component';
import { DataSourcesComponent } from './data-sources/data-sources.component';
import { DataSourceConfigurationComponent } from './data-sources/data-source-configuration/data-source-configuration.component';
// import { ProfileFieldService } from './profile-fields/profile-fields.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CustomGroupsComponent, ApplicationPermissionsComponent, BusinessHierarchyComponent, ProfileFieldsComponent, ProfileFieldsGroupDialogComponent, ProfileFieldsDialogComponent, AddGroupDialogComponent, AddProfilefieldDialogComponent, DataSourcesComponent, DataSourceConfigurationComponent],
  //providers: [ProfileFieldService]
})
export class BusinessProfileModule { }
