
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { MatSortModule, MatPaginator, MatTableDataSource, MatTableModule, MatDialog, MatDialogRef } from '@angular/material';
import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { Observable, BehaviorSubject } from 'rxjs';

import { ClientDataService } from '../../../services/app.service';
import { ProfileFieldService } from './profile-fields.service';
import { environment } from '../../../../environments/environment';
import { ProfileFieldsGroupDialogComponent } from './profile-fields-group-dialog/profile-fields-group-dialog.component';
import { ProfileFieldsDialogComponent } from './profile-fields-dialog/profile-fields-dialog.component';
import { AddGroupDialogComponent } from './add-group-dialog/add-group-dialog.component';
import { AddProfilefieldDialogComponent } from './add-profilefield-dialog/add-profilefield-dialog.component';

@Component({
  selector: 'app-profile-fields',
  templateUrl: './profile-fields.component.html',
  styleUrls: ['./profile-fields.component.scss'],
})
export class ProfileFieldsComponent implements OnInit {

  private profileFieldsList: any = [];
  private groupIdForDialog: any;
  private selectedRow: any;
  private availGroupList: any = [];
  private formProperties: any = [];
  private profileFieldGroup: FormGroup;
  private appUrl: any;
  selectedGroupId: any;
  selectedDefault = 0;
  profileUpdate: boolean = false;
  private dataSource: ProfileFieldsDataSource;
  private profileGroupDialogRef: MatDialogRef<ProfileFieldsGroupDialogComponent>
  private profileFieldDialogRef: MatDialogRef<ProfileFieldsDialogComponent>
  private addGroupDialogRef: MatDialogRef<AddGroupDialogComponent>
  private addProfilefieldDialogRef: MatDialogRef<AddProfilefieldDialogComponent>

  displayedColumns = ['groupName', 'fieldName', 'fieldDesc', 'remove'];
  //dataSource = new MatTableDataSource(ELEMENT_DATA);

  constructor(private fb: FormBuilder, private clientDataService: ClientDataService, private profileFieldService: ProfileFieldService,
    private router: Router, private dialog: MatDialog) {
    this.appUrl = environment.appURL;
  }

  ngOnInit() {
    this.getProfileFieldsByServer();
    this.dataSource = new ProfileFieldsDataSource(this.clientDataService, this.profileFieldService);
    this.dataSource.getProfileFieldsDatafromServer();
  }
  // creates form groups
  createGroup(formObj) {
    const group = this.fb.group({});
    formObj.properties.forEach(control => {
      group.addControl(control.attributeName, this.createControl(control));
    });
    return group;
  }
  // creates Form controls 
  createControl(config) {
    const { isDisabled, validation, value } = config;
    return this.fb.control({ 'value': 0, 'disabled': isDisabled }, validation);
  }
  //creates Profile Fields Form with Json from server
  getProfileFieldsByServer() {
    let self = this;
    let createNewForm = this.appUrl + '/profilefieldGroup/home?attributeName=Profile Master Field List';
    this.clientDataService.setUrl(createNewForm);
    this.clientDataService.getClientData().subscribe(res => {
      this.formProperties = res.properties;
      this.profileFieldGroup = this.createGroup(res);
      // this.availGroupList = res.values;
      // for(let profile of this.availGroupList){
      //   for(let field of profile.profileFields){
      //     this.profileFieldsList.push(field);
      //   }
      // }
      // console.log(this.profileFieldsList);
      this.profileFieldService.getAllGroupName().subscribe(groups => {
        this.availGroupList = [];
        this.profileFieldsList = [];
        this.availGroupList = groups;
        for (let profile of this.availGroupList) {
          for (let field of profile.profileFields) {
            this.profileFieldsList.push(field);
          }
        }
      }
      );
    });
  }

  selectedGroup(item) {
    this.selectedGroupId = item;
    this.profileFieldService.setSelectedGroupId(this.selectedGroupId);
    console.log(this.selectedGroupId);
    // this.profileFieldGroup.controls['']
  }

  // navigates to seleted Name.
  public changeRoute(routeName, sideNavRef) {
    this.router.navigateByUrl(routeName);
  }

  //update group or profile fields based on selection
  onColumnClicked(name) {
    let groupOrFieldName = name;
    if (groupOrFieldName) {
      //For Profile Groups
      for (let group of this.availGroupList) {
        if (group.groupName == groupOrFieldName) {
          let idSelected = group.id;
          console.log('groupName' + group.id);

          this.profileGroupDialogRef = this.dialog.open(ProfileFieldsGroupDialogComponent, {
            height: '350px',
            width: '500px',
            data: { 'id': idSelected }
          });
          //returns the updated field of dialog component after close of dialog.
          this.profileGroupDialogRef.afterClosed().subscribe(res => { this.dataSource.getProfileFieldsDatafromServer() });
        }
      }
      // for Profile Fields
      for (let field of this.profileFieldsList) {
        if (field.fieldName == groupOrFieldName) {
          let idSelected = field.id;
          this.profileFieldDialogRef = this.dialog.open(ProfileFieldsDialogComponent, {
            height: '560px',
            width: '600px',
            data: { 'id': idSelected }
          });
          // returns the updated field of dialog component after close of dialog.
          this.profileFieldDialogRef.afterClosed().subscribe(res => { this.dataSource.getProfileFieldsDatafromServer() });
        }
      }
    }
  }

  //Create New ProfileFieldGroup
  createProfilefieldGroup() {
    this.addGroupDialogRef = this.dialog.open(AddGroupDialogComponent, {
      height: '350px',
      width: '500px',
      data: {}
    });
    // returns the updated field of dialog component after close of dialog.
    this.addGroupDialogRef.afterClosed().subscribe(res => {
      console.log(res);
      this.dataSource.getProfileFieldsDatafromServer();
      // this.profileFieldService.getAllGroupName().subscribe(groups => console.log(groups));
    });
  }

  createProfilefield() {
    let selectedId = this.selectedGroupId;
    console.log(selectedId);
    this.addProfilefieldDialogRef = this.dialog.open(AddProfilefieldDialogComponent, {
      height: '460px',
      width: '500px',
      data: { 'id': selectedId }
    });
    // returns the updated field of dialog component after close of dialog.
    this.addProfilefieldDialogRef.afterClosed().subscribe(res => { console.log(res); this.dataSource.getProfileFieldsDatafromServer() });
    //  this.dataSource.getProfileFieldsDatafromServer();
  }

}



export interface ProfileFieldsModel {
  groupName: string;
  fieldName: string;
  fieldDesc: string;
  remove: boolean;
}
//class that fetches data from DB
export class ProfileFieldsDataSource implements DataSource<ProfileFieldsModel> {

  private appUrl: any;
  public selectedId: any;
  private listOfGroups: any = [];
  private listOfProfileFields: any = [];
  //BehaviorSubject, which means its subscribers will always get its latest emitted value (or an initial value), even if they subscribed late (after the value was emitted).
  private profileFieldsSubject: BehaviorSubject<ProfileFieldsModel[]> = new BehaviorSubject<ProfileFieldsModel[]>([]);

  constructor(private clientDataService: ClientDataService, private profileFieldService: ProfileFieldService) {
    this.appUrl = environment.appURL;
  }

  //CollectionViewer, which provides an Observable that emits information about what data is being displayed (the start index and the end index)
  connect(collectionViewer: CollectionViewer): Observable<ProfileFieldsModel[]> {
    return this.profileFieldsSubject.asObservable();
  }
  //complete any observable that have been created to avoid memory leaks
  disconnect(collectionViewer: CollectionViewer): void {
    this.profileFieldsSubject.complete();
  }
  getProfileFieldsDatafromServer() {
    let pFieldUrl = this.appUrl + '/profilefieldGroup/home?attributeName=Profile Master Field List';
    this.clientDataService.setUrl(pFieldUrl);
    return this.clientDataService.getClientData().subscribe(profileFields => {
      this.listOfGroups = profileFields.values;
      this.listOfGroups.push({ 'id': 0, 'groupName': 'All', 'groupDesc': 'Select All', 'profileFields': [] });
      this.profileFieldService.setAllGroupName(this.listOfGroups);
      // subscribing to a behaviour subject which provides latest selected group id's and readies array of respective objects
      {
        this.profileFieldService.getSelectedGroupId().subscribe(val => {
          this.selectedId = val;
          for (let item of this.listOfGroups) {
            if (this.selectedId == 0) {
              for (let data of item.profileFields) {
                this.listOfProfileFields.push({ 'groupName': item.groupName, 'fieldName': data.fieldName, 'fieldDesc': data.fieldDesc });
              }
            }
            else if (item.id != 0 && item.id == this.selectedId) {
              for (let data of item.profileFields) {
                this.listOfProfileFields.push({ 'groupName': item.groupName, 'fieldName': data.fieldName, 'fieldDesc': data.fieldDesc });
              }
            }
          }
          console.log(this.selectedId);
          console.log(this.listOfProfileFields);
          this.profileFieldsSubject.next(this.listOfProfileFields);
          this.listOfProfileFields = [];
        });
      }
    });
  }
}