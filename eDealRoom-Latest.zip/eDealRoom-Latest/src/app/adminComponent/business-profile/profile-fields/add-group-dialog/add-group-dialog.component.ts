import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { ClientDataService } from '../../../../services/app.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-add-group-dialog',
  templateUrl: './add-group-dialog.component.html',
  styleUrls: ['./add-group-dialog.component.scss']
})
export class AddGroupDialogComponent implements OnInit {

  addGroupDialogproperties: any;
  addGroupDialogForm: FormGroup;
  private appUrl: string;
  constructor(private dialogRef: MatDialogRef<AddGroupDialogComponent>, @Inject(MAT_DIALOG_DATA) private data: any, private clientDataService: ClientDataService, 
  private fb: FormBuilder, private snackBar: MatSnackBar ) {
    this.appUrl = environment.appURL;
   }

  ngOnInit() {
    this.getaddGroupDialogFormFromServer();
  }

  // creates form form groups
createGroup(formObj) {
  const group = this.fb.group({});
  formObj.forEach(control => { group.addControl(control.attributeName, this.createControl(control));
  });
  return group;
}
// creates Form controls 
createControl(config) {
  const { isDisabled, validation, value } = config;
  return this.fb.control({'value': value, 'disabled': isDisabled }, validation);
}

  getaddGroupDialogFormFromServer(){ 
    let dialogFormUrl = this.appUrl + 'profilefieldGroup/getAdd?attributeName=ProfileFiledGroup';
    console.log(dialogFormUrl);
    this.clientDataService.setUrl(dialogFormUrl);
    this.clientDataService.getClientData().subscribe(res => 
      {
        this.addGroupDialogproperties = res.properties; 
        //this.pFieldDialogValue = res.values;
        this.addGroupDialogForm = this.createGroup(this.addGroupDialogproperties);

      });
  }

  create(){
    let formObj=
  {
   "id": 64,
   "groupName": null,
   "groupDesc": null,
   "profileFields": null,
 } 
   formObj.id= 0;
  for(let ctrl in this.addGroupDialogForm.controls){
    if(ctrl== 'groupDesc'){
      formObj.groupDesc=this.addGroupDialogForm.controls[ctrl].value;
    }else if(ctrl== 'groupName'){
      formObj.groupName=this.addGroupDialogForm.controls[ctrl].value;
    }
    else if(ctrl== 'profileFields'){
      formObj.profileFields=null;
    }
  }
   console.log(formObj);
  let postSelectedList=this.appUrl + 'profilefieldGroup';
  this.clientDataService.setUrl(postSelectedList);
  this.clientDataService.PostClientData(formObj).subscribe(res => {
  this.openSnackBar("ProfileField Group has been created succefully");
 
  
  },err =>{
    let errVal = JSON.parse(err._body);
    console.log(errVal.errorMessages);
    this.openSnackBar(errVal.errorMessages);
   }
);
this.dialogRef.close(`${formObj.groupName}`);
// this.dialogRef.close(`${formObj}`)
}

// generic method to handle snackbar
public openSnackBar(msg) {
  this.snackBar.open(msg, 'Close', {
    duration: 5000,
  });
}
//reset the form
reset(){
  this.addGroupDialogForm.reset();
}

checkIfValifForm(){
  if(this.addGroupDialogForm){
    if(!this.addGroupDialogForm.controls['groupName'].value || !this.addGroupDialogForm.controls['groupDesc'].value){
      return true;
    }
  } 
}


}
