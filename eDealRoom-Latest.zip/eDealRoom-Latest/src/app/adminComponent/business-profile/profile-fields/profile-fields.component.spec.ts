import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileFieldsComponent } from './profile-fields.component';

describe('ProfileFieldsComponent', () => {
  let component: ProfileFieldsComponent;
  let fixture: ComponentFixture<ProfileFieldsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileFieldsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileFieldsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
