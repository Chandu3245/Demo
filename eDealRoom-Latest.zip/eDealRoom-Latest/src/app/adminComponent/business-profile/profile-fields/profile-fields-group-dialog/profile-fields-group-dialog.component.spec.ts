import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileFieldsGroupDialogComponent } from './profile-fields-group-dialog.component';

describe('ProfileFieldsDialogComponent', () => {
  let component: ProfileFieldsGroupDialogComponent;
  let fixture: ComponentFixture<ProfileFieldsGroupDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileFieldsGroupDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileFieldsGroupDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
