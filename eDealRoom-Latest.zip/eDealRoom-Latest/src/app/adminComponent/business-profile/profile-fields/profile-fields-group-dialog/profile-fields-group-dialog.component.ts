import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { environment } from '../../../../../environments/environment';
import { ClientDataService } from '../../../../services/app.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-profile-fields-group-dialog',
  templateUrl: './profile-fields-group-dialog.component.html',
  styleUrls: ['./profile-fields-group-dialog.component.scss']
})
export class ProfileFieldsGroupDialogComponent implements OnInit {

  private pFieldDialogValue: any;
  private profileFieldGroup: FormGroup;
  private pFieldDialogForm: any;
  private appUrl: string;
  public selectedId: any;
  constructor(private dialogRef: MatDialogRef<ProfileFieldsGroupDialogComponent>, @Inject(MAT_DIALOG_DATA) private data: any, private clientDataService: ClientDataService, private fb: FormBuilder, private snackBar: MatSnackBar ) { 
    this.appUrl = environment.appURL;
  }

  ngOnInit() {
    this.selectedId = this.data.id;
    console.log(this.selectedId);
    this.getProfileFieldGroupDialogFormFromServer();
    console.log(this.pFieldDialogForm);
  }


// creates form groups
createGroup(formObj) {
  console.log(formObj);
  const group = this.fb.group({});
  formObj.forEach(control => { group.addControl(control.attributeName, this.createControl(control));
  });
  return group;
}
// creates Form controls 
createControl(config) {
  const { isDisabled, validation, value } = config;
  return this.fb.control({'value': value, 'disabled': isDisabled }, validation);
}

  getProfileFieldGroupDialogFormFromServer(){ 
    let dialogFormUrl = this.appUrl + 'profilefieldGroup/getUpdate/'+ JSON.stringify(this.selectedId) +'?attributeName=ProfileFiledGroup';
    console.log(dialogFormUrl);
    this.clientDataService.setUrl(dialogFormUrl);
    this.clientDataService.getClientData().subscribe(res => 
      {
        this.pFieldDialogForm = res.properties; 
        this.pFieldDialogValue = res.values;
        this.profileFieldGroup = this.createGroup(res.properties);
        for(let group of this.pFieldDialogValue){
        this.profileFieldGroup.patchValue({'groupName':group.groupName, 'groupDesc': group.groupDesc});
        }
        this.profileFieldGroup.controls['groupName'].disable();
      });
  }

  getGroupDesc(event){
    console.log(event.target.value);
  }

  update(){
      let formObj=
    {
     "id": 64,
     "groupName": null,
     "groupDesc": null,
     "profileFields": null,
   } 
     formObj.id=this.selectedId;
    for(let ctrl in this.profileFieldGroup.controls){
      if(ctrl== 'groupDesc'){
        formObj.groupDesc=this.profileFieldGroup.controls[ctrl].value;
      }else if(ctrl== 'groupName'){
        formObj.groupName=this.profileFieldGroup.controls[ctrl].value;
      }
      else if(ctrl== 'profileFields'){
        formObj.profileFields=this.profileFieldGroup.controls[ctrl].value;
      }
    }
     console.log(formObj);
    let postSelectedList=this.appUrl + 'profilefieldGroup/'+JSON.stringify(this.selectedId);
    this.clientDataService.setUrl(postSelectedList);
    this.clientDataService.PutClientData(formObj).subscribe(res => {
    this.openSnackBar("ProfileField Group has been updated succefully");
   
	  
    },err =>{

      let errVal = JSON.parse(err._body);
      console.log(errVal.errorMessages);
      this.openSnackBar(errVal.errorMessages);
     }
  );
  this.dialogRef.close(`${formObj.groupDesc}`);
  // this.dialogRef.close(`${formObj}`)
  }

  delete(){
    let postDeletedList = this.appUrl + 'profilefieldGroup/' + JSON.stringify(this.selectedId);
    this.clientDataService.setUrl(postDeletedList);
    this.clientDataService.deleteClientData().subscribe(res => {
      // this.companyProgressBar=false;
      this.openSnackBar("Selected Group has been deleted successfully");
       },
      err=>{
        console.log(err._body);
        let errVal= JSON.parse(err._body);
        this.openSnackBar(errVal.errorMessages);
      }
     )

  }

  // generic method to handle snackbar
  public openSnackBar(msg) {
    this.snackBar.open(msg, 'Close', {
      duration: 5000,
    });
  }

  checkIfValifForm(){
    if(this.profileFieldGroup){
      if(!this.profileFieldGroup.controls['groupDesc'].value){
        return true;
      }
    } 
  }

}
