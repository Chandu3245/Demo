import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileFieldsDialogComponent } from './profile-fields-dialog.component';

describe('ProfileFieldsDialogComponent', () => {
  let component: ProfileFieldsDialogComponent;
  let fixture: ComponentFixture<ProfileFieldsDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileFieldsDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileFieldsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
