

import { Component, OnInit, Inject } from '@angular/core';
import { ClientDataService } from '../../../../services/app.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-profile-fields-dialog',
  templateUrl: './profile-fields-dialog.component.html',
  styleUrls: ['./profile-fields-dialog.component.scss']
})
export class ProfileFieldsDialogComponent implements OnInit {

  isCharacterSelected: boolean;
  isNumberSelected: boolean;
  private noOfDigits: any;
  private groupObj: any;
  private profileFieldFormGroup: FormGroup;
  private pFieldDialogValue: any;
  private  pFieldDialogForm: any;
  private selectedId: any;
  private appUrl: string;
  constructor(private dialogRef: MatDialogRef<ProfileFieldsDialogComponent>, @Inject(MAT_DIALOG_DATA) private data: any, private clientDataService: ClientDataService, 
  private fb: FormBuilder, private snackBar: MatSnackBar ) {
    this.appUrl = environment.appURL;
   }

  ngOnInit() {
    this.selectedId = this.data.id;
    this.getProfileFieldDialogFormFromServer();
  }

// creates form groups
createGroup(formObj) {
  const group = this.fb.group({});
  formObj.forEach(control => { group.addControl(control.attributeName, this.createControl(control));
  });
  return group;
}
// creates Form controls 
createControl(config) {
  const { isDisabled, validation, value } = config;
  return this.fb.control({'value': value, 'disabled': isDisabled }, validation);
}

///profilefield/findProfileField/{profileFieldId}?attributeName=ProfileFiled 
  getProfileFieldDialogFormFromServer() {
    let dialogFormUrl = this.appUrl + 'profilefield/findProfileField/' + JSON.stringify(this.selectedId) + '?attributeName=ProfileFiled';
    this.clientDataService.setUrl(dialogFormUrl);
    this.clientDataService.getClientData().subscribe(res => {
      this.pFieldDialogForm = res.properties;
      this.pFieldDialogValue = res.values;
      this.profileFieldFormGroup = this.createGroup(res.properties);
      for (let field of this.pFieldDialogValue) {
        this.groupObj = field.profilefiledGroupDTO;
        this.noOfDigits = field.noOfDigits;
        this.profileFieldFormGroup.patchValue({
          'dataType': field.dataType,
          'defaultCaption': field.defaultCaption,
          'fieldDesc': field.fieldDesc,
          'fieldName': field.fieldName,
          'fieldLength': field.fieldLength,
          'profileFiledGroupDTO': field.profilefiledGroupDTO.groupName
        });
        {
          if (field.dataType == "NUMBER") {
            this.isNumberSelected = true;
          } else if (field.dataType == "CHARACTER") {
            this.isCharacterSelected = true;
          } else {
            console.log("not a number nor character");
            this.isNumberSelected = false;
            this.isCharacterSelected = false;
          }
        }
      }
      // this.profileFieldFormGroup.controls['fieldName'].disable();
      Object.keys(this.profileFieldFormGroup.controls).forEach((controlName) => {
        if (controlName != 'fieldDesc' && controlName != 'defaultCaption') {
          this.profileFieldFormGroup.controls[controlName].disable(); // disables each form control based on 'this.formDisabled'
        }
      });
    });
  }

  update(){
    let formObj=
  {
   "id": 64,
   "dataType": null,
   "defaultCaption": null,
   "fieldDesc": null,
   "fieldName": null,
   'fieldLength': 0,
   'noOfDigits': null,
   'profilefiledGroupDTO': null
 } 
   formObj.id=this.selectedId;
  //  console.log(formObj.id);
  for(let ctrl in this.profileFieldFormGroup.controls){
    if(ctrl== 'dataType'){
      formObj.dataType=this.profileFieldFormGroup.controls[ctrl].value;
    }else if(ctrl== 'defaultCaption'){
      formObj.defaultCaption=this.profileFieldFormGroup.controls[ctrl].value;
    }else if(ctrl== 'fieldDesc'){
      formObj.fieldDesc=this.profileFieldFormGroup.controls[ctrl].value;
    }else if(ctrl== 'fieldName'){
      formObj.fieldName=this.profileFieldFormGroup.controls[ctrl].value;
    }else if(ctrl== 'fieldLength'){
      formObj.fieldLength=this.profileFieldFormGroup.controls[ctrl].value;
    }else if(ctrl== 'noOfDigits'){
      formObj.noOfDigits= this.noOfDigits;
    }else {
      formObj.profilefiledGroupDTO=this.groupObj;
    }
  }
  let postSelectedList=this.appUrl + 'profilefield/'+JSON.stringify(this.selectedId);
  this.clientDataService.setUrl(postSelectedList);
  this.clientDataService.PutClientData(formObj).subscribe(res => {
  this.openSnackBar("ProfileField has been updated succefully");
 
  
  },err =>{
    console.log(err._body);
    let errVal = JSON.parse(err._body);
    console.log(errVal.errorMessages);
    this.openSnackBar(errVal.errorMessages);
   }
);
this.dialogRef.close(true);
}

delete(){
  let postDeletedList = this.appUrl + 'profilefield/' + JSON.stringify(this.selectedId);
  this.clientDataService.setUrl(postDeletedList);
  this.clientDataService.deleteClientData().subscribe(res => {
    this.openSnackBar("Selected Profilefield has been deleted successfully");
     },
    err=>{
      let errVal= JSON.parse(err._body);
      this.openSnackBar(errVal.errorMessages);
    }
   );
   this.dialogRef.close(true);

}

// generic method to handle snackbar
public openSnackBar(msg) {
  this.snackBar.open(msg, 'Close', {
    duration: 5000,
  });
}

//
checkIfValifForm(){
  if(this.profileFieldFormGroup){
    if(
        !this.profileFieldFormGroup.controls['defaultCaption'].value ||
        !this.profileFieldFormGroup.controls['fieldDesc'].value 
      ){
      return true;
    }
  } 
}

}
