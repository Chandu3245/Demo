import { Injectable, Inject } from '@angular/core';
import { Observable, BehaviorSubject, Subject } from 'rxjs';

@Injectable()
export class ProfileFieldService{

    private profileGroupIdBSubject = new BehaviorSubject(0);
    private profileGroupsSubject = new Subject();

    
    public setSelectedGroupId(id: any){
        this.profileGroupIdBSubject.next(id);
    }
    public getSelectedGroupId(): Observable<any>{
        return this.profileGroupIdBSubject.asObservable();
    }

    public setAllGroupName(groups: any){
        this.profileGroupsSubject.next(groups);
    }
    public getAllGroupName(): Observable<any>{
        return this.profileGroupsSubject.asObservable();
    }

}