import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProfilefieldDialogComponent } from './add-profilefield-dialog.component';

describe('AddProfilefieldDialogComponent', () => {
  let component: AddProfilefieldDialogComponent;
  let fixture: ComponentFixture<AddProfilefieldDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddProfilefieldDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProfilefieldDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
