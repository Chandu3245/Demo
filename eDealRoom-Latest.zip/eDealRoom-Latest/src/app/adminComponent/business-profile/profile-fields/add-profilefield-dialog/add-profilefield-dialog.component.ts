import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { ClientDataService } from '../../../../services/app.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-add-profilefield-dialog',
  templateUrl: './add-profilefield-dialog.component.html',
  styleUrls: ['./add-profilefield-dialog.component.scss']
})
export class AddProfilefieldDialogComponent implements OnInit {

  isCharacterSelected: boolean;
  isNumberSelected: boolean;
  private selectedId: any;
  private selectedGroup: any;
  private profileGroupValues: any = [];
  private dataTypes: any= [];
  private addProfilefieldValue: any = [];
  private addProfilefieldForm: FormGroup;
  private addProfilefieldProperties: any = [];
  private appUrl: string;
  constructor(private dialogRef: MatDialogRef<AddProfilefieldDialogComponent>, @Inject(MAT_DIALOG_DATA) private data: any, private clientDataService: ClientDataService, 
  private fb: FormBuilder, private snackBar: MatSnackBar ) { 
    this.appUrl = environment.appURL;
  }

  ngOnInit() {
    this.selectedId = this.data.id;
    this.getAddProfileFieldDialogFormFromServer();
    console.log(this.selectedId);
  }

  // creates form groups
createGroup(formObj) {
  const group = this.fb.group({});
  formObj.forEach(control => { group.addControl(control.attributeName, this.createControl(control));
  });
  return group;
}
// creates Form controls 
createControl(config) {
  const { isDisabled, validation, value } = config;
  return this.fb.control({'value': value, 'disabled': isDisabled }, validation);
}

  getAddProfileFieldDialogFormFromServer(){ 
    let dialogFormUrl = this.appUrl + 'profilefield/getAdd?attributeName=ProfileFiled';
    console.log(dialogFormUrl);
    this.clientDataService.setUrl(dialogFormUrl);
    this.clientDataService.getClientData().subscribe(res => 
      {
        this.addProfilefieldProperties = res.properties; 
        this.addProfilefieldForm = this.createGroup(res.properties);
        this.addProfilefieldValue = res.values;
        for(let field of this.addProfilefieldValue){
          this.dataTypes = field.dataType;
          this.profileGroupValues = field.profilefiledGroupDTO;
          if(this.selectedId){
          this.selectDivisionObj();
          }
        }
        console.log(this.profileGroupValues);
       
      });
    }
    //setting Profilefield Group selected
    selectDivisionObj(){
      for(let group of this.profileGroupValues){
        if(this.selectedId == group.id){
          this.selectedGroup = group;
        }
      }
    }

    selectedDivision(list){
      this.selectedId = list.id;
      this.selectDivisionObj();
    }
//Display Length and Digit Decimals formControls - on select of NUMBER or CHARACTER
  dataTypeSelected(list) {
    if (list == "NUMBER") {
      this.isNumberSelected = true;
    } else if (list == "CHARACTER") {
      this.isCharacterSelected = true;
    } else {
      console.log("not a number nor character");
      this.isNumberSelected = false;
      this.isCharacterSelected = false;
    }
  }

    create(){
      let formObj=
      {
       "id": 0,
       "fieldName": null,
       "profilefiledGroupDTO": this.selectedGroup,
       "dataType": null,
       'defaultCaption': null,
       'fieldDesc': null,
       'fieldLength': null,
       'noOfDigits': 2

     } 
       formObj.id= 0;
      for(let ctrl in this.addProfilefieldForm.controls){
        if(ctrl== 'fieldName'){
          formObj.fieldName=this.addProfilefieldForm.controls[ctrl].value;
        } else if(ctrl== 'dataType'){
          formObj.dataType=this.addProfilefieldForm.controls[ctrl].value;
        }else if(ctrl== 'defaultCaption'){
          let val = this.addProfilefieldForm.controls[ctrl].value;
          if(val != undefined){
            formObj.defaultCaption= val;
          }else {
            formObj.defaultCaption = 0;
          }
        }else if(ctrl== 'fieldDesc'){
          formObj.fieldDesc=this.addProfilefieldForm.controls[ctrl].value;
        }else if(ctrl== 'fieldLength'){
          let val = this.addProfilefieldForm.controls[ctrl].value;
          if(val != undefined){
          formObj.fieldLength=val;
          }else {
            formObj.fieldLength = 0;
          }
        }else if(ctrl== 'noOfDigits'){
          let val = this.addProfilefieldForm.controls[ctrl].value;
          if(val != undefined){
            formObj.noOfDigits=val;
          }else {
            formObj.noOfDigits = 0;
          }
        }
      }
       console.log(formObj);
      let postSelectedList=this.appUrl + 'profilefield';
      this.clientDataService.setUrl(postSelectedList);
      this.clientDataService.PostClientData(formObj).subscribe(res => {
      this.openSnackBar("Profilefield  has been created succefully");
      
      },err =>{
        console.log(err._body);
        let errVal = JSON.parse(err._body);
        console.log(errVal.errorMessages);
        this.openSnackBar(errVal.errorMessages);
       }
    );
    this.dialogRef.close(`${formObj.fieldName}`);
    // this.dialogRef.close(`${formObj}`)
    }
    
    // generic method to handle snackbar
    public openSnackBar(msg) {
      this.snackBar.open(msg, 'Close', {
        duration: 5000,
      });
    }

    reset(){
      this.addProfilefieldForm.reset();
    }

    checkIfValifForm(){
      if(this.addProfilefieldForm){
        if( !this.addProfilefieldForm.controls['fieldName'].value || 
            !this.addProfilefieldForm.controls['dataType'].value ||
            !this.addProfilefieldForm.controls['fieldDesc'].value 
            // !this.addProfilefieldForm.controls['fieldLength'].value ||
            // !this.addProfilefieldForm.controls['noOfDigits'].value 
          ){
          return true;
        }
      } 
    }
}
