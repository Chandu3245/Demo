
import { environment } from '../../../environments/environment';

import { Component, OnInit, Inject,ViewChild,ElementRef, EventEmitter, Output, Input } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { ClientDataService } from '../../services/app.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-business-profile',
  templateUrl: './business-profile.component.html',
  styleUrls: ['./business-profile.component.scss']
})
export class BusinessProfileComponent implements OnInit {
  selectedDivision: any;
  @ViewChild('stepper')stepper :ElementRef;
  private formGroupList: Array<FormGroup> = [];
  private listOfSection:any=[]
  private availCompanyList = [];
  filteredOptions: Observable<string[]>;
  private myControl: FormControl = new FormControl();
  private compId: any;
  private initiateLookup:boolean=false;
  private appUrl: any;
  
constructor( @Inject(ClientDataService) private clientDataService: ClientDataService,
                     @Inject(FormBuilder) private fb: FormBuilder, private router:Router) {
                      this.appUrl = environment.appURL;
                     }
  ngOnInit() {
    this.getBusinessProfileByServer();
 
  }

  filter(val: String) {
    return val ? this.availCompanyList.filter(option => option.name.toLowerCase().indexOf(val.toLowerCase()) === 0) : this.availCompanyList;
  }

//creates formGroups from the server Json
  createGroup(formObj) {
    const group = this.fb.group({});
    formObj.attributeList.forEach(control => {
        group.addControl(control.attributeName, this.createControl(control));
    
    });
    for (let grp of formObj.attributeGroupList) {
      for (let subGrp of grp.subAttributes) {
        subGrp.attributes.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
      }
    }
    return group;
  }
  // creates Form controls 
  createControl(config) {
    const { isDisabled, validation, value } = config;
    return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  } 

    //creates businessProfile Form with Json from server
  getBusinessProfileByServer() {
    let self = this;
    let createNewForm = this.appUrl + 'companies/businessProfile';
    console.log(createNewForm);
    this.clientDataService.setUrl(createNewForm);
    this.clientDataService.getClientData().subscribe(res => {
      console.log(res);
      this.listOfSection=res.attributes
      console.log(this.listOfSection);
      for (let data of res.attributes) {
        this.formGroupList.push(this.createGroup(data));
      }
      for (let value of res.values) {
        this.availCompanyList.push(value);
      }
    });

  }
  // navigates to seleted Name.
   public changeRoute(routeName,sideNavRef){
    this.router.navigateByUrl(routeName);
  }

  //reset the changes to default
  reset(){
    for(let formInst of this.formGroupList){
      formInst.reset();
    }
  }
//selected division from Business Profile page
  getSelectedDivision(division){
    this.selectedDivision = division.id;
    this.formGroupList[0].patchValue({'marketName':division.marketName, 'internalInd': division.internalInd, 'activeInd': division.activeInd});
  }
}
