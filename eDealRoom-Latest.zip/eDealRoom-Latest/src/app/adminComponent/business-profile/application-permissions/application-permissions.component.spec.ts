import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationPermissionsComponent } from './application-permissions.component';

describe('ApplicationPermissionsComponent', () => {
  let component: ApplicationPermissionsComponent;
  let fixture: ComponentFixture<ApplicationPermissionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationPermissionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationPermissionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
