

import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-application-permissions',
  templateUrl: './application-permissions.component.html',
  styleUrls: ['./application-permissions.component.scss']
})
export class ApplicationPermissionsComponent implements OnInit {

  constructor(private location: Location) { }

  ngOnInit() {
  }

  goBack(){
    this.location.back();
  }

}
