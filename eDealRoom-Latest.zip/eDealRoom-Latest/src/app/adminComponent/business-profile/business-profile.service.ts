import { Injectable, Inject } from '@angular/core';
import { Observable, BehaviorSubject, Subject } from 'rxjs';

@Injectable()
export class BusinessProfileService{

    private businessProfileIdBSubject = new BehaviorSubject(0);
    
    public setSelectedDivisionId(id: any){
        this.businessProfileIdBSubject.next(id);
    }
    public getSelectedDivisionId(): Observable<any>{
        return this.businessProfileIdBSubject.asObservable();
    }

}