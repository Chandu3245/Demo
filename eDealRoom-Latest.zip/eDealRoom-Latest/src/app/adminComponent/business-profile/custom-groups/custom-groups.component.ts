

import { Component, OnInit } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatTableModule } from '@angular/material';
import { DataSource } from '@angular/cdk/collections'
import { Observable, BehaviorSubject } from 'rxjs';
import { ClientDataService } from '../../../services/app.service';
import { Location } from '@angular/common';
import { environment } from '../../../../environments/environment';
import { ActivatedRoute } from '@angular/router';
import { BusinessProfileService } from '../business-profile.service';

@Component({
  selector: 'app-custom-groups',
  templateUrl: './custom-groups.component.html',
  styleUrls: ['./custom-groups.component.scss']
})
export class CustomGroupsComponent implements OnInit {
  
  divisionId: number;
  private displayedColumns2 = ['teamName', 'teamDesc', 'defaultInd'];
  dataSource2:CustomGroupsDataSource;
  constructor(private clientDataService: ClientDataService, private location: Location, private businessProfileService: BusinessProfileService, private route: ActivatedRoute) { 
  }

  ngOnInit() {
    this.dataSource2 = new CustomGroupsDataSource(this.clientDataService, this.businessProfileService);
    this.dataSource2.getMyCustomGroupsByServer();
    this.divisionIdFromBusinessProfile();
  }

//go back to last viewed page
  goBack(){
    this.location.back();
  }
    //get division id from routerLink using ActivatedRoute
    divisionIdFromBusinessProfile(): void{
      this.divisionId = +this.route.snapshot.paramMap.get('selectedDivision');
      // console.log(this.divisionId);
      this.businessProfileService.setSelectedDivisionId(this.divisionId);
    }

}

//data model for table display
export interface CustomGroupValues {
  teamName: string;
  id: number;
  teamDesc: string;
  defaultInd: boolean;
  teamMembers: string;
  inactiveInd: boolean;
}


//dataSource Implementation to fetch CustomGroups data from Server
export class CustomGroupsDataSource implements DataSource<CustomGroupValues> {

  private appUrl: any;
  divisionId: any;
  private customGroupSubject: BehaviorSubject<CustomGroupValues[]> = new BehaviorSubject<CustomGroupValues[]>([]);

  constructor(private clientDataService, private businessProfileService) {
    this.appUrl = environment.appURL;
  }
//makes data fetched available to table
  connect(): Observable<CustomGroupValues[]> {
      return this.customGroupSubject.asObservable();
  }

// called once by the data table at component destruction time, in order to avoid memory leaks
  disconnect(): void {
      this.customGroupSubject.complete();
  }

  //fetch data from backend and returns an observable
  getMyCustomGroupsByServer() {
    this.businessProfileService.getSelectedDivisionId().subscribe(id => {
      this.divisionId = id;
      console.log(this.divisionId);
      if(this.divisionId){
      let customGroupUrl = this.appUrl + 'dea/teams/teamProfile/'+JSON.stringify(this.divisionId) +'?attributeName=Custom Groups';
      console.log(customGroupUrl );
      this.clientDataService.setUrl(customGroupUrl);
      return this.clientDataService.getClientData().subscribe(
        customGroups => {this.customGroupSubject.next(customGroups.values); console.log(customGroups.values);}
      );
    }
    });
  }

}