

import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { MatDialog, MatSnackBar, MatPaginator, MatTableDataSource, MatTableModule } from '@angular/material';
import { DataSource } from '@angular/cdk/collections'
import { Observable, BehaviorSubject } from 'rxjs';
import { ClientDataService } from '../../../services/app.service';
import { environment } from '../../../../environments/environment';
import { ActivatedRoute } from '@angular/router';
import { BusinessProfileService } from '../business-profile.service';


@Component({
  selector: 'app-business-hierarchy',
  templateUrl: './business-hierarchy.component.html',
  styleUrls: ['./business-hierarchy.component.scss']
})
export class BusinessHierarchyComponent implements OnInit {

  divisionId: number;
  displayedColumns = ['name', 'marketName', 'internalInd'];
  dataSource: BusinessHierarchyDataSource;

  constructor(private location: Location, private clientDataService: ClientDataService, private businessProfileService: BusinessProfileService, private route: ActivatedRoute) { }

  ngOnInit() {

    this.dataSource = new BusinessHierarchyDataSource(this.clientDataService, this.businessProfileService);
    this.dataSource.getMyBusinessHierarchyByServer();
    this.divisionIdFromBusinessProfile();
  }

//go back to last viewed page
  goBack(){
    this.location.back();
  }
//get division id from routerLink using ActivatedRoute
 divisionIdFromBusinessProfile(): void{
        this.divisionId = +this.route.snapshot.paramMap.get('selectedDivision');
        this.businessProfileService.setSelectedDivisionId(this.divisionId);
 }

}

//data model for table display
export interface BusinessHierarchyValues {
  id: number;creationUser: string;creationDate: Date;lastModifiedUser: string;lastModifiedDate: Date;
  activeInd: boolean;subDivisions: string; businessTeams: string;users: string;parentCompany: string;
  name: string;
  marketName: string;
  internalInd: boolean;
}

//dataSource Implementation to fetch Business Hierarchy data from Server
export class BusinessHierarchyDataSource implements DataSource<BusinessHierarchyValues> {

  private divisionId: any;
  private businessHierarchyValues: any = [];
  constructor(private clientDataService: ClientDataService, private businessProfileService){
    this.appUrl = environment.appURL;
  }
  private appUrl: any;
  private businessHierarchySubject: BehaviorSubject<BusinessHierarchyValues[]> = new BehaviorSubject<BusinessHierarchyValues[]>([]);
//makes data fetched available to table
  connect(): Observable<BusinessHierarchyValues[]> {
    return this.businessHierarchySubject.asObservable();
}
// called once by the data table at component destruction time, in order to avoid memory leaks
disconnect(): void{
  this.businessHierarchySubject.complete();
}

  //fetch data from backend and returns an observable
  getMyBusinessHierarchyByServer() {
    this.businessProfileService.getSelectedDivisionId().subscribe(id => {
      this.divisionId = id;
      if (this.divisionId) {
        let businessHierarchyUrl = this.appUrl + 'companies/hierarchy/'+ JSON.stringify(this.divisionId) + '?name=Business Hierarchy';
        this.clientDataService.setUrl(businessHierarchyUrl);
        return this.clientDataService.getClientData().subscribe(
          businessHierarchy => {
            for(let subDiv of businessHierarchy.values){
              this.businessHierarchyValues.push({'name':subDiv.name,'marketName': subDiv.marketName, 'internalInd': subDiv.internalInd});
              for(let value of subDiv.subDivisions){
                let valueName = '    '+value.name;
                this.businessHierarchyValues.push({'name': valueName,'marketName': value.marketName, 'internalInd': value.internalInd});
              }
            }
            this.businessHierarchySubject.next(this.businessHierarchyValues);
            this.businessHierarchyValues = [];
          });
        
      }
    });
  }

}