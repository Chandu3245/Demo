
import { Component, OnInit,OnChanges, Input, Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { environment } from './../../../environments/environment';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ClientDataService } from '../../services/app.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {
  private userProfileForm=[];
  private selectedListAvailUser:any;
  private deleteOperation=false;
  private companyNames=[];
  private userAvailableList:any=[];
  private userInCompany:any=[];
  private userAvailListBoolean:boolean=false;
  private selectedListAvailCompany:any;
  private userProfileFormBoolean:boolean=false;
  private userId:any;
  private companyLookUp:boolean=false;
  private userLookUp:boolean=false;
  private userValueChange:boolean=false;
  private compId:any;
  private selectedListObj:any;  
  private disableDelete:boolean=true;
  private defaultUserProfileFormBoolean:boolean=false;
  private appUrl: any;
  private errorCode:any;
  companyControl: FormControl = new FormControl();
  filteredOptions: Observable<string[]>;
  userControl: FormControl = new FormControl();
  filteredUsers: Observable<string[]>;
  private  companyProgressBar: boolean = false;
  constructor( @Inject(ClientDataService) private clientDataService: ClientDataService,
                      @Inject(MatSnackBar) public snackBar: MatSnackBar,) {
    this.appUrl = environment.appURL;
    this.getCompanyListFromServer();
   }
  ngOnInit() {
    this.filteredOptions = this.companyControl.valueChanges.pipe(
      startWith(''),
      map(val => this.filter(val))
    );
    this.filteredUsers = this.userControl.valueChanges.pipe(
      startWith(''),
      map(val => this.filterUser(val))
    );
  }
  filter(val: string): string[] {
    return val ? this.userProfileForm.filter(option => option.toLowerCase().indexOf(val.toLowerCase()) === 0): this.userProfileForm;
  }
  filterUser(val: string): string[] {
    return val ? this.userInCompany.filter(option => option.firstName.toLowerCase().indexOf(val.toLowerCase()) === 0): this.userInCompany;
  }
  //Method to work on the selected company
  companyOptionSelect(event){
      this.companyLookUp=true;
      this.userValueChange=true;
      this.selectedListAvailCompany=event.option.value;
      this.compId=this.companyNames.find(i => i.name === this.selectedListAvailCompany).id;
      this.getAvailUserListByServer();
  }
   //To get list of Companies from server
   getCompanyListFromServer(){
    this.userProfileForm=[];
    this.companyNames=[];
    let getCompanyList = this.appUrl + 'companies/userprofile?name=UserProfile'; 
    this.clientDataService.setUrl(getCompanyList);
    this.clientDataService.getClientData().subscribe(res => {
      this.companyNames=res.values;
      for(let data of res.values){
        this.userProfileForm.push(data.name);
      }
    }
  )
  }
  //To get List of users inside the selected company
    getAvailUserListByServer(){
      let self=this;
      self.userControl.reset();
      self.userInCompany=[];
      let selectedusers=self.appUrl+'companies/'+ JSON.stringify(self.compId) + '/users';
      self.clientDataService.setUrl(selectedusers);
      self.clientDataService.getClientData().subscribe(res => {
        for(let data of res.values){
          self.userInCompany.push(data)
        }
      },
      err=> {
        let errVal=JSON.parse(err._body);
        self.errorCode=errVal.errorMessages;
        self.openSnackBar(errVal.errorMessages);
      }
    )
    }
//Method to work on the selected user
  availUserOptionSelect(event){
    this.userLookUp=true;
    this.userValueChange=true;
    this.defaultUserProfileFormBoolean=true;
    this.selectedListObj=event;
    this.userProfileFormBoolean=true;
    this.selectedListAvailUser=event.option.value;
    let userSelected = this.userInCompany.find(obj => { 
      if(obj.firstName == this.selectedListAvailUser){
        return obj
      }
    });
    this.userId=userSelected.id;
    let postSelectedList = this.appUrl + 'users/' + JSON.stringify(this.userId) + '?name=User';
    this.clientDataService.setUrl(postSelectedList);
      this.clientDataService.getClientData().subscribe(res => {
    this.userAvailableList = res;
    })
}
 
  //events triggered on update and create op in profile form component
  getNewUserListByServer(event){
      this.defaultUserProfileFormBoolean=false;
      this.userProfileFormBoolean=false;
      if(event=='updated'){
      this.userLookUp=false;
      this.userValueChange=true;
      this.getAvailUserListByServer();
      this.userControl.reset();
      }
    if(event=='created'){
      this.getAvailUserListByServer();
      this.userControl.reset();
    }
  }
  //when input is changed after option selected is changed
  onSearchChange(searchValue : string,name ) {  
  if(name=='company'){
    this.userProfileFormBoolean=false;
    this.defaultUserProfileFormBoolean=false;
    this.userLookUp=false;
    this.disableDelete=true;
    this.userValueChange=false;
  }  
  else{
    this.disableDelete=true;
    this.userProfileFormBoolean=false;
    this.defaultUserProfileFormBoolean=false;
    this.userLookUp=false;
    this.userValueChange=true;
  }  
}
//creating new user 
createNewForm() { 
  this.userLookUp=false;
  this.userValueChange=true;
  this.userControl.reset();
  this.defaultUserProfileFormBoolean=true;
	this.userProfileFormBoolean=true;
  let cretaeNewForm = this.appUrl + 'attributegroups/User';
    this.clientDataService.setUrl(cretaeNewForm);
      this.clientDataService.getClientData().subscribe(res => {
      this.userAvailableList = res;
    })
  }
  //deleting a user
  compFormDelete(){
    this.companyProgressBar = true;
    this.userProfileFormBoolean=false;
    this.defaultUserProfileFormBoolean=false;
    this.userLookUp=false;
    this.userControl.reset();
   let self=this;
    let postDeletedList = this.appUrl + 'users/' + JSON.stringify(self.userId);
    this.clientDataService.setUrl(postDeletedList);
    this.clientDataService.deleteClientData().subscribe(res => {
      self.openSnackBar("Selected Company has been deleted successfully");
      this.getAvailUserListByServer();
      this.userControl.reset();
       },
      err=>{
        let errVal= JSON.parse(err._body);
        this.errorCode=errVal.errorMessages;
        self.openSnackBar(errVal.errorMessages);
      }
     )
      this.companyProgressBar = false;
  }
  //generic Method for snackbars
  public openSnackBar(msg){
    this.snackBar.open(msg, 'Close', {
        duration: 5000,
    });
}
//on clearing company input
 companyClear(){
  this.companyLookUp=false;
  this.companyControl.reset();
  this.userProfileFormBoolean=false;
  this.defaultUserProfileFormBoolean=false;
  }
//on clearing user input
 userClear(){
  this.disableDelete=true;
  this.userProfileFormBoolean=false;
  this.defaultUserProfileFormBoolean=false;
  this.userLookUp=false;
  this.userValueChange=true;
  this.userControl.reset();
 }
}
