
import { Component,OnChanges, OnInit, Inject, EventEmitter, Output, Input } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { environment } from './../../../environments/environment';
import { MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { MatDialog } from '@angular/material';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ClientDataService } from '../../services/app.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {
  private profileFormGroup:FormGroup;
  private appUrl: any;
  private userId:any;
  private compId=231;
  private currentUserValues:any;
  private errorCode:any;
  constructor( @Inject(FormBuilder) private fb: FormBuilder, private dialog: MatDialog,
  @Inject(MatSnackBar) public snackBar: MatSnackBar,
  @Inject(ClientDataService) private clientDataService: ClientDataService,private router:Router) {
    this.appUrl = environment.appURL;
    }
  ngOnInit() {
    this.getCurrentUserDetails();
    }
     createGroup(){
       const group=this.fb.group({});
       this.currentUserValues.properties.forEach(control=> group.addControl(control.attributeName,this.createControl(control)));
       return group;
     }
     createControl(config){
       const{isDisabled, validation, value}=config;
       return this.fb.control({'value':value, 'disabled':isDisabled},validation);
     }
     //Method to get specific user details
    getCurrentUserDetails(){
      this.userId=30;
      let currentUser =  this.appUrl + "users/" + JSON.stringify(this.userId) + "?name=User";
      this.clientDataService.setUrl(currentUser);
      this.clientDataService.getClientData().subscribe(res => {
      this.currentUserValues = res;
      if( this.currentUserValues  ){
        this.profileFormGroup = this.createGroup();
        for(let item of this.currentUserValues.properties){
          if(this.currentUserValues.values[0][item.attributeName]){
            this.profileFormGroup.controls[item.attributeName].setValue(this.currentUserValues.values[0][item.attributeName])
          }
        }
    }
     })
    }
    // updating user/company
   update(){
    let formObj=
    {
      "id":this.userId,
      "orgUserId": "",
      "company": {
                      "id": this.compId,
      },
      "firstName": "",
      "lastName": "",
      "emailAddress": "",
   }
    for(let ctrl in this.profileFormGroup.controls)
    {
        if(ctrl== 'firstName'){
          formObj.firstName=this.profileFormGroup.controls[ctrl].value;
        }if(ctrl== 'lastName'){
          formObj.lastName=this.profileFormGroup.controls[ctrl].value;
        }if(ctrl== 'orgUserId'){
          formObj.orgUserId=this.profileFormGroup.controls[ctrl].value;
        }if(ctrl== 'emailAddress'){
          formObj.emailAddress=this.profileFormGroup.controls[ctrl].value;
        }
    }
    let putSelectedList= this.appUrl + "users/" + JSON.stringify(this.userId);
    this.clientDataService.setUrl(putSelectedList);
    this.clientDataService.PutClientData(formObj).subscribe(res => {
      this.openSnackBar("User List has been updated successfully");
      
      this.clientDataService.setRoute(this.router.url,'/dashboard');
      this.router.navigateByUrl('/dashboard');
      }
      ,err =>{
        let errVal = JSON.parse(err._body);
        this.errorCode=errVal.errorMessages;
        this.openSnackBar(errVal.errorMessages);
       }
    );
  }
     myPreferences(){
      // let routeName='/myPreferences'
      // let navItemName = routeName.substr(1, routeName.length);
      // this.router.navigate([routeName,{data:navItemName}]);
      this.clientDataService.setRoute(this.router.url,'/myPreferences');
      this.router.navigateByUrl('/myPreferences');
     }
    cancel(){
      // let routeName='/dashboard'
      // let navItemName = routeName.substr(1, routeName.length);
      // this.router.navigate([routeName,{data:navItemName}]);
      this.clientDataService.setRoute(this.router.url,'/dashboard');
      this.router.navigateByUrl('/dashboard');
    }
    public openSnackBar(msg){
      this.snackBar.open(msg, 'Close', {
          duration: 5000,
      });
  }
  checkIfFormValid(){
    if(this.profileFormGroup){
      if(!this.profileFormGroup.controls['firstName'].value || 
      !this.profileFormGroup.controls['lastName'].value || 
      !this.profileFormGroup.controls['emailAddress'].value || 
      !this.profileFormGroup.controls['orgUserId'].value){
        return true;
      }
    }
  }
  }