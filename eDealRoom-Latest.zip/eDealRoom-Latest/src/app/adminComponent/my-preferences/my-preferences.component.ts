import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClientDataService } from '../../services/app.service';
import { MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { environment } from './../../../environments/environment';
@Component({
  selector: 'app-my-preferences',
  templateUrl: './my-preferences.component.html',
  styleUrls: ['./my-preferences.component.scss']
})
export class MyPreferencesComponent {
  private notificationFormGroup: FormGroup;
  private prefSectionName: any = [];
  private listOfSection: any = []
  private listOfObjForForm: any = [];
  private listOfValues: any = [];
  private formGroupList: Array<FormGroup> = [];
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  private errorCode: any;
  private appUrl: any;
  private myPreferencesProgressBar: boolean = false;
  private noOfDaysForNotice: any = ["1", "2", "3", "4", "5", "6", "7", "10", "14", "30"];
  private noOfEveryDaysForNotice: any = ["every day", "every other day", "every week", "every 2 weeks"];
  private daysSelected:any=this.noOfDaysForNotice[1];
  private everyDaysSelected:any=this.noOfEveryDaysForNotice[0];
  
  constructor( @Inject(FormBuilder) private fb: FormBuilder,
    @Inject(ClientDataService) private clientDataService: ClientDataService,
    @Inject(MatSnackBar) public snackBar: MatSnackBar) {
    this.appUrl = environment.appURL;
  }
  ngOnInit() {
    this.getMyPreferencesByServer();
    // for(let item of this.listOfSection[0]attributeList){
    //   if(this.formObj.values[0][item.attributeName]){
    //     this.profileFormGroup.controls[item.attributeName].setValue(this.formObj.values[0][item.attributeName])
    //   }
    // }

  }
  //Method to get my preferences Data form server on page load
  getMyPreferencesByServer() {
    let self = this;
    this.formGroupList = [];
    this.listOfObjForForm = [];
    // this.clientDataService.setUrl("../../assets/myPreferences.json");
    let getClientUrl = this.appUrl + "users/22/preference?name=UserPreferences";
    this.clientDataService.setUrl(getClientUrl);
    this.clientDataService.getClientData().subscribe(res => {
      self.listOfSection = res.sections

      self.listOfValues = res.values
      console.log(self.listOfValues)
      for (let data of res.sections) {
        self.listOfObjForForm.push(data.attributeList);
        for (let attrGrp of data.attributeGroupList) {
          self.listOfObjForForm.push(attrGrp.attributes);
        }
        self.formGroupList.push(self.createGroup(data));
      }

      console.log(self.formGroupList)
      this.myPreferencesProgressBar = true;
      let valueArray;
      // for(let value in self.listOfValues){
      // valueArray.push(value);
      // }
      let i;
      // for(let item of self.listOfSection){
      //   i++;
      //   for(let attrlist of item.attributeList){

      //     for(let data in self.listOfValues){
      //     if (attrlist.attributeName == data){
      //       for(let i=0; i<= self.formGroupList.length;i++){
      //         // if(){
      //       self.formGroupList[i].controls[attrlist.attributeName].setValue(self.listOfValues[attrlist.attributeName])
      //       console.log(self.listOfValues[attrlist.attributeName])
      //         // }
      //       }
      //     }
      //   }
      //   }
      // }
      for (let attrlist of self.formGroupList) {
        for (let formData in attrlist.controls) {
          for (let data in self.listOfValues) {
            if (data == formData) {
              attrlist.controls[formData].setValue(self.listOfValues[formData]);
              console.log(self.listOfValues[formData])
              console.log(formData);
              console.log(attrlist.controls[formData]);
            }
          }
        }
      }
    }, err => {
      this.myPreferencesProgressBar = true;
    }
    )

  }
  //Method to Create Groups for Array of Object 
  createGroup(formObj) {
    const group = this.fb.group({});
    formObj.attributeList.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
    for (let grp of formObj.attributeGroupList) {
      grp.attributes.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
    }
    return group;
  }
  createControl(config) {
    const { isDisabled, validation, value } = config;
    return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  }
  //Method to Update My preferences data on server on click of Update button
  public updateMyPreferences() {
    let self = this;
    this.myPreferencesProgressBar = false;
    let formObj = {
      "id": 22,
      "user": {
        "id": 22,
        "orgUserId": "10"
      },
      "taskNotifyByMail": true,
      "taskOverdue": true,
      "taskReassigned": true,
      "taskDuedateChanged": true,
      "taskCompleted": true,
      "taskRemaindMyTasks": true,
      "taskNotifyBeforeNoDays": 0,
      "taskFollowupFrequency": 0,
      "alertNotifyByMail": false,
      "discussionNotifyByMail": false,
      "documentNotifyByMail": false
    }
    for (let group of this.formGroupList) {
      for (let grp in group.controls) {
        if (grp == "taskNotifyByMail") {
          formObj.taskNotifyByMail = false//group.controls[grp].value;
        }
        if (grp == "taskOverdue") {
          formObj.taskOverdue = group.controls[grp].value;
        }
        if (grp == "taskReassigned") {
          formObj.taskReassigned = group.controls[grp].value;
        }
        if (grp == "taskDuedateChanged") {
          formObj.taskDuedateChanged = group.controls[grp].value;
        }
        if (grp == "taskCompleted") {
          formObj.taskCompleted = group.controls[grp].value;
        }
        if (grp == "taskRemaindMyTasks") {
          formObj.taskRemaindMyTasks = group.controls[grp].value;
        }
        // if(grp=="taskNotifyBeforeNoDays"){
        //   formObj.taskNotifyBeforeNoDays=group.controls[grp].value;
        // }
        // if(grp=="taskFollowupFrequency"){
        //   formObj.taskFollowupFrequency=group.controls[grp].value;
        // }
        if (grp == "alertNotifyByMail") {
          formObj.alertNotifyByMail = false//group.controls[grp].value;
        }
        if (grp == "discussionNotifyByMail") {
          formObj.discussionNotifyByMail = false//group.controls[grp].value;
        }
        if (grp == "documentNotifyByMail") {
          formObj.documentNotifyByMail = false//group.controls[grp].value;
        }

      }
    }
    let postClientUrl = this.appUrl + "users/22/preferences/22";
    this.clientDataService.setUrl(postClientUrl);
    this.clientDataService.PutClientData(formObj).subscribe(res => {
      self.myPreferencesProgressBar = true;
      self.openSnackBar("Updated Successfully");
      self.getMyPreferencesByServer();
    }, err => {
      let errVal = JSON.parse(err._body);
      this.errorCode = errVal.errorMessages;
      self.myPreferencesProgressBar = true;
      self.openSnackBar(errVal.errorMessages);
    }
    );
  }
  // generic method to handle snackbar
  public openSnackBar(msg) {
    this.snackBar.open(msg, 'Close', {
      duration: 5000,
    });
  }
}
