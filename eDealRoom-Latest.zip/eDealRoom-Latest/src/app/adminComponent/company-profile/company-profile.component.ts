import { environment } from './../../../environments/environment';
import { MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import {
  Component, OnInit, Input, Inject, ViewChild,
  AfterViewInit
} from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { ClientDataService } from '../../services/app.service';
@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.component.html',
  styleUrls: ['./company-profile.component.scss']
})
export class CompanyProfileComponent implements OnInit {
  private availCompanyList = [];
  private deleteOperation = false;
  private companyProfileForm: any;
  private userButtonEnableBoolean: boolean = false;
  private userProfileFormBoolean: boolean = false;
  private defaultUserProfileFormBoolean: boolean = false;
  private appUrl: any;
  private compId: any;
  private selectedListObj: any;
  private saveObject: any;
  private companyProgressBar: boolean = false;
  private errorCode: any;
  private disableInternalCheckBox: boolean = true;
  constructor( @Inject(ClientDataService) private clientDataService: ClientDataService,
    @Inject(MatSnackBar) public snackBar: MatSnackBar,) {
    this.appUrl = environment.appURL;
  }
  ngOnInit() {
    this.getAvailCompanyListByServer();
  }
  inputEmptyCheck(event) { }
 
  //Method to hit url to get ID from selected company in drpdown and create profile form
  public getSelectedListAvailUser(event) {
    let self = this;
    this.selectedListObj = event;
    this.userButtonEnableBoolean = true;
    this.userProfileFormBoolean = true;
    this.defaultUserProfileFormBoolean = true;
    if (this.deleteOperation) {
      this.deleteOperation = !this.deleteOperation
    }
    this.compId = event.id;
    let postSelectedList = this.appUrl + 'companies/' + JSON.stringify(this.compId) + '?name=Company';
    this.clientDataService.setUrl(postSelectedList);
    this.clientDataService.getClientData().subscribe(res => {
      this.companyProfileForm = res;
    }, err => {
      let errVal = JSON.parse(err._body);
      this.errorCode = errVal.errorMessages;
    })
  }
   //Method to get available company in DropDown on page load
   public getAvailCompanyListByServer() {
    this.availCompanyList = [];
    let listUrl = this.appUrl + 'companies';
    this.clientDataService.setUrl(listUrl);
    this.clientDataService.getClientData().subscribe(res => {
      for (let data of res.values) {
        this.availCompanyList.push(data)  
      }
      
    })
  }
  //Output event to update company dropdow on profile Update button click
  public getUpdateCompanyList() {
    this.getAvailCompanyListByServer()
  }
  //Output event to update company dropdow on profile SAVE button click
  public getCreateCompanyList() {
    this.getAvailCompanyListByServer()
  }
  //Outpur event to update company dropdown and clear input field value and hnding form on create button click
  public getNewUserListByServerEvent(event) {
    this.defaultUserProfileFormBoolean = false;
    this.userProfileFormBoolean = false;
    if (event == 'updated') {
      if (this.selectedListObj) {
        this.deleteOperation = !this.deleteOperation
      }
    }
    else if (event == 'created') { }

  }
  //Method to delete slected company form dropdown on dellete button.
  compFormDelete() {
    this.companyProgressBar = true;
    this.userButtonEnableBoolean = false;
    this.userProfileFormBoolean = false;
    this.defaultUserProfileFormBoolean = false;
    if (this.selectedListObj) {
      this.deleteOperation = !this.deleteOperation
    }
    let self = this;
    let compId = this.selectedListObj.id;
    let postDeletedList = this.appUrl + 'companies/' + JSON.stringify(compId);
    this.clientDataService.setUrl(postDeletedList);
    this.clientDataService.deleteClientData().subscribe(res => {
      this.getAvailCompanyListByServer();
      this.companyProgressBar = false;
      self.openSnackBar("Selected Company has been deleted successfully");
    }, err => {
      let errVal = JSON.parse(err._body);
      this.errorCode = errVal.errorMessages;
      self.openSnackBar(errVal.errorMessages);
    }

    )
  }
  //Create New Profile form on Create button
  createNewForm() {
    this.userButtonEnableBoolean = false;
    if (this.selectedListObj) {
      this.deleteOperation = !this.deleteOperation
    }
    this.defaultUserProfileFormBoolean = true;
    this.userProfileFormBoolean = true;
    let cretaeNewForm = this.appUrl + 'attributegroups/Company';
    this.clientDataService.setUrl(cretaeNewForm);
    this.clientDataService.getClientData().subscribe(res => {
      this.companyProfileForm = res;
    })
  }
  submit() { }
  // generic method to handle snackbar
  public openSnackBar(msg) {
    this.snackBar.open(msg, 'Close', {
      duration: 5000,
    });
  }
  //methos to stop companyProgressBar
  public stopProgressEventParent(event) {
    this.companyProgressBar = event;
  }
  //Output Method to clear Input Field and hinding profileform on update click
  public getOnSearchInputChange() {
    this.userProfileFormBoolean = false;
    this.defaultUserProfileFormBoolean = false;
    this.userButtonEnableBoolean = false;
  }
  public setDisableDelete(){
    this.userButtonEnableBoolean = false;
  }
}

