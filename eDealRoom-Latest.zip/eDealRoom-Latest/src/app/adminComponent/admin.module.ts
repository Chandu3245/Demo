import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule, ANALYZE_FOR_ENTRY_COMPONENTS } from '@angular/core';
import { MyMaterialModule } from '../material.module';
import { routing } from './admin-routing';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { AdminComponent } from "./admin.component";
import { UserProfileComponent } from './user-profile/user-profile.component';
import { CompanyProfileComponent } from './company-profile/company-profile.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyPreferencesComponent } from './my-preferences/my-preferences.component';
import { BusinessProfileComponent } from './business-profile/business-profile.component';
import { ClientDataService } from '../services/app.service';
// import { SearchProfileComponent } from '../search-profile/search-profile.component';
// import { ProfileFormComponent } from '../profile-form/profile-form.component';


@NgModule({
    declarations:[AdminComponent,],// MyProfileComponent, MyPreferencesComponent, BusinessProfileComponen, UserProfileComponent, CompanyProfileComponent,SearchProfileComponent,ProfileFormComponent],
    imports:[CommonModule,FormsModule,ReactiveFormsModule,
        MyMaterialModule,
        routing,
        DragDropDirectiveModule,
        ],
        providers:  [ ClientDataService],
    exports:[AdminComponent] //components that are defined in this module but might be used in other modules are included here,
    
})
export class AdminModule{

}