import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
@Component({
  selector: 'app-search-profile',
  templateUrl: './search-profile.component.html',
  styleUrls: ['./search-profile.component.scss']
})
export class SearchProfileComponent implements OnInit {
  @Input() listObj;
  @Input() deleteOperation: boolean;
  @Output() selectedListAvailUserEvent: EventEmitter<any> = new EventEmitter();
  @Output() onSearchInputChange: EventEmitter<any> = new EventEmitter();
  @Output() clearInputValue: EventEmitter<any> = new EventEmitter();
  private selectedListAvailUser: any;
  private companySearchValue: any;
  myControl: FormControl = new FormControl();
  filteredOptions: Observable<string[]>;
 constructor(){}
  ngOnInit() {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(val => this.filter(val))
    );
  }
  ngOnChanges() {
    if (this.deleteOperation || this.listObj) {
      this.myControl.reset();
    }
  }
  //Filter method to make array of company dropdown list
  filter(val: string): string[] {
    return val ? this.listObj.filter(option => option.name.toLowerCase().indexOf(val.toLowerCase()) === 0) : this.listObj;
  }

  //Method to select company from avail dropdown list on optionSelected and emitting event to company profile.
  availUserOptionSelect(event) {
    let self = this;
    this.selectedListAvailUser = event.option.value;
    let companySelected = this.listObj.find(obj => {
      if (obj.name == this.selectedListAvailUser) {
        return obj
      }
    });
    this.selectedListAvailUserEvent.emit(companySelected);
  }
  // Method for fetching input value changed and emitting event to compnay profile
  onSearchChange(searchValue: string) {
    this.companySearchValue = searchValue;
    this.onSearchInputChange.emit(searchValue);
  }
  // method for clearing entered Attribute list on Close icon click
  public clearForm(ctrl) {
    ctrl.setValue("");
    this.onSearchInputChange.emit();
  }
}
