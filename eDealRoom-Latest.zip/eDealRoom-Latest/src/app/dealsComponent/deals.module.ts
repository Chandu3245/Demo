
import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MyMaterialModule } from '../material.module';
import { routing } from './deals-routing';
import { DealsComponent } from "./deals.component";
import { CreateDealComponent } from './create-deal/create-deal.component';


@NgModule({
    declarations:[DealsComponent],
    imports:[CommonModule,
        MyMaterialModule,
        routing,
        DragDropDirectiveModule,
        ],
    exports:[DealsComponent] //components that are defined in this module but might be used in other modules are included here
})
export class DealsModule{

}