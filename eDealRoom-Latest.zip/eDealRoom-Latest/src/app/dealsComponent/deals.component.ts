
import { Component,OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'deals-comp',
  templateUrl: './deals.component.html',
  styleUrls: ['./deals.component.scss']
})
export class DealsComponent implements OnInit {
  ngOnInit(){
  }

}
