

import { environment } from '../../../environments/environment';

import { Component, OnInit, ViewChild, AfterViewInit, Inject, ElementRef  } from '@angular/core';
import { Location } from '@angular/common';
import { ClientDataService } from '../../services/app.service';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, AbstractControl } from '@angular/forms';
import { MatDialog, MatSnackBar } from '@angular/material';
import { CreateCompanyComponent } from '../../create-company/create-company.component';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-create-deal',
  templateUrl: './create-deal.component.html',
  styleUrls: ['./create-deal.component.scss']
})
export class CreateDealComponent implements OnInit {


  companyName: Observable<any>;
  isSearchTypeContains: boolean = true;
  disableSearchButton: boolean = true;
  private listOfCompanyValues: any[];
  private listOfDivisionValues: any;
  private listOfDealTypeValues: any;
  private listOfTaskValues: any;
  private listOfLibraryValues: any;
  private formGroupList: Array<FormGroup> = [];
  private listofGroups: any = [];
  private listOfSections: any = [];
  private availCompanyList = [];
  private searchTypes: any = [
    {
      searchType: 'BEGINSWITH',
      checked: false
    },
    {
      searchType: 'CONTAINS',
      checked: true
    }
  ];
  private appUrl: any;
  private companyId: any;
  private divisionId: any;
  private libraryTemId: any;
  private taskTemId: any;
  private searchTerm: string;
  private searchTypeName: string;
  private searchTypeDefault: boolean = true;
  private divisionSelected: any;
  private companySelected: any;
  private libTemSelected: any;
  private taskTemSelected: any;
  private companyNameCreated: any;
  private closeDialogAfterCreation: boolean;
  constructor(private location: Location, private clientDataService: ClientDataService, private fb: FormBuilder,
    private dialog: MatDialog, private route: Router, @Inject(MatSnackBar) public snackBar: MatSnackBar) {
    this.appUrl = environment.appURL;
  }

  ngOnInit() {
    this.getCreateDealFormByServer();
  }
  //to create formGroup from the server Json
  createGroup(formObj) {
    const group = this.fb.group({});
    formObj.attributeGroupList.forEach(control => {
      group.addControl(control.attributeGroupName, this.createControl(control));
    });
    for (let grp of formObj.attributeGroupList) {
      for (let subGrp of grp.subAttributes) {
        subGrp.attributes.forEach(control => {
          group.addControl(control.attributeName, this.createControl(control));
        });
        this.listofGroups.push(subGrp.attributeGroupName);
      }
    }
    return group;
  }
  //to create Form controls 
  createControl(config) {
    const { isDisabled, value } = config;
    if (config.attributeName == 'search') {

      let control = this.fb.control({ 'value': value, 'disabled': this.disableSearchButton });
      let attributeName = config.attributeName;
      let self = this;
      control.valueChanges.subscribe(res => {
        self.controlChanged(control, attributeName);
      });
      return control;
    } else if (config.attributeName == 'searchCompany') {

      let control = this.fb.control({ 'value': value, 'disabled': isDisabled });
      let attributeName = config.attributeName;
      let self = this;
      control.valueChanges.subscribe(res => {
        self.controlChanged(control, attributeName);
      });
      return control;
    } else if (config.attributeName == 'dealName') {
      // let dealNamePattern=/^[a-zA-Z]+[a-zA-Z0-9]*$/;
      let validation = [this.regexValidator(new RegExp('^[a-zA-Z]+[a-zA-Z0-9]*$'), {'number': true}), Validators.maxLength(75)];
      let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
      let attributeName = config.attributeName;
      let self = this;
      control.valueChanges.subscribe(res => {
        self.controlChanged(control, attributeName);
      });
      return control;
    }else {
      let validation;
      let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
      let attributeName = config.attributeName;
      let self = this;
      control.valueChanges.subscribe(res => {
        self.controlChanged(control, attributeName);
      });

      return control;
    }
  }

  public controlChanged(ctrl, nameOfAttribute) {
    if (nameOfAttribute == 'searchCompany') {
      if (this.searchTypeName == 'beginsWith') {
        if (ctrl.value.length < 1 || ctrl.value.length == '') {
          this.disableSearchButton = true;
        } else {
          this.disableSearchButton = false;
        }
      } else if (this.searchTypeName != 'beginsWith') {
        if (ctrl.value.length <= 2) {
          ctrl.setErrors({ 'length': true });
          this.disableSearchButton = true;
        } else {
          this.disableSearchButton = false;
        }
      }
    }
  }

  regexValidator(regex: RegExp, error: ValidationErrors): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      return valid ? null : error;
    };
  }

  //createDeral Form with Json from server
  getCreateDealFormByServer() {
    let self = this;
    let listUrl = this.appUrl + '/deals/getCreateDeal?attributeName=CreateDeal';
    this.clientDataService.setUrl(listUrl);
    this.clientDataService.getClientData().subscribe(res => {
      self.listOfSections = res.sections;
      for (let data of res.sections) {
        self.formGroupList.push(self.createGroup(data));
      }
      this.listofGroups = res.values;
    });
  }

  //values to division, dealtype, task and library ListBoxes from Server
  private selectValues(event) {

    if (event.currentTarget.textContent == "Division") {
      let values: any = [];
      values = this.listofGroups;
      for (let val of values) {
        this.listOfDivisionValues = val.division;
      }

    }
    if (event.currentTarget.textContent == "Deal Type") {
      let values: any = [];
      values = this.listofGroups;
      for (let val of values) {
        this.listOfDealTypeValues = val.dealType;
      }
    }
  }

  //Create Company Dialog  box to create a new comnpany 
  private setConfig(event) {
    let self = this;
    if (event.currentTarget.innerText == "NEW COMPANY") {
      this.formGroupList[0].get('searchCompany').reset('');
      let dialogRef = self.dialog.open(CreateCompanyComponent, {
        height: '360px',
        width: '500px',
        data: []
      });
      this.clientDataService.getCompanyCreatedFromDeal().subscribe(name => {
      this.companyName = name;
        if (this.companyName) {
          let listUrl = this.appUrl + 'companies';
          this.clientDataService.setUrl(listUrl);
          this.clientDataService.getClientData().subscribe(res => {
            this.listOfCompanyValues = [];
            for (let comp of res.values) {
              if (comp.name == this.companyName) {
                this.listOfCompanyValues.push(comp);
              }
            }
          })
        }
      });
    }
    if (event.currentTarget.innerText == "SEARCH") {

      this.availCompanyList = [];
      //defaults to contains search type
      if (this.searchTypeName == undefined) {
        this.searchTypeName = 'contains';
        if (this.searchTerm) {
          let listUrl = this.appUrl + 'companies/searchCompanies' + '/' + this.searchTypeName + '?searchText=' + this.searchTerm;
          this.clientDataService.setUrl(listUrl);
          this.clientDataService.getClientData().subscribe(res => {
            this.listOfCompanyValues = res;
          })
        }
        //on selected searchtype following executes
      } else {
        if (this.searchTerm) {
          let listUrl = this.appUrl + 'companies/searchCompanies' + '/' + this.searchTypeName + '?searchText=' + this.searchTerm;
          this.clientDataService.setUrl(listUrl);
          this.clientDataService.getClientData().subscribe(res => {
            this.listOfCompanyValues = res;
          })
        }
      }
    }
  }

  //fetches search words to search for companies available with
  private searchTermMethod(event) {
    this.searchTerm = event.target.value;
  }
  //fetches search Type selected
  private searchType(serVal) {
    if (serVal == "BEGINSWITH") {
      this.searchTypeName = 'beginsWith';
      this.isSearchTypeContains = false;
    } else {
      this.searchTypeName = 'contains';
      this.isSearchTypeContains = true;
    }
  }

  //get division id to pull related task and library templates
  getSelectedDivision(list) {
    this.divisionId = list.id;
    if (this.divisionId) {
      for (let obj of this.listOfDivisionValues) {
        if (obj.id == this.divisionId)
          this.divisionSelected = obj;
      }
      //fetch task template
      {
        let listUrl = this.appUrl + 'taskTemplate/findTaskTemplatesByDivision/' + JSON.stringify(this.divisionId);
        this.clientDataService.setUrl(listUrl);
        this.clientDataService.getClientData().subscribe(res => {
          this.listOfTaskValues = res;
        });
      }
      // fetch library template
      {
        let listUrl = this.appUrl + 'libraryTemplates/division/' + JSON.stringify(this.divisionId);
        this.clientDataService.setUrl(listUrl);
        this.clientDataService.getClientData().subscribe(res => {
          this.listOfLibraryValues = res.values;
        });
      }
    }
  }

  //get company id to fetch selected company obj and to append with post payload 
  getSelectedCompany(list) {
    this.companyId = list.id;
    if (this.companyId) {
      for (let obj of this.listOfCompanyValues) {
        if (obj.id == this.companyId)
          this.companySelected = obj;
      }
    }
  }
  //get task template id to fetch selected company obj and to append with post payload 
  getSelectedTaskTemplate(list) {
    this.taskTemId = list.id;
  }
  //get library template id to fetch selected company obj and to append with post payload 
  getSelectedLibTemplate(list) {
    this.libraryTemId = list.id;
  }
  //go back to last page viewed
  goBack() {
    this.location.back();
  }
  // navigates to seleted Name.
  public changeRoute(routeName, sideNavRef) {
    this.route.navigateByUrl(routeName);
  }
  //createDeal Object for payload
  create() {

    let formObj =
      {
        "company": null,
        "division": null,
        "dealName": null,
        "dealTypeId": null,
        "taskTemplate": null,
        "libraryTemplate": null
      }
    for (let ctrl in this.formGroupList[0].controls) {
      if (ctrl == 'companyName') {
        if (this.companySelected != undefined) {
          formObj.company = this.companySelected;
        } else {
          // alert(this.companySelected);
          this.openSnackBar('Company Name cannot be empty');
          formObj.company = null;
          return false;
        }
      } else if (ctrl == 'division') {
        if (this.divisionSelected != undefined) {
          formObj.division = this.divisionSelected;
        } else {
          this.openSnackBar('Division cannot be empty');
          formObj.division = null;
          return false;
        }
      } else if (ctrl == 'dealName') {
        let val = this.formGroupList[0].controls[ctrl].value;
        if (val == undefined) {
          this.openSnackBar('Deal Name cannot be empty');
          return false;
        } 
        else {
          formObj.dealName = this.formGroupList[0].controls[ctrl].value;
        }
      } else if (ctrl == 'dealType') {
        let dealTypeId = this.formGroupList[0].controls[ctrl].value;
        if (dealTypeId != undefined) {
          formObj.dealTypeId = this.formGroupList[0].controls[ctrl].value;
        } else {
          this.openSnackBar('Deal Type cannot be empty');
          return false;
        }
      } else if (ctrl == 'taskTemplate') {
        if (this.taskTemId) {
          for (let obj of this.listOfTaskValues) {
            if (obj.id == this.taskTemId)
              formObj.taskTemplate = obj;
          }
        } else {
          this.openSnackBar('Task Template cannot be empty');
          formObj.taskTemplate = null;
          return false;
        }
      } else if (ctrl == 'libraryTemplate') {
        if (this.libraryTemId) {
          for (let obj of this.listOfLibraryValues) {
            if (obj.id == this.libraryTemId)
              formObj.libraryTemplate = obj;
          }
        } else {
          this.openSnackBar('Library Template cannot be empty');
          formObj.libraryTemplate = null;
          return false;
        }
      }
    }
    let postSelectedList = this.appUrl + 'deals/';
    this.clientDataService.setUrl(postSelectedList);
    this.clientDataService.PostClientData(formObj).subscribe(res => {

      this.openSnackBar("New Deal has been created in Deal List");

    }, err => {
      let errVal = JSON.parse(err._body);
      console.log(errVal.errorMessages);
      this.openSnackBar(errVal.errorMessages);
    }
    );
  }
  // generic method to handle snackbar
  public openSnackBar(msg) {
    this.snackBar.open(msg, 'Close', {
      duration: 5000,
    });
  }
  //check validation on create button
  checkIfFormValid() {
    if (this.formGroupList[0]) {
      if (
        !this.formGroupList[0].controls['companyName'].value ||
        !this.formGroupList[0].controls['division'].value ||
        !this.formGroupList[0].controls['dealName'].value ||
        !this.formGroupList[0].controls['dealType'].value ||
        !this.formGroupList[0].controls['taskTemplate'].value ||
        !this.formGroupList[0].controls['libraryTemplate'].value
      ) {
        return true;
      }
    }
  }

}
