import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MyMaterialModule } from '../material.module';
import { routing } from './reports-routing';
import { ReportsComponent } from "./reports.component";

@NgModule({
    declarations:[ReportsComponent],
    imports:[CommonModule,
        MyMaterialModule,
        routing,
        DragDropDirectiveModule,
        ],
    exports:[ReportsComponent] //components that are defined in this module but might be used in other modules are included here
})
export class ReportsModule{

}