export class Node {
    ID:string;
    name:string;
    isLeafNode:boolean;
    parent?:Node;
    children?:Node[];
    isSelected?:boolean;
    isIntermediate?:boolean;
    isNodeExpanded?:boolean;
  }