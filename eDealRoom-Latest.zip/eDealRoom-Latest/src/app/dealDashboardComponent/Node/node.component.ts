import { Component, OnInit,Input } from '@angular/core';
import {Node} from '../Node';
import { trigger,style,transition,animate,keyframes,query,stagger } from '@angular/animations';

import {
   state
} from '@angular/animations';

@Component({
  selector: 'app-node',
  templateUrl: './node.component.html',
  styleUrls: ['./node.component.css'],
   animations: [
    /*  trigger('listAnimation', [
      transition('* => *', [

        query(':enter', style({ opacity: 0 }), {optional: true}),

        query(':enter', stagger('300ms', [
          animate('.5s ease-in', keyframes([
            style({opacity: 0, transform: 'translateY(-75%)', offset: 0}),
            style({opacity: .5, transform: 'translateY(35px)',  offset: 0.3}),
            style({opacity: 1, transform: 'translateY(0)',     offset: 1.0}),
          ]))]), {optional: true}),
            query(':leave', stagger('300ms', [
          animate('.2s ease-out', keyframes([
            style({opacity: 1, transform: 'translateY(0)', offset: 0}),
            style({opacity: .5, transform: 'translateY(-200%)',  offset: 0.3}),
            style({opacity: 0, transform: 'translateY(100%)',     offset: 1.0}),
          ]))]), {optional: true})
      ])
    ]),
*/
    trigger('slide', [
     //  state('true', style({ height: '*' })),
    //  state('false', style({ height: '0' })),
      transition('* => true', [ style({ 'transform': 'translateY(120%)' }),animate('200ms ease-in',style({
        'transform': 'translateY(0%)'
        }))]),
      transition('* => false',[style({'transform': 'translateY(120%)' }), animate('300ms ease-in',style({
          'transform': 'translateY(0%)'
        }))]),
  ])]
})
export class NodeComponent implements OnInit {
@Input('nodes')nodes:Node[];
  constructor() { }
  ngOnInit() {
  }
onNodeToggle(node:Node,event:any){
  node.isNodeExpanded= !node.isNodeExpanded;
}
onNodeSelectionChange(clickedNode:Node,currentNode:Node,event:any){
  clickedNode.isSelected=event;
  if(currentNode.children && currentNode.children.length>0){
    currentNode.children.forEach(Childnode=>{
         Childnode.isSelected=event;
         if(Childnode.children && Childnode.children.length>0){
           this.onNodeSelectionChange(clickedNode,Childnode,event);
         }
    });
  }
  if(clickedNode.parent){
    //node.parent.isIntermediate=true;
   let  parentNode=clickedNode.parent;
    while(parentNode){
      let result=this.ifAllChildSelected(parentNode,clickedNode,event);
       if(!parentNode.isSelected){
      parentNode.isIntermediate=result.anyChildSelected;
       parentNode.isSelected=result.isAllSelected;
       }
     if( parentNode.isSelected){
        parentNode.isIntermediate=false;
     }
    // console.log(parentNode.name +" Is now All selected ??"+result.isAllSelected);
      parentNode=parentNode.parent;  
    }
}
}
ifAllChildSelected(parentNode:Node,clickedNode:Node,event:any):any{
  //  console.log('Called for '+node.name);
    let isAllSelected:boolean=true;
    let anyChildSelected:boolean=false;
    if(parentNode.children){
      parentNode.children.forEach(childNode=>{
        //console.log(childNode.name +' is selected ? '+childNode.isSelected);
        if(childNode.name===clickedNode.name){
          isAllSelected=isAllSelected && event;
          anyChildSelected=anyChildSelected || event;
        }else {
          isAllSelected=isAllSelected && (childNode.isSelected?true:false);
          anyChildSelected=anyChildSelected || childNode.isSelected ||childNode.isIntermediate;
                }
            })
  }
  // console.log('returning All selected for  '+isAllSelected);
  return {isAllSelected:isAllSelected,anyChildSelected:anyChildSelected} ;
}
}