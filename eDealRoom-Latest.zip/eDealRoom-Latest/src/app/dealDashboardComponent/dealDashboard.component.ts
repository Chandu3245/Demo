import {Component} from '@angular/core';
import{Node} from './Node';
import {Router,ActivatedRoute} from '@angular/router';

@Component({
  selector: 'dash-deal',
  templateUrl: './dealDashboard.component.html',
  styleUrls: ['./dealDashboard.component.scss']
})
export class DealDashboardComponent  {
 
  nodes:Node[];
  subTreeNodes:Node[]=[];
  constructor(private router:Router,private route: ActivatedRoute){}
ngOnInit(){
  this.nodes=new Array();
var parentNodeNum:number=0;
  for (parentNodeNum=0;parentNodeNum<=7;parentNodeNum++) {
    let node=this.createNode(false,'Parent Node '+(parentNodeNum+1)+ ' Level 1');
    node.children=new Array();
    var num:number = 0
      for(num=0;num<=10;num++) {
        let childNode=this.createChildNode(node,false,'Child Node '+(num+1)+ ' Level 2');
        var childNum:number=0;
        childNode.children=new Array();
        for (childNum=0;childNum<=10;childNum++) {
            let grandChild =this.createChildNode(childNode,true,'Child Node '+(childNum+1)+ ' Level 3');
              childNode.children.push(grandChild);
        }
        node.children.push(childNode);
      }
      // for(childNum=0;childNum<=10;childNum++) {
      //   this.createChildNode(node,true,'Child Node '+(childNum+1)+ ' Level3');
      // }
    this.nodes.push(node);
  }
}
createNode(isLeafNode:boolean,nodeName:string){
  let node:Node =new Node();
  node.ID=Math.random.name;
  node.name=nodeName;
  node.isLeafNode=isLeafNode;
  node.isNodeExpanded=false;
  node.isIntermediate=false;
  node.isSelected=false;
  return node;

}
createChildNode(parentNode:Node,isLeafNode:boolean,nodeName:string){
  let node:Node =new Node();
  node.parent=parentNode;
  node.ID=Math.random.name;
  node.name=nodeName;
  node.isLeafNode=isLeafNode;
  node.isNodeExpanded=false;
  node.isIntermediate=false;
  node.isSelected=false;
  return node;

}
saveSelections(){
   this.nodes.forEach(node=>{
      if(node.isSelected){
        this.subTreeNodes.push(node);
      }else if(node.isIntermediate){
        //SOME CHILD NODES ARE SELECTED AND NOW HAVE TO ADJUST

       let clonedNode= Object.assign({}, node);
       this.subTreeNodes.push(clonedNode);

        this.purgeTree(this.subTreeNodes);
      }
});
}

purgeTree(nodes:Node[]){
  if(nodes===undefined){
    return;
  }
nodes.forEach(childNode=>{
        if(!childNode.isSelected && !childNode.isIntermediate){
        //  nodes.slice(nodes.indexOf(childNode));
          var index = nodes.indexOf(childNode, 0);
if (index > -1) {
   nodes.splice(index, 1);
}else if(childNode.isIntermediate){
this.purgeTree(childNode.children);
}

        }
});
}

public clone(node:Node): any {
    var cloneObj = new Node();
    for (var attribut in Node) {
        if (typeof this[attribut] === "object") {
         //   cloneObj[attribut] = this.clone(node);
        } else {
            cloneObj[attribut] = this[attribut];
        }
    }
    return cloneObj;
}
}
