
import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyMaterialModule } from './material.module';
import {CdkTableModule} from '@angular/cdk/table';
import { TemplatesModule } from "./templatesComponent/templates.module";

import { AppComponent } from './app.component';
import { DealDashboardComponent } from './dealDashboardComponent/dealDashboard.component';
import { NodeComponent } from "./dealDashboardComponent/Node/node.component";
import { appRouting } from "./app.routing";
import { DragDropDirectiveModule} from "angular4-drag-drop";
import { ProfileFormComponent } from './profile-form/profile-form.component';
import { SearchProfileComponent } from './search-profile/search-profile.component';
import { UserProfileComponent } from './adminComponent/user-profile/user-profile.component';
import { CompanyProfileComponent } from './adminComponent/company-profile/company-profile.component';

import { MyProfileComponent } from './adminComponent/my-profile/my-profile.component';
import { MyPreferencesComponent } from './adminComponent/my-preferences/my-preferences.component';
import { BusinessProfileComponent } from './adminComponent/business-profile/business-profile.component';
import { FilterPipe } from './pipes/filter.pipe';
import { CreateProfileDialogComponent } from './create-profile-dialog/create-profile-dialog.component';
import { ClientDataService } from './services/app.service';

import { BrowserXhr } from '@angular/http';
import { CustomBrowserXhr} from './custom-browser-xhr';
import { CustomGroupsComponent } from './adminComponent/business-profile/custom-groups/custom-groups.component';
import { ApplicationPermissionsComponent } from './adminComponent/business-profile/application-permissions/application-permissions.component';
import { BusinessHierarchyComponent } from './adminComponent/business-profile/business-hierarchy/business-hierarchy.component';
import { CreateDealComponent } from './dealsComponent/create-deal/create-deal.component';
import { CreateCompanyComponent } from './create-company/create-company.component';
import { ProfileFieldsComponent } from './adminComponent/business-profile/profile-fields/profile-fields.component';
import { ProfileFieldService } from './adminComponent/business-profile/profile-fields/profile-fields.service';
import { BusinessProfileService } from './adminComponent/business-profile/business-profile.service';
import { ProfileFieldsGroupDialogComponent } from './adminComponent/business-profile/profile-fields/profile-fields-group-dialog/profile-fields-group-dialog.component';
import { ProfileFieldsDialogComponent } from './adminComponent/business-profile/profile-fields/profile-fields-dialog/profile-fields-dialog.component';
import { AddGroupDialogComponent } from './adminComponent/business-profile/profile-fields/add-group-dialog/add-group-dialog.component';
import { AddProfilefieldDialogComponent } from './adminComponent/business-profile/profile-fields/add-profilefield-dialog/add-profilefield-dialog.component';
import { DataSourcesComponent } from './adminComponent/business-profile/data-sources/data-sources.component';
import { DataSourceConfigurationComponent } from './adminComponent/business-profile/data-sources/data-source-configuration/data-source-configuration.component';

@NgModule({
  declarations: [
    NodeComponent,AppComponent,DealDashboardComponent,ProfileFormComponent,SearchProfileComponent,UserProfileComponent,CompanyProfileComponent,FilterPipe
    ,MyProfileComponent,MyPreferencesComponent,BusinessProfileComponent, CreateProfileDialogComponent,
  CustomGroupsComponent, ApplicationPermissionsComponent, BusinessHierarchyComponent, CreateDealComponent,CreateCompanyComponent, 
  ProfileFieldsComponent, ProfileFieldsGroupDialogComponent, ProfileFieldsDialogComponent, AddProfilefieldDialogComponent,AddGroupDialogComponent, DataSourcesComponent,
  DataSourceConfigurationComponent],
  imports: [
    BrowserModule,BrowserAnimationsModule,MyMaterialModule,TemplatesModule,
    FormsModule,ReactiveFormsModule,DragDropDirectiveModule,CdkTableModule,
    HttpModule,appRouting,
  ],
  providers: [ClientDataService,ProfileFieldService,BusinessProfileService,
    { provide: BrowserXhr, useClass: CustomBrowserXhr }, 
  ],
  exports:[FilterPipe],
  bootstrap: [AppComponent],
  entryComponents: [CreateProfileDialogComponent, CreateCompanyComponent, 
    ProfileFieldsGroupDialogComponent, ProfileFieldsDialogComponent, AddGroupDialogComponent, AddProfilefieldDialogComponent]
})
export class AppModule {}
 