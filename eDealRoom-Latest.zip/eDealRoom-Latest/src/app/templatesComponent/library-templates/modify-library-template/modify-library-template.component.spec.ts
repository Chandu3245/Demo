import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyLibraryTemplateComponent } from './modify-library-template.component';

describe('ModifyLibraryTemplateComponent', () => {
  let component: ModifyLibraryTemplateComponent;
  let fixture: ComponentFixture<ModifyLibraryTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyLibraryTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyLibraryTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
