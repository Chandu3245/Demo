
import { Component, OnInit,Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { ClientDataService } from '../../../services/app.service';
import { Router } from '@angular/router';
import { environment } from './../../../../environments/environment';

@Component({
  selector: 'app-modify-library-template',
  templateUrl: './modify-library-template.component.html',
  styleUrls: ['./modify-library-template.component.scss']
})
export class ModifyLibraryTemplateComponent {// implements OnInit {

  private appUrl: any;
  private taskTemplateForm: any;
  private taskTemplateValueForm: any;
  private newTemplateForm: FormGroup;
  private profileFormGroup: FormGroup;
  private templateId = null;
  private resVals: any;
  private rowValues: any;
  private resProperties: any;
  private errorCode:any;
  constructor(private fb: FormBuilder, private appService: ClientDataService, private router: Router,
              @Inject(MatSnackBar) public snackBar: MatSnackBar) {
    this.appUrl = environment.appURL;
  }

  ngOnInit() {
    this.templateId = this.appService.getToBeModified();
    let selectedusers = this.appUrl + 'libraryTemplates/' + JSON.stringify(this.templateId) + '?name=ModifyLibraryTemplate';
    this.appService.setUrl(selectedusers);
    this.appService.getClientData().subscribe(res => {
      console.log(res)
      this.rowValues = res;
      this.resProperties = res.properties;
      this.resVals = res.values;
      this.profileFormGroup = this.createGroup();
      for (let item of res.properties) {
        if (item.attributeName == 'companyId') {
          this.profileFormGroup.controls[item.attributeName].setValue(res.values[0].company.name);
        }
        else if (res.values[0][item.attributeName]) {
          this.profileFormGroup.controls[item.attributeName].setValue(res.values[0][item.attributeName])
        }
      }
    })
  }
  createGroup() {
    const group = this.fb.group({});
    this.resProperties.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
    return group;
  }
  createControl(config) {
    const { isDisabled, validation, value } = config;
    return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  }
  done() {
    let formObj =
      {
        "id": this.templateId,
        "libraryTemplateName": "",
        "libraryTemplateDesc": "",
        "company": {
          "id": this.resVals[0].company.id
        },
        "activeInd": 1,
        "defaultInd": 1
      }
//       {
//   "id": 131,
//   "lastModifiedUser": {
//     "id": 1
//   },
//   "libraryTemplateName": "Lib template remove 4 updated 4th time",
//   "libraryTemplateDesc": "Library Template Nixon 4 updated 1",
//   "company": {
//     "id": 257
//   },
//   "activeInd": 1,
//   "defaultInd": 0
// } 

    //  formObj.id=this.compId;
    for (let ctrl in this.profileFormGroup.controls) {
      if (ctrl == 'libraryTemplateName') {
        formObj.libraryTemplateName = this.profileFormGroup.controls[ctrl].value;
      } if (ctrl == 'libraryTemplateDesc') {
        formObj.libraryTemplateDesc = this.profileFormGroup.controls[ctrl].value;
      } if (ctrl == 'defaultInd') {
        // console.log(this.profileFormGroup.controls[ctrl].value)
        if(this.profileFormGroup.controls[ctrl].value==false){
          console.log('false')
          formObj.defaultInd = 0;
        }
        if(this.profileFormGroup.controls[ctrl].value==true){
          console.log('true')
          formObj.defaultInd = 1;
        }
        } if (ctrl == 'companyId') {
        // formObj.company.id = this.profileFormGroup.controls[ctrl].value;
      }
    }
    console.log(this.profileFormGroup);
    console.log(formObj)
    let postSelectedTemplate= this.appUrl + "libraryTemplates/"+ JSON.stringify(this.templateId);
    this.appService.setUrl(postSelectedTemplate);
   this.appService.PutClientData(formObj).subscribe(res => {
     
      this.openSnackBar("Company List has been updated succefully");
      this.router.navigateByUrl('/libraryTemplates');
    },err =>{
      let errVal = JSON.parse(err._body);
      this.errorCode=errVal.errorMessages;
      this.openSnackBar(errVal.errorMessages);
     }
  );
    
  }
   // generic method to handle snackbar
   public openSnackBar(msg){
    this.snackBar.open(msg, 'Close', {
        duration: 5000,
    });
}
}

