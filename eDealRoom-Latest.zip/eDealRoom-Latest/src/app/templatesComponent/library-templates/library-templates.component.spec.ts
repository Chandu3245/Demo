import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibraryTemplatesComponent } from './library-templates.component';

describe('LibraryTemplatesComponent', () => {
  let component: LibraryTemplatesComponent;
  let fixture: ComponentFixture<LibraryTemplatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibraryTemplatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibraryTemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
