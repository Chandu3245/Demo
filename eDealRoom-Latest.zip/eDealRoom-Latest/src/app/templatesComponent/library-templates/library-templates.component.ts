
import { Component,Inject, OnInit } from '@angular/core';
import { MatDialog,MatDialogModule,MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar  } from '@angular/material';
import { environment } from './../../../environments/environment';
import { LibraryTemplateDialogComponent } from './library-template-dialog.component'
import { Observable } from 'rxjs';
import { MatTableModule } from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {MatPaginator, MatTableDataSource} from '@angular/material';
import { ClientDataService } from '../../services/app.service';
import { Router  } from "@angular/router";
@Component({
  selector: 'app-library-templates',
  templateUrl: './library-templates.component.html',
  styleUrls: ['./library-templates.component.scss']
})
export class LibraryTemplatesComponent {
  private appUrl: any;
  private rowValues={};
  private rowVals=[];
  private libraryTemplates=[];
  private divisions=[];
  private selDivision='';
  private selectAllCheck: boolean = false;
  public checked: boolean = false;
  private checkStatusList=[];
  private listofSelectedRows=[];
  private listofNonDefaultRows=[];
  private selRowsCount=[];
  private selectingRows=[]; 
  private elementModel=[];
  private displayedColumns = ['checkbox','Template', 'Default', 'Last Modified By', 'Last Modified'];
  private initialSelection = [];
  private allowMultiSelect = true;
  private selection = new SelectionModel<PeriodicElement>(this.allowMultiSelect,this.initialSelection);
  private dataSource = new MatTableDataSource<PeriodicElement>(this.elementModel);
  private errorCode:any;
  
  constructor(public dialog:MatDialog, @Inject(ClientDataService) private clientDataService: ClientDataService,@Inject(MatSnackBar) public snackBar: MatSnackBar,@Inject(Router) private router:Router) {
    this.appUrl = environment.appURL;
    this.clientDataService.getRowSelectioinObservable().subscribe(res => {
      this.listofNonDefaultRows=[];
      this.selRowsCount = res;//listofSelectedRows
      for(let item of this.rowVals){
        if(item.defaultInd==0){
          this.listofNonDefaultRows.push(true);
        }
      }
      if(this.selRowsCount.length<this.listofNonDefaultRows.length){
        this.checked=false;
        this.selectAllCheck=false;
      }
      else{
        this.selectAllCheck=true;
        this.checked=true;
      }
    })
  }
  ngOnInit() {
    this.getTemplatesFromServer();
  }
  private setConfig() {
    let self = this;
    let dialogRef = self.dialog.open(LibraryTemplateDialogComponent, {
      height: '370px',
      width: '1000px',
      data: []
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }
  private modifyTemplate(template){
    for(let row of this.rowVals){
      if(template.tempId==row.id){
        this.clientDataService.setToBeModified(row.id);  
        break;
      }
    }
    this.router.navigateByUrl('/modifyLibrary');
  }
  //Methods to fetch all templates 
  getTemplatesFromServer(){
    let allDivisions=this.appUrl+'libraryTemplates?name=LibraryTemplateList';
    this.clientDataService.setUrl(allDivisions);
    this.clientDataService.getClientData().subscribe(res => {
      this.rowValues=res;
      this.divisions=res.divisions;
      this.rowVals=res.libraryTemplates;
      this.clientDataService.setRows(this.rowVals);
      for(let row of this.rowVals){
        this.checkStatusList.push(false);
        let element:PeriodicElement={name:'', defaultIndex:null, userName:'',lastModifiedDate:'',tempId:null}
        element.name=row.libraryTemplateName;
        element.defaultIndex=row.defaultInd;
        element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName;
        element.lastModifiedDate=row.lastModifiedDate;
        element.tempId=row.id;
        this.elementModel.push(element);
      }
      this.divisions.push({name:'All Divisions'})
      this.dataSource = new MatTableDataSource<PeriodicElement>(this.elementModel);
      this.selDivision=this.divisions.find(val=> val.name=="All Divisions").name;
    })
  }
  onSelect(division:any){
    if(this.checked || this.selectAllCheck){
      this.selectAllCheck = !this.selectAllCheck;
      this.checked=!this.checked;
    }
    this.checkStatusList=[];
    this.selRowsCount=[];
    this.listofSelectedRows=[];
    this.selectingRows=[];
    this.listofNonDefaultRows=[];
    this.selDivision=division.name;
    this.elementModel=[];
    if(this.selDivision=='All Divisions'){
      this.getTemplatesFromServer();
    }
    else{
      let selectedDivision=this.appUrl+'libraryTemplates/division/' + JSON.stringify(division.id) ;
      this.clientDataService.setUrl(selectedDivision);
      this.clientDataService.getClientData().subscribe(res => {
        this.rowVals=res.values;
        this.clientDataService.setRows(res.values);
        for(let row of res.values){
          this.checkStatusList.push(false);
          let element:PeriodicElement={name:'', defaultIndex:null, userName:'',lastModifiedDate:'',tempId:null}
          element.name=row.libraryTemplateName;
          element.defaultIndex=row.defaultInd;
          element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName
          element.lastModifiedDate=row.lastModifiedDate;
          element.tempId=row.id;
          this.elementModel.push(element);
        }
        this.dataSource = new MatTableDataSource<PeriodicElement>(this.elementModel);
      })
    }
  }
  selectAllRow(event){
    this.checked = !this.checked;
    this.selectingRows = [];
    this.listofSelectedRows=[];
    if(event.checked){
      this.isAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    else{
      this.listofSelectedRows=[];
      for(let i = 0; i <this.rowVals.length; i++){
        this.checkStatusList[i]=false;
      }
      this.selectingRows = [];
    }
    this.clientDataService.setRowSelectionObservable(this.selectingRows);
  }
  rowSelChanged(aRow,rowIndex,event){
    if(this.checked){
      this.selectingRows=[]
      this.isAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    let selectedRowVal = this.clientDataService.getEdittedRow(rowIndex);
    this.checkStatusList[rowIndex] = event.checked;
    let obj={id:selectedRowVal.id};
    if(event.checked){
      this.listofSelectedRows.push(obj);
    }
    else{
      this.checked= ! this.checked;
      var removeIndex = this.listofSelectedRows.map(function(item) { return item.id; }).indexOf(selectedRowVal.id);
      this.listofSelectedRows.splice(removeIndex, 1);
    }
    this.clientDataService.setRowSelectionObservable(this.listofSelectedRows);
    this.checkStatusList[rowIndex]=event.checked;
    let selectingRows=[];
    for ( let eachRow of this.rowVals){
      if(this.checkStatusList){
        selectingRows.push(eachRow.id);
      }
    }
  }
  isAllChecked(){
    for(let i = 0; i <this.rowVals.length; i++){
      let selRow=this.clientDataService.getEdittedRow(i);
      let obj={id:selRow.id};
      if(selRow && selRow.defaultInd==0){
        this.checkStatusList[i]=true;
        this.selectingRows.push(obj);
      }
      else{
        this.checkStatusList[i]=false;
      }
    }
  }
  remove(){
    let selectedusers=this.appUrl+'libraryTemplates/deleteLts';
    let obj={values:this.listofSelectedRows};
    this.clientDataService.setUrl(selectedusers);
    this.clientDataService.PostClientData(obj).subscribe(res=>{
      let division=this.divisions.find(val=> val.name==this.selDivision);
      this.onSelect(division);
      this.openSnackBar("Selected Template has been deleted successfully");
      },
      err=>{
        let errVal= JSON.parse(err._body);
        this.errorCode=errVal.errorMessages;
        this.openSnackBar(errVal.errorMessages);
      }
    )
  }
   //generic Method for snackbars
  public openSnackBar(msg){
    this.snackBar.open(msg, 'Close', {
        duration: 5000,
    });
  }
}

export interface PeriodicElement {
  name: string;
  defaultIndex: number;
  userName: string;
  lastModifiedDate: string;
  tempId:number;
}
