
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ClientDataService } from '../../services/app.service';
import { environment } from './../../../environments/environment';

@Component({
  selector: 'app-library-template-dialog',
  templateUrl: './library-template-dialog.component.html',
  styleUrls: ['./library-template-dialog.component.scss']
})
export class LibraryTemplateDialogComponent implements OnInit {
private appUrl: any;
private taskTemplateForm :any; 
private taskTemplateValueForm :any; 
private newTemplateForm:FormGroup;

constructor( private fb:FormBuilder,private appService: ClientDataService){
  this.appUrl = environment.appURL;
}

ngOnInit() {
  let taskAttributeUrl = this.appUrl +'libraryTemplates/attributeGroup?name=LibraryTemplate';
  this.appService.setUrl(taskAttributeUrl);
  let self= this;
  this.appService.getClientData().subscribe(res => {
    self.taskTemplateForm =res.properties;
    self.taskTemplateValueForm=res.values;
    self.newTemplateForm=self.createGroup(self.taskTemplateForm);
})
}
createGroup(task) {
  const group = this.fb.group({});
  task.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
  return group;
}
createControl(config) {
  const { isDisabled, validation, value } = config;
  let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  let self = this;
  return control;
}
}
