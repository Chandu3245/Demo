
import { NgModule } from '@angular/core';
import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { MyMaterialModule } from '../../material.module';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

import { LibraryTemplateDialogComponent } from "./library-template-dialog.component";
import { LibraryTemplatesComponent } from "./library-templates.component";
@NgModule({
  imports:[CommonModule,FormsModule,ReactiveFormsModule,
    MyMaterialModule,
    DragDropDirectiveModule,
    ],
  declarations: [LibraryTemplatesComponent,LibraryTemplateDialogComponent],
  entryComponents: [
    LibraryTemplateDialogComponent
],
exports:[LibraryTemplatesComponent] 
})
export class LibraryTemplatesModule { }
