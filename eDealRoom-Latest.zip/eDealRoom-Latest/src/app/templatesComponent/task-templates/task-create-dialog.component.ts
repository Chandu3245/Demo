
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ClientDataService } from '../../services/app.service';
import { environment } from './../../../environments/environment';

@Component({
  selector: 'app-task-create-dialog',
  templateUrl: './task-create-dialog.component.html',
  styleUrls: ['./task-create-dialog.component.scss']
})
export class TaskCreateDialogComponent implements OnInit {
private appUrl: any;
private taskTemplateForm :any; 
private taskTemplateValueForm :any; 
private newTemplateForm:FormGroup;
private divisionMasterTemplates:any;
constructor( private fb:FormBuilder,private appService: ClientDataService){
  this.appUrl = environment.appURL;
}

ngOnInit() {
  let taskAttributeUrl = this.appUrl +'taskTemplate/attributeGroup?name=TaskTemplate';
  
  this.appService.setUrl(taskAttributeUrl);
  let self= this;
  this.appService.getClientData().subscribe(res => {
    self.taskTemplateForm =res.properties;
    self.taskTemplateValueForm=res.divisions;
    self.divisionMasterTemplates=res.divisionMasterTemplates;
    self.newTemplateForm=self.createGroup(self.taskTemplateForm);
})
}
createGroup(task) {
  const group = this.fb.group({});
  task.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
  return group;
}
createControl(config) {
  const { isDisabled, validation, value } = config;
  let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  let self = this;
  return control;
}
}
