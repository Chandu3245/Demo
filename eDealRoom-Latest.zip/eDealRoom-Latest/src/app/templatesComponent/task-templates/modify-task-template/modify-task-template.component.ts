import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from "@angular/router";
import { ClientDataService } from '../../../services/app.service';
import { environment } from './../../../../environments/environment';

@Component({
  selector: 'app-modify-task-template',
  templateUrl: './modify-task-template.component.html',
  styleUrls: ['./modify-task-template.component.scss']
})
export class ModifyTaskTemplateComponent implements OnInit {

 
  private appUrl: any;
  private taskTemplateForm :any; 
  private taskTemplateValueForm :any; 
  private newTemplateForm:FormGroup;
  private profileFormGroup: FormGroup;
  private templateId=null;
  private resVals:any;
  private rowValues:any;
  private resProperties:any;
  constructor( private fb:FormBuilder,private appService: ClientDataService, private router:Router){
    this.appUrl = environment.appURL;
  }
  
  ngOnInit() {
    this.templateId=this.appService.getToBeModified();
    let selectedusers=this.appUrl+'taskTemplate/' + JSON.stringify(this.templateId) + '/ModifytaskTemplate';
    this.appService.setUrl(selectedusers);
    this.appService.getClientData().subscribe(res=>{
      console.log(res)
      this.rowValues=res;
      this.resProperties=res.properties;
      this.resVals=res.values;
      this.profileFormGroup = this.createGroup();
      for(let item of res.properties){
        if(item.attributeName=='division'){
          this.profileFormGroup.controls[item.attributeName].setValue(res.values[0].division.name);
        }
        else if (item.attributeName=='parentTemplateId'){
          this.profileFormGroup.controls[item.attributeName].setValue(res.values[0].divisionMasterTemplate.templateName);
        } 
        else if(res.values[0][item.attributeName]){
          this.profileFormGroup.controls[item.attributeName].setValue(res.values[0][item.attributeName])
        }
      }
  })
      }
  createGroup() {
    const group = this.fb.group({});
    this.resProperties.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
   return group;
  }
  createControl(config) {
    const { isDisabled, validation, value } = config;
    return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  }
  done(){
    this.router.navigateByUrl('/taskTemplates');
  }
  }
