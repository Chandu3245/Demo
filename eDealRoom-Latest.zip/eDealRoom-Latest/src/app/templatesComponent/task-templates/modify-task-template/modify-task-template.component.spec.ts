import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyTaskTemplateComponent } from './modify-task-template.component';

describe('ModifyTaskTemplateComponent', () => {
  let component: ModifyTaskTemplateComponent;
  let fixture: ComponentFixture<ModifyTaskTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyTaskTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyTaskTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
