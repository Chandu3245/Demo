import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskTemplatesComponent } from './task-templates.component';

describe('TaskTemplatesComponent', () => {
  let component: TaskTemplatesComponent;
  let fixture: ComponentFixture<TaskTemplatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskTemplatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskTemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
