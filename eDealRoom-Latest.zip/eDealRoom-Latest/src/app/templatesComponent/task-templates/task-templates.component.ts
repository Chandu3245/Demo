
import { Component,Inject, OnInit } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { environment } from './../../../environments/environment';
import { Observable } from 'rxjs';
import { Router } from "@angular/router";
import { MatTableModule } from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {MatPaginator, MatTableDataSource} from '@angular/material';
import { ClientDataService } from '../../services/app.service';
import { TaskCreateDialogComponent } from "./task-create-dialog.component";
@Component({
  selector: 'app-task-templates',
  templateUrl: './task-templates.component.html',
  styleUrls: ['./task-templates.component.scss']
})
export class TaskTemplatesComponent implements OnInit {
    private appUrl: any;
    private rowValues={};
    private rowVals=[];
    private divisions=[];
    private selDivision='';
    private selectAllCheck: boolean = false;
    public checked: boolean = false;
    private checkStatusList=[];
    private listofSelectedRows=[];
    private listofNonDefaultRows=[];
    private selRowsCount=[];
    private selectingRows=[]; 
    private elementModel=[];
    private displayedColumns = ['checkbox','Template', 'Default', 'Last Modified By', 'Last Modified','Copy'];
    private initialSelection = [];
    private allowMultiSelect = true;
    private selection = new SelectionModel<PeriodicElement>(this.allowMultiSelect,this.initialSelection);
    private dataSource = new MatTableDataSource<PeriodicElement>(this.elementModel);
    private errorCode:any;
    
    constructor(public dialog:MatDialog, @Inject(ClientDataService) private clientDataService: ClientDataService,@Inject(MatSnackBar) public snackBar: MatSnackBar,@Inject(Router) private router:Router) {
      this.appUrl = environment.appURL;
      this.clientDataService.getRowSelectioinObservable().subscribe(res => {
        this.listofNonDefaultRows=[];
        this.selRowsCount = res;//listofSelectedRows
        for(let item of this.rowVals){
          if(item.defaultIndicator==false){
            this.listofNonDefaultRows.push(true);
          }
        }
        if(this.selRowsCount.length<this.listofNonDefaultRows.length){
          this.checked=false;
          this.selectAllCheck=false;
        }
        else{
          this.selectAllCheck=true;
      	  this.checked=true;
        }
      })
     }
    ngOnInit() {
      this.getTemplatesFromServer();
    }
    
    private setConfig() {
      let self = this;
      let dialogRef = self.dialog.open(TaskCreateDialogComponent, {
        height: '370px',
        width: '1000px',
        data: []
      });
    
      dialogRef.afterClosed().subscribe(result => {
    
      });
    }
    //Methods to fetch all templates 
  getTemplatesFromServer(){
    let selectedusers=this.appUrl+'taskTemplate/retrieveall?name=' + 'TaskTemplateList';
    this.clientDataService.setUrl(selectedusers);
    this.clientDataService.getClientData().subscribe(res => {
      this.rowValues=res;
      this.divisions=res.divisions;
      this.rowVals=res.taskTemplates;
      this.clientDataService.setRows(this.rowVals);
      for(let row of this.rowVals){
        this.checkStatusList.push(false);
        let element:PeriodicElement={name:'', defaultIndex:null, userName:'',lastModifiedDate:'',copy:'',tempId:null}
        element.name=row.templateName;
        element.defaultIndex=row.defaultIndicator;
        element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName;
        element.lastModifiedDate=row.lastModifiedDate;
        element.tempId=row.id;
        this.elementModel.push(element);
      }
      this.divisions.push({name:'All Divisions'})
      this.dataSource = new MatTableDataSource<PeriodicElement>(this.elementModel);
      this.selDivision=this.divisions.find(val=> val.name=="All Divisions").name;
    })
  }
    onSelect(division:any){
      if(this.checked || this.selectAllCheck){
        this.selectAllCheck = !this.selectAllCheck;
        this.checked=!this.checked;
      }
      this.checkStatusList=[];
      this.selRowsCount=[];
      this.listofSelectedRows=[];
      this.selectingRows=[];
      this.listofNonDefaultRows=[];
      this.selDivision=division.name;
      this.elementModel=[];
      if(division.name=='All Divisions'){
        this.getTemplatesFromServer();
      }
      else{
      let selectedDivision=this.appUrl+'taskTemplate/division/' + JSON.stringify(division.id) + '?name=TaskTemplateList';
      this.clientDataService.setUrl(selectedDivision);
      this.clientDataService.getClientData().subscribe(res => {
        this.rowVals=res.values;
        this.clientDataService.setRows(res.values);
        for(let row of res.values){
          this.checkStatusList.push(false);
          let element:PeriodicElement={name:'', defaultIndex:false, userName:'',lastModifiedDate:'',copy:'',tempId:null}
          element.name=row.templateName;
          element.defaultIndex=row.defaultIndicator;
          element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName;
          element.lastModifiedDate=row.lastModifiedDate;
          element.tempId=row.id;
          this.elementModel.push(element);
        }
        this.dataSource = new MatTableDataSource<PeriodicElement>(this.elementModel);
      })
    }
  }
  modifyTemplate(template){
    console.log(this.rowVals)
    for(let row of this.rowVals){
      if(template.tempId==row.id){
        this.clientDataService.setToBeModified(row.id);  
        console.log(template)
        break;
      }
    }
    this.router.navigateByUrl('/modifyTask');
  }
  selectAllRow(event){
    this.checked = !this.checked;
    this.selectingRows = [];
    this.listofSelectedRows=[];
    if(event.checked){
      this.isAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    else{
      this.listofSelectedRows=[];
      for(let i = 0; i <this.rowVals.length; i++){
        this.checkStatusList[i]=false;
      }
      this.selectingRows = [];
    }
    this.clientDataService.setRowSelectionObservable(this.selectingRows);
  }
  rowSelChanged(aRow,rowIndex,event){
    if(this.checked){
      this.selectingRows=[]
      this.isAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    let selectedRowVal = this.clientDataService.getEdittedRow(rowIndex);
    this.checkStatusList[rowIndex] = event.checked;
    let obj={id:selectedRowVal.id};
    if(event.checked){
      this.listofSelectedRows.push(obj);
      }
    else{
      this.checked= ! this.checked;
      var removeIndex = this.listofSelectedRows.map(function(item) { return item.id; }).indexOf(selectedRowVal.id);
      this.listofSelectedRows.splice(removeIndex, 1);
    }
    this.clientDataService.setRowSelectionObservable(this.listofSelectedRows);
    this.checkStatusList[rowIndex]=event.checked;
    let selectingRows=[];
    for ( let eachRow of this.rowVals){
      if(this.checkStatusList){
        selectingRows.push(eachRow.id);
      }
    }
  }
  isAllChecked(){
    for(let i = 0; i <this.rowVals.length; i++){
      let selRow=this.clientDataService.getEdittedRow(i);
      let obj={id:selRow.id};
      if(selRow && selRow.defaultIndicator==false){
        this.checkStatusList[i]=true;
          this.selectingRows.push(obj);
      }
      else{
        this.checkStatusList[i]=false;
      }
    }
  }
  remove(){
    let selectedusers=this.appUrl+'taskTemplates/deleteTts';
    let obj={values:this.listofSelectedRows};
    this.clientDataService.setUrl(selectedusers);
    this.clientDataService.PostClientData(obj).subscribe(res=>{
      let division=this.divisions.find(val=> val.name==this.selDivision);
      this.onSelect(division);
      this.openSnackBar("Selected Template has been deleted successfully");
      },
      err=>{
        let errVal= JSON.parse(err._body);
        this.errorCode=errVal.errorMessages;
        this.openSnackBar(errVal.errorMessages);
      }
    )
  }
     //generic Method for snackbars
  public openSnackBar(msg){
    this.snackBar.open(msg, 'Close', {
        duration: 5000,
      });
    }
  }
  
  export interface PeriodicElement {
    name: string;
    defaultIndex: Boolean;
    userName: string;
    lastModifiedDate: string;
    copy:string;
    tempId:number;
  }
  
