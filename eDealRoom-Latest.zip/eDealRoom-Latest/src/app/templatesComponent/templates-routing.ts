
import { TemplatesComponent } from './templates.component';
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LibraryTemplatesComponent } from "./library-templates/library-templates.component";
import { MasterTemplatesComponent } from "./master-templates/master-templates.component";
import { TaskTemplatesComponent } from "./task-templates/task-templates.component";
import { ModifyLibraryTemplateComponent } from "./library-templates/modify-library-template/modify-library-template.component";
import { ModifyTaskTemplateComponent } from "./task-templates/modify-task-template/modify-task-template.component";
import { ModifyDivisionMasterComponent } from "./master-templates/modify-division-master/modify-division-master.component";
import { ModifyBusinessMasterComponent } from "./master-templates/modify-business-master/modify-business-master.component";

const routes: Routes = [
  { path: '', component: TemplatesComponent },
  {path :'libraryTemplates',component:LibraryTemplatesComponent},
  {path :'libraryTemplates',
  children: [
          {path: '', component:LibraryTemplatesComponent},
          { path: 'modifyLibrary', component: ModifyLibraryTemplateComponent },
          ]
  },
  {path :'masterTemplates',component:MasterTemplatesComponent},
  {path :'taskTemplates',component:TaskTemplatesComponent},
  {path :'modifyTask',component:ModifyTaskTemplateComponent},
  {path :'modifyLibrary',component:ModifyLibraryTemplateComponent},
  {path :'modifyDivisionMaster',component:ModifyDivisionMasterComponent},
  {path :'modifyBusinessMaster',component:ModifyBusinessMasterComponent},
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);