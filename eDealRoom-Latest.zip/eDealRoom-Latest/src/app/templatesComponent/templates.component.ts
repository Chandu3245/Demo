
import { Component,OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'dash-deal',
  templateUrl: './templates.component.html',
  styleUrls: ['./templates.component.scss']
})
export class TemplatesComponent implements OnInit {
 
  ngOnInit(){
  }

}
