import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyDivisionMasterComponent } from './modify-division-master.component';

describe('ModifyDivisionMasterComponent', () => {
  let component: ModifyDivisionMasterComponent;
  let fixture: ComponentFixture<ModifyDivisionMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyDivisionMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyDivisionMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
