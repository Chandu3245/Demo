import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-master-create-dialog',
  templateUrl: './business-master-create-dialog.component.html',
  styleUrls: ['./business-master-create-dialog.component.scss']
})
export class BusinessMasterCreateDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
