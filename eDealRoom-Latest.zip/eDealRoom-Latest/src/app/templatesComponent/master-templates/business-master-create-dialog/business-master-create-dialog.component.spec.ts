import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessMasterCreateDialogComponent } from './business-master-create-dialog.component';

describe('BusinessMasterCreateDialogComponent', () => {
  let component: BusinessMasterCreateDialogComponent;
  let fixture: ComponentFixture<BusinessMasterCreateDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessMasterCreateDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessMasterCreateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
