
import { Component,Inject, OnInit } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { environment } from './../../../environments/environment';
import { Observable } from 'rxjs';
import { Router } from "@angular/router";
import { MatTableModule } from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {MatPaginator, MatTableDataSource} from '@angular/material';
import { ClientDataService } from '../../services/app.service';
import { DivisionMasterCreateDialogComponent } from "./division-master-create-dialog/division-master-create-dialog.component";
import { BusinessMasterCreateDialogComponent } from "./business-master-create-dialog/business-master-create-dialog.component";

@Component({
  selector: 'app-master-templates',
  templateUrl: './master-templates.component.html',
  styleUrls: ['./master-templates.component.scss']
})

export class MasterTemplatesComponent implements OnInit {
  private appUrl: any;
    private rowValues={};
    private businessVals=[];
    private divisionVals=[];
    private divisions=[];
    private selDivision='';
    private selectAllBusinessCheck: boolean = false;
    private selectAllDivisionCheck: boolean = false;
    public businessChecked: boolean = false;
    public divisionChecked: boolean = false;
    private checkBusinessStatusList=[];
    private checkDivisionStatusList=[];
    private listofSelectedRows=[];
    private listofNonDefaultRows=[];
    private selRowsCount=[];
    private selectingRows=[]; 
    private businessElementModel=[];
    private divisionElementModel=[];
    private displayedColumns = ['checkbox','Template', 'Final','Active', 'Last Modified By', 'Last Modified','Copy'];
    private initialSelection = [];
    private allowMultiSelect = true;
    private selection = new SelectionModel<PeriodicElement>(this.allowMultiSelect,this.initialSelection);
    private masterDataSource = new MatTableDataSource<PeriodicElement>(this.businessElementModel);
    private divisionDataSource = new MatTableDataSource<PeriodicElement>(this.divisionElementModel);
    private errorCode:any;
    
    constructor(public dialog:MatDialog, @Inject(ClientDataService) private clientDataService: ClientDataService,@Inject(MatSnackBar) public snackBar: MatSnackBar,@Inject(Router) private router:Router) {
      this.appUrl = environment.appURL;
      this.clientDataService.getBusinessRowSelectionObservable().subscribe(res => {
        this.listofNonDefaultRows=[];
        this.selRowsCount = res;//listofSelectedRows
        for(let item of this.businessVals){
          if(item.finalIndicator==false && item.activeIndicator==false){
            this.listofNonDefaultRows.push(true);
          }
        }
        if(this.selRowsCount.length<this.listofNonDefaultRows.length){
          this.businessChecked=false;
          this.selectAllBusinessCheck=false;
        }
        else{
          this.selectAllBusinessCheck=true;
      	  this.businessChecked=true;
        }
      })
      this.clientDataService.getDivisionRowSelectionObservable().subscribe(res => {
        this.listofNonDefaultRows=[];
        this.selRowsCount = res;//listofSelectedRows
        for(let item of this.divisionVals){
          if(item.finalIndicator==false && item.activeIndicator==false){
            this.listofNonDefaultRows.push(true);
          }
        }
        if(this.selRowsCount.length<this.listofNonDefaultRows.length){
          this.divisionChecked=false;
          this.selectAllDivisionCheck=false;
        }
        else{
          this.selectAllDivisionCheck=true;
      	  this.divisionChecked=true;
        }
      })
     }
    ngOnInit() {
      this.getBusinessTemplatesFromServer();
      this.getDivisionTemplatesFromServer();
    }
    
    private createDivision() {
      let self = this;
      let dialogRef = self.dialog.open(DivisionMasterCreateDialogComponent, {
        height: '370px',
        width: '1000px',
        data: []
      });
    
      dialogRef.afterClosed().subscribe(result => {
    
      });
    }
    private createBusiness() {
      let self = this;
      let dialogRef = self.dialog.open(BusinessMasterCreateDialogComponent, {
        height: '370px',
        width: '1000px',
        data: []
      });
    
      dialogRef.afterClosed().subscribe(result => {
    
      });
    }
    
    //Methods to fetch all Business templates 
  getBusinessTemplatesFromServer(){
    let selectedusers=this.appUrl+'businessMasterTemplate/retrieveall?name=' + 'BusinessMasterTemplateList';
    this.clientDataService.setUrl(selectedusers);
    this.clientDataService.getClientData().subscribe(res => {
      this.rowValues=res;
      this.businessVals=res.values;
      this.clientDataService.setRows(this.businessVals);
      for(let row of this.businessVals){
        this.checkBusinessStatusList.push(false);
        let element:PeriodicElement={name:'', final:false, active:false, userName:'',lastModifiedDate:'',copy:'',tempId:null}
        element.name=row.templateName;
        element.final=row.finalIndicator;
        element.active=row.activeIndicator;
        element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName;
        element.lastModifiedDate=row.lastModifiedDate;
        element.tempId=row.id;
        this.businessElementModel.push(element);
      }
      this.masterDataSource = new MatTableDataSource<PeriodicElement>(this.businessElementModel);
    })
  }
  //Methods to fetch all Division templates 
  getDivisionTemplatesFromServer(){
    let selectedusers=this.appUrl+'divisionMasterTemplate/retrieveAll?name=DivisionMasterTemplateList';
    this.clientDataService.setUrl(selectedusers);
    this.clientDataService.getClientData().subscribe(res => {
      // this.rowValues=res;
      this.divisionVals=res.values;
      // this.divisionVals=res.values;
      this.clientDataService.setRows(this.divisionVals);
      for(let row of this.divisionVals){
        this.checkDivisionStatusList.push(false);
        let element:PeriodicElement={name:'', final:false, active:false, userName:'',lastModifiedDate:'',copy:'',tempId:null}
        element.name=row.templateName;
        element.final=row.finalIndicator;
        element.active=row.activeIndicator;
        element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName;
        element.lastModifiedDate=row.lastModifiedDate;
        element.tempId=row.id;
        this.divisionElementModel.push(element);
      }
      this.divisionVals.push({division:{name:'All Divisions'}})
      console.log(this.divisionVals);
      this.divisionDataSource = new MatTableDataSource<PeriodicElement>(this.divisionElementModel);
      for(let div of this.divisionVals){
        if(div.division.name!==null){
        if(div.division.name=='All Divisions'){
          this.selDivision=div.division.name;
          return;
        }}
      }
      // this.selDivision=this.divisionVals.find(val=> val.division.name=="All Divisions").division.name
      // console.log(this.divisionVals.find(val=> val.division.name=="All Divisions"));
      console.log(this.selDivision)
    })
  }
  //   onBusinessSelect(division:any){
  //     if(this.businessChecked || this.selectAllBusinessCheck){
  //       this.selectAllBusinessCheck = !this.selectAllBusinessCheck;
  //       this.businessChecked=!this.businessChecked;
  //     }
  //     this.checkBusinessStatusList=[];
  //     this.selRowsCount=[];
  //     this.listofSelectedRows=[];
  //     this.selectingRows=[];
  //     this.listofNonDefaultRows=[];
  //     this.selDivision=division.name;
  //     this.elementModel=[];
  //     if(division.name=='All Divisions'){
  //       this.getDivisionTemplatesFromServer();
  //     }
  //     else{
  //     let selectedDivision=this.appUrl+'taskTemplate/division/' + JSON.stringify(division.id) + '?name=TaskTemplateList';
  //     this.clientDataService.setUrl(selectedDivision);
  //     this.clientDataService.getClientData().subscribe(res => {
  //       this.divisionVals=res.values;
  //       this.clientDataService.setRows(res.values);
  //       for(let row of res.values){
  //         this.checkBusinessStatusList.push(false);
  //         let element:PeriodicElement={name:'', final:false, active:false, userName:'',lastModifiedDate:'',copy:'',tempId:null}
  //         element.name=row.templateName;
  //         element.final=row.finalIndicator;
  //         element.active=row.activeIndicator;
  //         element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName;
  //         element.lastModifiedDate=row.lastModifiedDate;
  //         element.tempId=row.id;
  //         this.elementModel.push(element);
  //       }
  //       this.divisionDataSource = new MatTableDataSource<PeriodicElement>(this.elementModel);
  //     })
  //   }
  // }
  onDivisionSelect(division:any){
    if(this.divisionChecked || this.selectAllDivisionCheck){
      this.selectAllDivisionCheck = !this.selectAllDivisionCheck;
      this.divisionChecked=!this.divisionChecked;
    }
    this.checkDivisionStatusList=[];
    this.selRowsCount=[];
    this.listofSelectedRows=[];
    this.selectingRows=[];
    this.listofNonDefaultRows=[];
    this.selDivision=division.name;
    this.divisionElementModel=[];
    if(division.division.name=='All Divisions'){
      this.getDivisionTemplatesFromServer();
    }
    else{
      console.log(division)
    let selectedDivision=this.appUrl+'divisionMasterTemplate/division/' + JSON.stringify(division.division.id) + '?name=DivisionMasterTemplateList';
    this.clientDataService.setUrl(selectedDivision);
    this.clientDataService.getClientData().subscribe(res => {
      this.divisionVals=res.values;
      this.clientDataService.setRows(res.values);
      for(let row of res.values){
        this.checkDivisionStatusList.push(false);
        let element:PeriodicElement={name:'', final:false, active:false, userName:'',lastModifiedDate:'',copy:'',tempId:null}
        element.name=row.templateName;
        element.final=row.finalIndicator;
        element.active=row.activeIndicator;
        element.userName=row.lastModifiedUser.lastName +', ' + row.lastModifiedUser.firstName;
        element.lastModifiedDate=row.lastModifiedDate;
        element.tempId=row.id;
        this.divisionElementModel.push(element);
      }
      this.divisionDataSource = new MatTableDataSource<PeriodicElement>(this.divisionElementModel);
    })
  }
}
  modifyBusinessTemplate(template){
    for(let row of this.businessVals){
      if(template.tempId==row.id){
        this.clientDataService.setToBeModified(row.id);  
        break;
      }
    }
      this.router.navigateByUrl('/modifyBusinessMaster');
  }
  modifyDivisionTemplate(template){
    for(let row of this.divisionVals){
      if(template.tempId==row.id){
        this.clientDataService.setToBeModified(row.id);  
        break;
      }
    }
      this.router.navigateByUrl('/modifyDivisionMaster');
  }
  selectAllBusinessRow(event){
    this.divisionChecked = !this.divisionChecked;
    this.selectingRows = [];
    this.listofSelectedRows=[];
    if(event.checked){
      this.isDivisionAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    else{
      this.listofSelectedRows=[];
      for(let i = 0; i <this.businessVals.length; i++){
        this.checkDivisionStatusList[i]=false;
      }
      this.selectingRows = [];
    }
    this.clientDataService.setBusinessRowSelectionObservable(this.selectingRows);
  }
  selectAllDivisionRow(event){
    this.divisionChecked = !this.divisionChecked;
    this.selectingRows = [];
    this.listofSelectedRows=[];
    if(event.checked){
      this.isDivisionAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    else{
      this.listofSelectedRows=[];
      for(let i = 0; i <this.divisionVals.length; i++){
        this.checkDivisionStatusList[i]=false;
      }
      this.selectingRows = [];
    }
    this.clientDataService.setRowSelectionObservable(this.selectingRows);
  }
  businessRowSelChanged(aRow,rowIndex,event){
    if(this.businessChecked){
      this.selectingRows=[]
      this.isBusinessAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    let selectedRowVal = this.clientDataService.getEdittedRow(rowIndex);
    this.checkBusinessStatusList[rowIndex] = event.checked;
    let obj={id:selectedRowVal.id};
    if(event.checked){
      this.listofSelectedRows.push(obj);
      }
    else{
      this.businessChecked= ! this.businessChecked;
      var removeIndex = this.listofSelectedRows.map(function(item) { return item.id; }).indexOf(selectedRowVal.id);
      this.listofSelectedRows.splice(removeIndex, 1);
    }
    this.clientDataService.setRowSelectionObservable(this.listofSelectedRows);
    this.checkBusinessStatusList[rowIndex]=event.checked;
    let selectingRows=[];
    for ( let eachRow of this.businessVals){
      if(this.checkBusinessStatusList){
        selectingRows.push(eachRow.id);
      }
    }
  }
  divisionRowSelChanged(aRow,rowIndex,event){
    if(this.divisionChecked){
      this.selectingRows=[]
      this.isDivisionAllChecked();
      this.listofSelectedRows=this.selectingRows;
    }
    let selectedRowVal = this.clientDataService.getEdittedRow(rowIndex);
    this.checkDivisionStatusList[rowIndex] = event.checked;
    let obj={id:selectedRowVal.id};
    if(event.checked){
      this.listofSelectedRows.push(obj);
      }
    else{
      this.divisionChecked= ! this.divisionChecked;
      var removeIndex = this.listofSelectedRows.map(function(item) { return item.id; }).indexOf(selectedRowVal.id);
      this.listofSelectedRows.splice(removeIndex, 1);
    }
    this.clientDataService.setRowSelectionObservable(this.listofSelectedRows);
    this.checkDivisionStatusList[rowIndex]=event.checked;
    let selectingRows=[];
    for ( let eachRow of this.divisionVals){
      if(this.checkDivisionStatusList){
        selectingRows.push(eachRow.id);
      }
    }
  }
  isBusinessAllChecked(){
    for(let i = 0; i <this.businessVals.length; i++){
      let selRow=this.clientDataService.getEdittedRow(i);
      let obj={id:selRow.id};
      if(selRow && selRow.activeIndicator==false && selRow.finalIndicator== false){
        this.checkBusinessStatusList[i]=true;
          this.selectingRows.push(obj);
      }
      else{
        this.checkBusinessStatusList[i]=false;
      }
    }
  }
  isDivisionAllChecked(){
    for(let i = 0; i <this.divisionVals.length; i++){
      let selRow=this.clientDataService.getEdittedRow(i);
      let obj={id:selRow.id};
      if(selRow && selRow.activeIndicator==false && selRow.finalIndicator== false){
        this.checkDivisionStatusList[i]=true;
          this.selectingRows.push(obj);
      }
      else{
        this.checkDivisionStatusList[i]=false;
      }
    }
  }
  remove(){
    let selectedusers=this.appUrl+'taskTemplates/deleteTts';
    let obj={values:this.listofSelectedRows};
    this.clientDataService.setUrl(selectedusers);
    this.clientDataService.PostClientData(obj).subscribe(res=>{
      let division=this.divisions.find(val=> val.name==this.selDivision);
      this.onDivisionSelect(division);
      this.openSnackBar("Selected Template has been deleted successfully");
      },
      err=>{
        let errVal= JSON.parse(err._body);
        this.errorCode=errVal.errorMessages;
        this.openSnackBar(errVal.errorMessages);
      }
    )
  }
     //generic Method for snackbars
  public openSnackBar(msg){
    this.snackBar.open(msg, 'Close', {
        duration: 5000,
      });
    }
  }
  
  export interface PeriodicElement {
    name: string;
    final: Boolean;
    active: Boolean;
    userName: string;
    lastModifiedDate: string;
    copy:string;
    tempId:number;
  }
  
