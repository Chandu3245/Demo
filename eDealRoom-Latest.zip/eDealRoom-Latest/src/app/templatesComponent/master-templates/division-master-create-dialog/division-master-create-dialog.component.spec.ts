import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DivisionMasterCreateDialogComponent } from './division-master-create-dialog.component';

describe('DivisionMasterCreateDialogComponent', () => {
  let component: DivisionMasterCreateDialogComponent;
  let fixture: ComponentFixture<DivisionMasterCreateDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DivisionMasterCreateDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DivisionMasterCreateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
