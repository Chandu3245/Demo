
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from "@angular/router";
import { ClientDataService } from '../../../services/app.service';
import { environment } from './../../../../environments/environment';

@Component({
  selector: 'app-modify-business-master',
  templateUrl: './modify-business-master.component.html',
  styleUrls: ['./modify-business-master.component.scss']
})
export class ModifyBusinessMasterComponent implements OnInit {

 
  private appUrl: any;
  private taskTemplateForm :any; 
  private taskTemplateValueForm :any; 
  private newTemplateForm:FormGroup;
  private profileFormGroup: FormGroup;
  private templateId=null;
  private resVals:any;
  private rowValues:any;
  private resProperties:any;
  constructor( private fb:FormBuilder,private appService: ClientDataService, private router:Router){
    this.appUrl = environment.appURL;
  }
  
  ngOnInit() {
    this.templateId=this.appService.getToBeModified();
    let selectedusers=this.appUrl+'businessMasterTemplate/' + JSON.stringify(this.templateId) + '/BusinessMasterTemplate';
    this.appService.setUrl(selectedusers);
    this.appService.getClientData().subscribe(res=>{
      console.log(res)
      this.rowValues=res;
      this.resProperties=res.properties;
      this.resVals=res.values;
      this.profileFormGroup = this.createGroup();
      for(let item of res.properties.attributes){
        if(res.values[0][item.attributeName]){
          this.profileFormGroup.controls[item.attributeName].setValue(res.values[0][item.attributeName])
        }
      }
      for(let item of res.properties.subAttributes){
        for(let subItem of item.attributes)
        if(res.values[0][subItem.attributeName]){
          this.profileFormGroup.controls[subItem.attributeName].setValue(res.values[0][subItem.attributeName])
        }
      }
    })
      }
  createGroup() {
    const group = this.fb.group({});
    this.resProperties.attributes.forEach(control => group.addControl(control.attributeName, this.createControl(control)));
    for(let attr of this.resProperties.subAttributes){
      for(let subAttr of attr.attributes){
        group.addControl(subAttr.attributeName,this.createControl(subAttr));
      }
    }
   return group;
  }
  createControl(config) {
    const { isDisabled, validation, value } = config;
    return this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  }
  done(){
    this.router.navigateByUrl('/masterTemplates');
  }
  }
