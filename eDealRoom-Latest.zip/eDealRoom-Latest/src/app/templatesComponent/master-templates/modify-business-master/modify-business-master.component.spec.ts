import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyBusinessMasterComponent } from './modify-business-master.component';

describe('ModifyBusinessMasterComponent', () => {
  let component: ModifyBusinessMasterComponent;
  let fixture: ComponentFixture<ModifyBusinessMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyBusinessMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyBusinessMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
