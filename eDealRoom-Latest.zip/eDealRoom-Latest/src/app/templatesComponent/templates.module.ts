
import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MyMaterialModule } from '../material.module';
import { routing } from './templates-routing';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

import { ClientDataService } from "../services/app.service";
import { TemplatesComponent } from "./templates.component";
import { LibraryTemplatesComponent } from './library-templates/library-templates.component';
import { MasterTemplatesComponent } from './master-templates/master-templates.component';
import { TaskTemplatesComponent } from './task-templates/task-templates.component';
import { LibraryTemplateDialogComponent } from "./library-templates/library-template-dialog.component";
import { TaskCreateDialogComponent } from "./task-templates/task-create-dialog.component";
import { ModifyLibraryTemplateComponent } from "./library-templates/modify-library-template/modify-library-template.component";
import { ModifyTaskTemplateComponent } from './task-templates/modify-task-template/modify-task-template.component';
import { BusinessMasterCreateDialogComponent } from './master-templates/business-master-create-dialog/business-master-create-dialog.component';
import { DivisionMasterCreateDialogComponent } from './master-templates/division-master-create-dialog/division-master-create-dialog.component';
import { ModifyDivisionMasterComponent } from './master-templates/modify-division-master/modify-division-master.component';
import { ModifyBusinessMasterComponent } from './master-templates/modify-business-master/modify-business-master.component';
@NgModule({
    imports:[CommonModule,FormsModule,ReactiveFormsModule,
        MyMaterialModule,
        routing,
        DragDropDirectiveModule,
        ],
        providers: [ClientDataService],
        exports:[],
        declarations:[TaskCreateDialogComponent,TemplatesComponent,LibraryTemplatesComponent, LibraryTemplateDialogComponent,ModifyLibraryTemplateComponent, MasterTemplatesComponent, TaskTemplatesComponent, ModifyTaskTemplateComponent,BusinessMasterCreateDialogComponent, DivisionMasterCreateDialogComponent, ModifyDivisionMasterComponent, ModifyBusinessMasterComponent],
        entryComponents: [
            LibraryTemplateDialogComponent,TaskCreateDialogComponent,BusinessMasterCreateDialogComponent,DivisionMasterCreateDialogComponent
        ],
     })
export class TemplatesModule{
   
}