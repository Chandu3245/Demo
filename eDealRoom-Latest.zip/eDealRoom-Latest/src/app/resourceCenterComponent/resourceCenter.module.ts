import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MyMaterialModule } from '../material.module';
import { routing } from './resource-routing';
import { ResourceComponent } from "./resourceCenter.component";

@NgModule({
    declarations:[ResourceComponent],
    imports:[CommonModule,
        MyMaterialModule,
        routing,
        DragDropDirectiveModule,
        ],
    exports:[ResourceComponent] //components that are defined in this module but might be used in other modules are included here
})
export class ResourceModule{

}