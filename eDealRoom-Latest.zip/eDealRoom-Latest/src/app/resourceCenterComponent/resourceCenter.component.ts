import { Component,OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'resource-comp',
  templateUrl: './resourceCenter.component.html',
  styleUrls: ['./resourceCenter.component.scss']
})
export class ResourceComponent implements OnInit {
 
  ngOnInit(){
  }

}
