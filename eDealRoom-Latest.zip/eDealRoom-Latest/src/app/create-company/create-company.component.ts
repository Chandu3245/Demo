
import { environment } from '../../environments/environment';

import { Component, OnInit, Input, Inject, Output, EventEmitter } from '@angular/core';
import { ClientDataService } from '../services/app.service';


@Component({
  selector: 'app-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.scss']
})
export class CreateCompanyComponent implements OnInit {

  private availCompanyList: any = [];
  private companyFormObj: any;
  private appUrl;
  private activeClick: any;
  private disableInternalCheckBox: boolean = false;
   public closeDialogAfterCreation: boolean;
  public  companyNameCreated: any;
  constructor( @Inject(ClientDataService) private clientDataService: ClientDataService) { 
    this.appUrl = environment.appURL;
   this.activeClick = 1;

  }

  ngOnInit() {
    this.createNewForm();
  }
//creates company creation  Form with Json from server
  createNewForm() { 
      let cretaeNewForm = this.appUrl + 'attributegroups/Company';
      this.clientDataService.setUrl(cretaeNewForm);
        this.clientDataService.getClientData().subscribe(res => {
        this.companyFormObj = res;
      })
    }
  //fetches name of company created newly
 getCreatedCompanyName(event){
      if(event !== undefined){
        this.closeDialogAfterCreation = true;
        this.companyNameCreated = event;
        this.getAvailCompanyListByServer();
        console.log(this.companyNameCreated);
        console.log(this.availCompanyList);
        this.clientDataService.setCompanyCreatedFromDeal(this.companyNameCreated);
      }else{
        this.closeDialogAfterCreation = false;
      }
    }

    getAvailCompanyListByServer() {
      let listUrl= this.appUrl + 'companies' ;
      this.clientDataService.setUrl(listUrl);
      this.clientDataService.getClientData().subscribe(res => {
        for (let data of res.values) {
          this.availCompanyList.push(data)
        }
       })
    }
}
