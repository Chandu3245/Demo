import { MatSnackBar } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { Injectable, Inject } from '@angular/core';
import { Http, Headers, RequestOptions, HttpModule } from '@angular/http';

import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import "rxjs/add/operator/map";

@Injectable()

export class ClientDataService {
    private url: any;
    private route: any;
    private sharePointsearchFldrName: any;
    private attributesToGetData: any;
    private urlToXml: any;
    private headers: any;
    private options: any;
    private tableData: any = {};
    private rows=[];
    private templateId=null;
    private templates=[];
    private userName: any;
    private tabDataObservable: Subject<any> = new Subject();
    private objForTableFetch: any = {}
    private subject = new Subject<any>(); 
    private subjectTemp=new Subject<any>();
    private selValues: Subject<any> = new Subject();
    private selectedBusinessRow:Subject<any>=new Subject();
    private selectedDivisionRow:Subject<any>=new Subject();
    private setCompanyName: Subject<any> = new Subject();

    constructor( @Inject(Http) private _http: Http, @Inject(MatSnackBar) private snackBar: MatSnackBar) {
        //constructor body
    }

    //method to set the current login user
    public setUser(name) {
        this.userName == name;
    }

       //method to get the current login user
    public getUser() {
        return this.userName
    }

    //method to set the url for service call
    public setUrl(url, attr?) {
        if (attr) {
            if (typeof (attr) != 'string') {
                this.attributesToGetData = JSON.stringify(attr);
            } else {
                this.attributesToGetData = attr;
            }
            this.url = url + this.attributesToGetData;
        } else {
            this.url = url
        }
    }
    //method to set route 
    public setRoute(previousRoute:any,currentRoute:any){
       if(previousRoute!==currentRoute){
        this.subject.next(currentRoute);
       }

    }
    //method to get route
    public getRoute():Observable<any> {
        return this.subject.asObservable();
    }
    //method to set tableRows
    public setRows(rows:any){
        this.rows=rows;
    }
    public setToBeModified(templateId:any){
        this.templateId=templateId;
        }
    public getToBeModified(){
        return this.templateId;
    }
    public setTemplateList(templates:any){
        this.subjectTemp.next(templates);
    }
    public getTemplateList():Observable<any>{
        return this.subjectTemp.asObservable();
    }
     //method to post the  url 
    public PostClientData(attr?) {
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
        if (attr && typeof (attr) != 'string') {
            this.attributesToGetData = JSON.stringify(attr);
        } else {
            this.attributesToGetData = attr;
        }
        this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)
        return this._http.post(this.url, this.attributesToGetData, this.options).map(response => response.json());
    }
     //method to put the  url 
    public PutClientData(attr?) {
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: this.headers, withCredentials: true });
        return this._http.put(this.url, attr, options)
               .map(success => success.json())
      }
    //get method for service call
    public getClientData() {
        return this._http.get(this.url).map(response => response.json());
    }
    //delete method for service call
    public deleteClientData(){
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
        this.options = new RequestOptions({ headers: this.headers });
        return this._http.delete(this.url)
           .map(response => response.json());
    }
    //delete method with req payload
    public deleteClientDataWithPayload(attr){
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: this.headers });
        return this._http.delete(this.url , attr)
           .map(response => response.json());
    }
    public setXmlUrl(url) {
        this.urlToXml = url;
    }

    public getXml() {
        return this._http.get(this.urlToXml).map(response => response)
    }

    public setSharePointName(nameToSearch) {
        this.sharePointsearchFldrName = nameToSearch;
    }

    public getSharePointName() {
        return this.sharePointsearchFldrName;
    }

    getEdittedRow(index) {
        return this.rows[index];
    
    }
    setRowSelectionObservable(listofSelectedRows){
        this.selValues.next(listofSelectedRows);
    }
    public getRowSelectioinObservable(): Observable<any>{
        return this.selValues.asObservable();
    }
    public setBusinessRowSelectionObservable(selBusinessRow){
        this.selectedBusinessRow.next(selBusinessRow);
    }
    public getBusinessRowSelectionObservable():Observable<any>{
        return this.selectedBusinessRow.asObservable();
    }
    public setDivisionRowSelectionObservable(selBusinessRow){
        this.selectedDivisionRow.next(selBusinessRow);
    }
    public getDivisionRowSelectionObservable():Observable<any>{
        return this.selectedDivisionRow.asObservable();
    }
    





    //method for fetching  row and column  data for table
    public FetchTable(urlForCol, urlForRows, objForCol, objforRows) {
        this.objForTableFetch = {
            objForCol: objForCol,
            objForRows: objforRows,
            urlForCol: urlForCol,
            urlForRows: urlForRows
        }
        let self = this;
        if (this.objForTableFetch.objForCol != '') {
            this.setUrl(urlForCol, this.objForTableFetch.objForCol)
        } else {
            this.setUrl(urlForCol)
        }
        this.getClientData().subscribe(res => {
            self.tableData['columns'] = res.data;
            if (self.objForTableFetch.objForRows != '') {
                self.setUrl(self.objForTableFetch.urlForRows);
            } else {
                self.setUrl(self.objForTableFetch.urlForRows);
            }
            self.PostClientData(self.objForTableFetch.objForRows).subscribe(res => {
                self.tableData['rows'] = res.data;
                self.setTabDataObserver(self.tableData);
            }, err => {
                this.openSnackBar('Service Error');
            })
        }, err => {
            this.openSnackBar('Service Error');
        })
    }

    //Observable for setting and getting table data 
    public setTabDataObserver(val) {
        this.tabDataObservable.next(val);
    }

    public getTabDataObserver() {
        return this.tabDataObservable.asObservable();
    }

    //method to open snackbar
    private openSnackBar(msg) {
        this.snackBar.open(msg, 'Close', {
            duration: 5000,
        });
    }

    public getCompanyCreatedFromDeal(): Observable <any>{
        return this.setCompanyName.asObservable();
    }
    public setCompanyCreatedFromDeal(compName: any){
        this.setCompanyName.next(compName);
    }

}