
import { DealDashboardComponent } from './dealDashboardComponent/dealDashboard.component';
import { AppComponent} from "./app.component";
import { UserProfileComponent } from "./adminComponent/user-profile/user-profile.component";
import { CompanyProfileComponent } from "./adminComponent/company-profile/company-profile.component"
import { MyProfileComponent } from './adminComponent/my-profile/my-profile.component';
import { MyPreferencesComponent } from './adminComponent/my-preferences/my-preferences.component';
import { BusinessProfileComponent } from './adminComponent/business-profile/business-profile.component';
import { CustomGroupsComponent } from './adminComponent/business-profile/custom-groups/custom-groups.component';
import { ApplicationPermissionsComponent } from './adminComponent/business-profile/application-permissions/application-permissions.component';
import { BusinessHierarchyComponent } from './adminComponent/business-profile/business-hierarchy/business-hierarchy.component';
import { CreateDealComponent } from './dealsComponent/create-deal/create-deal.component';


import { ModuleWithProviders  } from '@angular/core';  
import { Routes, RouterModule } from '@angular/router'; 
import { ProfileFieldsComponent } from './adminComponent/business-profile/profile-fields/profile-fields.component';
import { DataSourcesComponent } from './adminComponent/business-profile/data-sources/data-sources.component';
import { DataSourceConfigurationComponent } from './adminComponent/business-profile/data-sources/data-source-configuration/data-source-configuration.component';


const appRoutes: Routes = [
    {path :'dashboard',component:DealDashboardComponent},
    {path :'companyProfile',component:CompanyProfileComponent},
    {path :'userProfile',component:UserProfileComponent},
    {path :'myProfile',component:MyProfileComponent},
    {path :'myPreferences',component:MyPreferencesComponent},
    {path :'businessProfile',
      children: [
              {path: '', component:BusinessProfileComponent},
              { path: 'customGroups/:selectedDivision', component: CustomGroupsComponent },
              { path: 'appPermissions/:selectedDivision', component: ApplicationPermissionsComponent },
              { path: 'businessHierarchy/:selectedDivision', component: BusinessHierarchyComponent },
              { path: 'profileFields', component: ProfileFieldsComponent },
              { path: 'dataSources',
               children: [
                { path: '', component: DataSourcesComponent },
                {path: 'dataSourceConfiguration/:id', component: DataSourceConfigurationComponent}
              ]}
            ]
      },
    {path :'createDeal',component:CreateDealComponent},
    
    { path:'activity', loadChildren:'./activityDashboardComponent/activityDashboard.module#ActivityModule'},
    { path:'admin', loadChildren:'./adminComponent/admin.module#AdminModule'},
    { path:'deals', loadChildren:'./dealsComponent/deals.module#DealsModule'},
    { path:'reports', loadChildren:'./reportsComponent/reports.module#ReportsModule'},
    { path:'resource', loadChildren:'./resourceCenterComponent/resourceCenter.module#ResourceModule'},
    { path:'search', loadChildren:'./searchComponent/search.module#SearchModule'},
    { path:'templates', loadChildren:'./templatesComponent/templates.module#TemplatesModule'},
    { path: '',redirectTo:'/dashboard',pathMatch:'full'},
   ];
  export const appRouting: ModuleWithProviders = RouterModule.forRoot(appRoutes);