import { Pipe } from "@angular/core";

@Pipe({
  name: "sort"
})
export class SortPipe {
  transform(array: Array<string>, propertyToSort: string): Array<string> {
    array.sort((a: any, b: any) => {
        if(propertyToSort){
            if (a[propertyToSort] < b[propertyToSort]) {
                return -1;
              } else if (a[propertyToSort] > b[propertyToSort]) {
                return 1;
              } else {
                return 0;
              }
        }else{
            if (a< b) {
                return -1;
              } else if (a > b) {
                return 1;
              } else {
                return 0;
              }
        }
     
    });
    return array;
  }
}