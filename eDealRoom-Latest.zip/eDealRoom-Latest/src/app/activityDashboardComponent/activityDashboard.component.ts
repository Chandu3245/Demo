import { Component,OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'activity-dash',
  templateUrl: './activityDashboard.component.html',
  styleUrls: ['./activityDashboard.component.scss']
})
export class ActivityComponent implements OnInit {
 
  ngOnInit(){
  }

}
