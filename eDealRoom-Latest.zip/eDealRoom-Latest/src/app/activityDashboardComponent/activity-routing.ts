import { ActivityComponent } from './activityDashboard.component';
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', component: ActivityComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);