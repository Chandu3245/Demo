import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MyMaterialModule } from '../material.module';
import { routing } from './activity-routing';
import { ActivityComponent } from "./activityDashboard.component";

@NgModule({
    declarations:[ActivityComponent],
    imports:[CommonModule,
        MyMaterialModule,
        routing,
        DragDropDirectiveModule,
        ],
    exports:[ActivityComponent] //components that are defined in this module but might be used in other modules are included here
})
export class ActivityModule{

}