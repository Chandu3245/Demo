import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MyMaterialModule } from '../material.module';
import { routing } from './search.routing';
import { SearchComponent } from "./search.component";

@NgModule({
    declarations:[SearchComponent],
    imports:[CommonModule,
        MyMaterialModule,
        routing,
        DragDropDirectiveModule,
        ],
    exports:[SearchComponent] //components that are defined in this module but might be used in other modules are included here
})
export class SearchModule{

}