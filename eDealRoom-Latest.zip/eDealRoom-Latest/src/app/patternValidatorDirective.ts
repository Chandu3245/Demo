
// import { Directive, OnChanges } from '@angular/core';

// @Directive({
//   selector: '[pattern][formControlName],[pattern][formControl],[pattern][ngModel]',
//   providers: [PATTERN_VALIDATOR],
//   host: { '[attr.pattern]': 'pattern ? pattern : null' }
// })
// class PatternValidator implements Validator, OnChanges {
// pattern: string | RegExp
// ngOnChanges(changes: SimpleChanges): void
// validate(c: AbstractControl): ValidationErrors | null
// registerOnValidatorChange(fn: () => void): void
// }