
import { Component,OnInit } from '@angular/core';
import {Router,Params,ActivatedRoute} from '@angular/router';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { ClientDataService } from "./services/app.service";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  private listOfTabs:any =
  [
      {
      statusName:"Deal DashBoard",
      ListOfPolicies:[],
      statusIndex:0,
      },
      {
      statusName:"Deals",
      ListOfPolicies:['Deal List','Create Deal'],
      statusIndex:1,
      },
      {
        statusName:"Resource Center",
        ListOfPolicies:[],
        statusIndex:2,
      },
      {
        statusName:"Search",
        ListOfPolicies:['Deal Search','Document search'],
        statusIndex:3,
      },
      {
        statusName:"Templates",
        ListOfPolicies:['Library Templates','Master Templates','Task Templates'],
        statusIndex:4,
      },
      {
        statusName:"Reports",
        ListOfPolicies:['Generate Report','Deal PipeLine','MileStone Summary','Custom Deal List','Custom Reports Config'],
        statusIndex:5,
      },
      {
        statusName:"Activity Dashboard",
        ListOfPolicies:[],
        statusIndex:6,
      },
      {
        statusName:"Admin",
        ListOfPolicies:['My Profile','My Preferences','Business Profile','User Profiles','Company Profiles'],
        statusIndex:7,
      },
  ]
  private sideNavOpen:boolean= false;
  private viewHeadlineIcon:any = true;
  private rightArrowlineIcon:any = false;
  private sideNavWithNames:any = true;
  private sideNavWithOutNames:any = false;
  private leftArrowlineIcon:any = false;
  private showOnlyIcons:boolean = false;
  private showminimizeSideNavIcon:boolean = false;
  private compSelected:any;
  private checkshowminimizeSideNavIconStatus:boolean = true;
  private navItemName:string = "";
  private navItem:string = "";
  private userName:any=''
  private isMobileLen:any;
  private isTabLen:any=[320, 414];
  private deviceType:any='';
  private deviceOrien:any='';
  private appURL:string;
   private sidenavWidth:string="185px";
   private toolbarMargin:String = "0px";
   private navMode :String='side';
   private activeSideItem:any=0;
   private sideNavToggle:boolean=false;	
   private subject = new Subject<any>(); 
   constructor(private router:Router,private route: ActivatedRoute, private service:ClientDataService){
   }
    ngOnInit(){
      this.router.navigateByUrl('/dashboard');
      this.service.setRoute(this.router.url,'/dashboard');
      this.service.getRoute().subscribe(data=> {
        this.navItemName=data;
        })
      }
      ngAfterViewInit(){

      }
  public changeRoute(routeName,sideNavRef){
    if(this.checkshowminimizeSideNavIconStatus){
        if(this.compSelected != routeName){
          this.showminimizeSideNavIcon = !this.showminimizeSideNavIcon;
        }
    this.checkshowminimizeSideNavIconStatus = false;
    }
    this.compSelected = routeName;
    this.navItem = routeName.substr(1, routeName.length);
    this.service.setRoute(this.router.url,routeName);
    this.router.navigateByUrl(routeName)
      }
   public closeLeftPanel(){
    this.showminimizeSideNavIcon =false;
    this.sideNavOpen = !this.sideNavOpen;
    this.checkshowminimizeSideNavIconStatus = true;
    this.compSelected="";
    this.navItemName = "";
    this.sidenavWidth = "120";
    if (window.innerWidth >992 ) {
     this.navMode = "side";
     } else {
     this.navMode = "open";
     } 
  }
  //minimizeSideNav on click of keyboard_arrow_left
    public minimizeSideNav(){
      this.sidenavWidth="50px"; 
      this.toolbarMargin = "20px"
       this.sideNavWithNames = false;
        this.sideNavToggle = !this.sideNavToggle;
     }
   //maximized SideNav on click of keyboard_arrow_right
     public showIconWithNames(){
      this.sideNavToggle = !this.sideNavToggle;
       this.sideNavWithNames = !this.sideNavWithNames;
       this.sidenavWidth="185px"; 
       this.toolbarMargin = "0px"
   }


}
